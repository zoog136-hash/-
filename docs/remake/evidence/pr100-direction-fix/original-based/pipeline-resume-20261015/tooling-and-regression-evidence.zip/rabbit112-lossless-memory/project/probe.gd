extends SceneTree

var retained: Array[Texture2D] = []
var atlases: Array[AtlasTexture] = []
var probe_data: Dictionary

func rss_kib() -> int:
	var status_file := FileAccess.open('/proc/self/status', FileAccess.READ)
	var status := status_file.get_buffer(32768).get_string_from_utf8()
	for line in status.split('\n'):
		if line.begins_with('VmRSS:'):
			return int(line.split(':')[1].strip_edges().split(' ')[0])
	return -1

func _initialize() -> void:
	call_deferred('_run')

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var count := int(args[0]) if args.size() > 0 else 1
	var output := args[1] if args.size() > 1 else 'res://probe-result.json'
	var image_inspect := args.size() > 2 and args[2] == 'inspect'
	probe_data = JSON.parse_string(FileAccess.get_file_as_string('res://probe-data.json'))
	var initial_rss := rss_kib()
	var initial_gpu := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TEXTURE_MEM_USED)
	var began := Time.get_ticks_usec()
	var textures: Array[Dictionary] = []
	for i in mini(count, probe_data.files.size()):
		var spec: Dictionary = probe_data.files[i]
		var path := 'res://sources/' + str(spec.id) + '.png'
		var start := Time.get_ticks_usec()
		var texture := load(path) as Texture2D
		retained.append(texture)
		textures.append({'id':spec.id,'texture_class':texture.get_class(),'reported_size':[texture.get_width(),texture.get_height()],'load_usec':Time.get_ticks_usec()-start})
	var load_elapsed_usec := Time.get_ticks_usec() - began
	for f in probe_data.frames:
		var idx := int(str(f.file_id).trim_prefix('p'))
		if idx >= retained.size(): continue
		var a := AtlasTexture.new()
		a.atlas = retained[idx]
		a.region = Rect2(f.region[0], f.region[1], f.region[2], f.region[3])
		a.margin = Rect2(f.margin[0], f.margin[1], f.margin[2], f.margin[3])
		atlases.append(a)
	await process_frame
	await process_frame
	var load_gpu := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TEXTURE_MEM_USED)
	var load_rss := rss_kib()
	var image_data: Array[Dictionary] = []
	if image_inspect:
		for i in retained.size():
			var image := retained[i].get_image()
			if i == 1 and count == 31:
				image.save_png('res://../cache-' + str(ProjectSettings.globalize_path('res://').get_base_dir().get_file()) + '-p01.png')
			image_data.append({'id':probe_data.files[i].id,'physical_image_size':[image.get_width(),image.get_height()],'image_format':image.get_format(),'image_data_bytes':image.get_data_size(),'has_mipmaps':image.has_mipmaps()})
	var atlas_data: Array[Dictionary] = []
	for i in atlases.size():
		var a := atlases[i]
		atlas_data.append({'reported_size':[a.get_width(),a.get_height()],'region':[a.region.position.x,a.region.position.y,a.region.size.x,a.region.size.y],'margin':[a.margin.position.x,a.margin.position.y,a.margin.size.x,a.margin.size.y]})
	var result := {'engine':Engine.get_version_info().string,'headless':DisplayServer.get_name()=='headless','adapter':RenderingServer.get_video_adapter_name(),'count':count,'unique_loaded':retained.size(),'load_usec':load_elapsed_usec,'rss_initial_kib':initial_rss,'rss_loaded_kib':load_rss,'gpu_texture_mem_initial_bytes':initial_gpu,'gpu_texture_mem_loaded_bytes':load_gpu,'gpu_texture_mem_delta_bytes':load_gpu-initial_gpu,'textures':textures,'images':image_data,'atlases':atlas_data}
	FileAccess.open(output,FileAccess.WRITE).store_string(JSON.stringify(result,'  ')+'\n')
	print('MEMORY_PROBE ',JSON.stringify({'count':count,'loaded':retained.size(),'load_usec':load_elapsed_usec,'rss_initial_kib':initial_rss,'rss_loaded_kib':load_rss,'gpu_delta_bytes':load_gpu-initial_gpu,'headless':result.headless}))
	quit()
