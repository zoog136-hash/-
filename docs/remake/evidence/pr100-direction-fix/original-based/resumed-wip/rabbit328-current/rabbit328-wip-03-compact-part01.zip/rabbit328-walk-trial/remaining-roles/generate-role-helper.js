const run=(async function(s) {
 const q=x=>"'"+String(x).replace(/'/g,"'\\''")+"'";
 try {
  const p=await tools.exec_command({cmd:"cat "+q(s.prompt),max_output_tokens:4500});
  const r=await tools.image_gen__imagegen({prompt:p.output,referenced_image_paths:s.reference_images,transparent_background:true});
  store("rabbitLastResult",r);store("rabbitLastSpec",s);generatedImage(r);
  let raw=String(r.output_hint).match(/\/workspace\/generated_images\/[^ \n]+\.png/)?.[0],copied=false,method="Byte-identical raw file copy";
  if(raw) {const c=await tools.exec_command({cmd:"cp "+q(raw)+" "+q(s.output_copy),max_output_tokens:500});copied=c.exit_code===0;}
  if(!copied && typeof r.image_url==="string" && r.image_url.startsWith("data:image/png;base64,")) {
   const payload=r.image_url.split(",")[1],payloadPath=s.output_copy+".tool-base64.txt";
   await tools.apply_patch("*** Begin Patch\n*** Add File: "+payloadPath+"\n+"+payload.match(/.{1,120}/g).join("\n+")+"\n*** End Patch");
   const cmd="python3 - <<'PY'\nfrom pathlib import Path\nimport base64,hashlib\nraw=base64.b64decode(Path("+JSON.stringify(payloadPath)+").read_text())\nPath("+JSON.stringify(s.output_copy)+").write_bytes(raw)\nassert hashlib.sha256(raw).digest()==hashlib.sha256(Path("+JSON.stringify(s.output_copy)+").read_bytes()).digest()\nprint('TOOL_DATA_URL_RAW_BYTES_SAVED',len(raw))\nPY";
   text(await tools.exec_command({cmd,max_output_tokens:500}));raw=s.output_copy;copied=true;method="Exact original tool PNG data URL decoded, no art/pixel modification";
  }
  if(!copied) {text({status:"RAW_PERSISTENCE_FAILED",direction:s.direction,phase:s.phase,resultKeys:Object.keys(r)});return;}
  text(await tools.exec_command({cmd:"python3 /workspace/scratch/pr100-continuation/dancing-sword-authoring/analyze_stage.py "+q(s.output_copy)+" --rows "+s.rows_count+" --directions "+s.direction_pair.join(",")+" --axis "+s.directions_axis+" --canvas "+s.canvas,max_output_tokens:1200}));
  const rec={...s,raw_generated_path:raw,raw_persistence_method:method,new_authored_2D_not_original_extraction:true,Main:false,completed_added:0};
  await tools.apply_patch("*** Begin Patch\n*** Add File: "+s.output_copy.replace(/\.png$/,".generation.json")+"\n+"+JSON.stringify(rec,null,2).replace(/\n/g,"\n+")+"\n*** End Patch");
 } catch(e) {
  const failure={...s,status:"TOOL_FAILURE",error:String(e),image_created:false,success_claimed:false,Main:false,completed_added:0};
  await tools.apply_patch("*** Begin Patch\n*** Add File: "+s.output_copy.replace(/\.png$/,".tool-failure-"+Date.now()+".json")+"\n+"+JSON.stringify(failure,null,2).replace(/\n/g,"\n+")+"\n*** End Patch");
  text({status:"TOOL_FAILURE",direction:s.direction,phase:s.phase,error:String(e)});
 }
});

