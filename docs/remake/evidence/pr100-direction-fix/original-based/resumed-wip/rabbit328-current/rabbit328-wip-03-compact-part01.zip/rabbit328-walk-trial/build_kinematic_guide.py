import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pathlib,json,hashlib
b=pathlib.Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose')
fig,ax=plt.subplots(figsize=(7,7),dpi=160)
ax.set_xlim(-.7,.8);ax.set_ylim(-.13,1.35);ax.set_aspect('equal');ax.axis('off')
ax.axhline(0,color='#333333',linewidth=2)
ax.plot([0,0],[1.02,1.24],color='#777777',linewidth=5)
near=[[.03,1.02],[-.17,.61],[-.33,.19]]
far=[[-.03,1.00],[.19,.57],[.35,.10]]
ax.plot(*zip(*far),color='#008fbb',linewidth=12,solid_capstyle='round',zorder=2)
ax.plot(*zip(*near),color='#b32a83',linewidth=12,solid_capstyle='round',zorder=3)
for pts,c,z in [(far,'#005c79',4),(near,'#761a56',5)]:
 ax.scatter(*zip(*pts),s=125,c=c,edgecolors='white',linewidths=1.2,zorder=z)
ax.plot([-.365,-.29,-.12], [.20,.105,.10],color='#b32a83',linewidth=11,solid_capstyle='round',zorder=3)
ax.plot([.30,.39,.59],[0,0,0],color='#008fbb',linewidth=11,solid_capstyle='round',zorder=2)
ax.plot([-.02,-.095],[.90,.86],color='black',linewidth=13,zorder=8)
ax.annotate('FACING E / RIGHT',xy=(.61,1.22),xytext=(-.15,1.22),arrowprops={'arrowstyle':'->','lw':2},fontsize=14,weight='bold')
ax.annotate('NEAR / BANDED THIGH\ntravels BACK to LEFT',xy=(-.09,.81),xytext=(-.66,.86),arrowprops={'arrowstyle':'->','color':'#b32a83'},fontsize=10,color='#761a56')
ax.annotate('FAR / PLAIN THIGH\ntravels FORWARD to RIGHT',xy=(.14,.70),xytext=(.27,.92),arrowprops={'arrowstyle':'->','color':'#008fbb'},fontsize=10,color='#005c79')
ax.annotate('rear boot lifted\ntoe still points RIGHT',xy=(-.16,.11),xytext=(-.65,.36),arrowprops={'arrowstyle':'->','color':'#b32a83'},fontsize=10,color='#761a56')
ax.annotate('forward boot PLANTED\nwhole sole on baseline',xy=(.48,0),xytext=(.17,.32),arrowprops={'arrowstyle':'->','color':'#008fbb'},fontsize=10,color='#005c79')
ax.text(-.65,-.105,'KINEMATICS ONLY: no costume, face, colors or extra anatomy to copy',fontsize=8,color='#555555')
fig.savefig(b/'desired-E-opposite-support-guide.png',bbox_inches='tight',facecolor='white');plt.close(fig)
r={'subject':'transform:328','purpose':'Desired singleEwalkC legtopology constraint. Coloredtechnicaldiagram is newlydrawn, not editedcharacterart or pixeltrackedgroundtruth.','near_banded_leg':{'hip':near[0],'knee':near[1],'ankle':near[2],'physical_path':'hip→back-leftknee→back-leftankle→liftedrightpointingboot'},'far_plain_leg':{'hip':far[0],'knee':far[1],'ankle':far[2],'physical_path':'hip→front-rightknee→front-rightankle→flatrightpointingboot'},'ground_y':0,'compared_existing_motion_reference':{'path':'assets/actors/eight_direction/original_based/succubus/poses.png','provenance_frames':[16,32],'use':'Viewedapprovedhumanwalkphaselegbends for kinematicprinciple only. Its costume,wings,bodyproportions andidentity are NOT referenced by imagegen.'},'source_pixels_modified':False,'imagegen_identity_refs':['assets/catalog/96c155500a24fa3048b0f5d0.png','docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/E-W/generated-E-W-walk.png']}
(b/'kinematic-guide.json').write_text(json.dumps(r,indent=2)+'\n')
print('GUIDE_SHA256',hashlib.sha256((b/'desired-E-opposite-support-guide.png').read_bytes()).hexdigest())
