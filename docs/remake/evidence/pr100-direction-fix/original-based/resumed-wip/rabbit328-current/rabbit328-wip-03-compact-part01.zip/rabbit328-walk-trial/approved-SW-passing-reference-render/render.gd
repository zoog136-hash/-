extends SceneTree
const OUT="/workspace/scratch/pr100-continuation/rabbit328-single-pose/approved-SW-passing-reference-render"
func _initialize() -> void:
 call_deferred("run")
func run() -> void:
 root.transparent_bg=true
 RenderingServer.set_default_clear_color(Color(0,0,0,0))
 var source:=Image.new()
 var original: String="/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/SW-NE/generated-walk-SW-NE.png"
 assert(source.load(original)==OK)
 var sprite:=Sprite2D.new()
 sprite.texture=ImageTexture.create_from_image(source)
 sprite.region_enabled=true
 sprite.region_rect=Rect2(640,27,232,470)
 sprite.scale=Vector2.ONE*2.2280701754
 sprite.position=Vector2(627,627)
 root.add_child(sprite)
 await process_frame
 await RenderingServer.frame_post_draw
 assert(root.get_texture().get_image().save_png(OUT+"/existing-SW-passing2-reference.png")==OK)
 var f:=FileAccess.open(OUT+"/render-provenance.json",FileAccess.WRITE)
 f.store_string(JSON.stringify({"source":original,"region":[640,27,232,470],"render_scale":2.2280701754,"engine":Engine.get_version_info(),"purpose":"RenderexistinggenuinesingleSWpassingforreference; notnewanimation/extractionclaim; sourcepixelsunchanged."},"\t")+"\n")
 f.close()
 print("SW_PASSING_REFERENCE_RENDER_OK")
 quit(0)
