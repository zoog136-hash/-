from pathlib import Path
import json,hashlib,math,shutil
from PIL import Image
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose')
old=b/'review.json'
if not (b/'review-first-single-pose.json').exists():shutil.copyfile(old,b/'review-first-single-pose.json')
if not (b/'checkpoint-first-single-pose.json').exists():shutil.copyfile(b/'checkpoint.json',b/'checkpoint-first-single-pose.json')
rows=[
 ('opposite-first','/workspace/generated_images/exec-ed2326a5-8d37-4c91-8533-c7494dbf0d07.png','E-opposite-support-attempt1.png','E-opposite-support-attempt1.prompt.txt'),
 ('opposite-anatomical-correction','/workspace/generated_images/exec-a207ae9b-7c15-4dee-87c3-0b185511450b.png','E-opposite-support-proportion-edit.png','E-opposite-support-proportion-edit.prompt.txt'),
 ('passing2-first','/workspace/generated_images/exec-9cb66739-3610-43ce-bcd2-69546dfe1038.png','E-passing2-attempt1.png','E-passing2.prompt.txt'),
 ('passing2-anatomical-correction','/workspace/generated_images/exec-e3d89910-7005-4bfb-bae1-c497e88f8ced.png','E-passing2-proportion-edit.png','E-passing2-proportion-edit.prompt.txt')]
records=[]
for name,raw,copy,prompt in rows:
 rawdata=Path(raw).read_bytes();copydata=(b/copy).read_bytes();assert rawdata==copydata
 diag=json.loads((b/Path(copy).with_suffix('.diagnostic.json')).read_text())
 records.append({'stage':name,'raw_generated_path':raw,'unchanged_copy':copy,'prompt':prompt,'sha256':hashlib.sha256(copydata).hexdigest(),'bytes':len(copydata),'image_size':list(Image.open(b/copy).size),'analyze':diag['analyze_status'],'complete_visible_regions':diag['complete_pose_regions_status'],'raw_copy_byte_identity':True,'new_authored_2D_not_original_extraction':True})
(b/'generation-history.json').write_text(json.dumps(records,indent=2)+'\n')
manual={
 'method':'Manually estimated projected 2D hip/knee/ankle centers from exact raw images. Hips partly occluded by skirt; these are NOT recovered 3D bone lengths, not automated ground truth and not a proportion PASS. Uncertainty approximately10–25newrawpixels per joint, 5–10oldrawpixels. Normalize each projected segment by corresponding skin-face height; do not interpret hem-to-ground vertical span as bone length.',
 'old_A':{'face_height':57,'near_banded':[[296,370],[313,415],[336,458]],'far_plain':[[261,366],[228,402],[193,442]]},
 'new_B_corrected':{'face_height':127,'near_banded':[[613,835],[548,903],[451,975]],'far_plain':[[731,828],[769,915],[813,1005]]},
 'new_passing2_corrected':{'face_height':123,'near_banded':[[738,783],[837,747],[823,875]],'far_plain':[[641,819],[616,928],[608,1034]]},
 'interpretation':'Estimated projected segments show no universal13%bodygrowth claim. B far leg foreshortening and passing2 near-thigh occlusion prevent exact equality claims. Parent independent visual anatomy review required; record the estimates transparently rather than marking a numeric threshold PASS.'}
for name in ['old_A','new_B_corrected','new_passing2_corrected']:
 for side in ['near_banded','far_plain']:
  pts=manual[name][side];ls=[math.dist(pts[i],pts[i+1]) for i in [0,1]]
  manual[name][side+'_projected_lengths_px']=ls
  manual[name][side+'_projected_lengths_per_faceheight']=[v/manual[name]['face_height'] for v in ls]
(b/'projected-anatomical-landmarks.json').write_text(json.dumps(manual,indent=2)+'\n')
preview=b/'registered-E-fourphase';config=json.loads((preview/'config.json').read_text());report=json.loads((preview/'godot-preview.json').read_text())
assert report['loop_capture_count']==90 and len(report['registered_captures'])==4
hashes=[]
for spec in config['specs']:
 im=Image.open(spec['path']);x,y,w,h=spec['region'];crop=im.crop((x,y,x+w,y+h));hashes.append(hashlib.sha256(crop.tobytes()).hexdigest())
assert len(set(hashes))==4
review={
 'key':'transform:328','status':'E_FOUR_PHASE_DIAGNOSTIC_PENDING_INDEPENDENT_REVIEW','source':{'path':'/workspace/twilight/assets/catalog/96c155500a24fa3048b0f5d0.png','sha256':'f4ddb1e1084a79c371a2bd647bfa91a07dce4e9cd6a465b2dea407f84e1735db'},
 'source_pixels_modified':False,'old_assets_and_failures_preserved':True,'newly_authored_2D_not_original_animation_extraction':True,
 'generation_history':'generation-history.json','latest_new_images':['E-opposite-support-proportion-edit.png','E-passing2-proportion-edit.png'],
 'independent_parent_approval_so_far':'First single opposite-support pose LEG_PATH_OPPOSITE_SUPPORT_ONLY: banded near leg hip→rear-left knee→ankle→liftedboot; plain far leg hip→front-right knee→ankle→plantedsole. Proportions and latereditedposes/loop remain unapproved.',
 'strict_gate_results':records,
 'registered_E_loop':{'configuration':'registered-E-fourphase/config.json','script':'registered-E-fourphase/preview.gd','render_log':'registered-E-fourphase/godot.log','report':'registered-E-fourphase/godot-preview.json','MP4':'registered-E-fourphase/registered-loop.mp4','GIF':'registered-E-fourphase/registered-loop.gif','timing':'registered-E-fourphase/video-timing.json','encoded_duration_seconds':6.72,'encoded_frames_including_final_hold':91,'initial_incorrect_fixed30fps_encodings_retained':True,'static_captures':4,'actual_playback_capture_PNGs':90,'exact_distinct_pose_crop_hashes':hashes,'sequence':['existing A: banded near front support','existing passing1: banded near vertical support / plain far knee lifted','new corrected B: banded near rear lifted / plain far front support','new corrected passing2: banded near front knee lifted / plain far vertical support'],'fixed_world_root':[550,600],'source_anchors_never_follow_forward_toe':True,'renderer':'Godot4.7.2 OpenGL3 Mesa llvmpipe','actual_Main':False},
 'author_visual_findings':['All4 static registered poses were inspected. Physical support legs genuinely alternate; blackband follows nearleg rather than changing stocking identity.','A/passing1 defaultoldsourceanchorx768 had28px passing torso drift in first3phase preview. Replaced only metadata with body/head correspondence x736; failedregistration capture retained.','First passing2 actualsoley1177 caused~20px extra rise after support registration. Focused thigh/shin edit shortened actualanatomy; revisedsoley1145. This correction is newart, no pixeltrimming/rescaling on disk.','After corrected4phase registration cap tops are within~6previewpixels, headsize broadly similar. Exactproportion/cycle naturalness still requires independentreview.','NewB/oldA bodyrootX derives from face/torso correspondence, not forwardtoe. Actual supportsoleY used perimage.','Threephase B→A lacked oppositepassing. A genuine fourth pose was authored; no duplicated/translatedstill used.'],
 'proportion_correction_to_prior_claim':'Old13%claim used arbitrary1024:2048canvas metadata and was not anatomicalgrowth evidence. See proportion-landmark-analysis.json. Hem-to-groundspan also depends on bentknees; see projected-anatomical-landmarks.json for explicitly approximate hip/knee/ankle estimates. NoanatomicalPASS claimed.',
 'retained_intermediate_evidence':['registered-E-threephase','registered-E-fourphase-attempt1','E-opposite-support-attempt1.png','E-passing2-attempt1.png'],
 'not_yet_verified':['Independent exact limbproportions and stable costume comparison','Independent4phaseEloop naturalness','Remaining7walkdirections','All5roles8directions','ActualMain integration and player attack/hit/death/drop/pickup','Final importer contact/native height86'],
 'production_imported':False,'all8directions':False,'all5roles':False,'Main':'not_run','completed_added':0,
 'next':'Root independently review corrected B and4phaseEloop. No8direction expansion until trialreview. Keep all failure rawfiles and metadata; only then authorize directionalmethod expansion.'}
(b/'review.json').write_text(json.dumps(review,indent=2)+'\n')
checkpoint={'key':'transform:328','status':review['status'],'latest_review':'review.json','history':'generation-history.json','latest_loop':'registered-E-fourphase/registered-loop.mp4','latest_loop_GIF':'registered-E-fourphase/registered-loop.gif','raw_images':review['latest_new_images'],'strict_singlepose_analyze_complete_regions':'PASS all4generatedrecords','independent_approval':'Firstoppositelegpathonly; anatomy/loopunapproved','new_completed':0,'Main':'not_run','production_imported':False,'next':review['next']}
(b/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
for folder in [b/'registered-E-threephase',b/'registered-E-fourphase-attempt1',preview]:
 paths=sorted(p for p in folder.rglob('*.png') if '.godot' not in p.parts)
 manifest=[{'path':str(p.relative_to(folder)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
 (folder/'capture-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
manifest=[]
for p in sorted(b.rglob('*')):
 if p.is_file() and '.godot' not in p.parts and not any(x.startswith('xdg-') for x in p.parts) and 'mplconfig' not in p.parts and p.name!='artifacts-manifest.json':
  manifest.append({'path':str(p.relative_to(b)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(b/'artifacts-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':review['status'],'raw_records':len(records),'registered_distinct_poses':len(set(hashes)),'actual_Godot_capture_pngs':94,'Main':False,'completed_added':0,'manifest_files':len(manifest)},indent=2))
