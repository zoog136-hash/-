# transform328 WIP03 resume

Read LATEST-WIP03-CHECKPOINT.json first. No completed actor or Main claim. Restore WIP02 compact parts then WIP03 compact parts into the same rabbit328-walk-trial directory. WIP02 carries old raw history; WIP03 adds all persisted raw remaining80 role sheets, fresh trial02 single-walk/art+guides/prompts/failures, diagnostic code/reports/representative captures and realtimed MP4. SHA manifests retain excluded redundant capture bodies.

Current raw112 matrix is walk-trial02/selected32-whole-raw-trial02.json plus remaining-roles/selected80-raw-eligible.json. These are candidate metadata, not explicit independent visual acceptance. Read parent review scopes and exact next steps in checkpoint. No production assembled PNG is created or approved. Raw PNGs remain byte-identical. Map/production code/profile/importer edits belong to parent, not this scratch authoring task.
