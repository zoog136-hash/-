from pathlib import Path
import hashlib,json,zipfile,datetime
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');out=Path('/workspace/scratch/pr100-continuation/rabbit328-portable');prefix='rabbit328-walk-trial/';label='wip-03-compact';allsha=[];excluded=[];items=[]
def digest(data):return hashlib.sha256(data).hexdigest()
for p in sorted(b.rglob('*')):
 if not p.is_file() or '.godot' in p.parts or any(x.startswith('xdg-') for x in p.parts) or 'mplconfig' in p.parts:continue
 data=p.read_bytes();rel=str(p.relative_to(b));rec={'path':rel,'bytes':len(data),'sha256':digest(data)};allsha.append(rec)
 isnew=rel.startswith(('remaining-roles/','walk-trial02/','registered-E-trial02-standalone/','registered32-trial02-atomic/'))
 reason=None
 if 'loop-frames' in p.parts and p.suffix=='.png':reason='Redundantactualdiagnosticcapturebody;SHAkept, MP4+representativestatickept.'
 elif p.suffix=='.gif':reason='RedundantGIFderivative;SHAkept, actualtimingMP4retained.'
 elif p.suffix in ['.png','.mp4'] and not isnew:reason='Oldraw/reference/diagnostic alreadydurablyincludedinWIP02compactparts;SHA/pathkept,restoreWIP02first.'
 elif p.name.endswith('.tool-base64.txt'):reason='RedundantexacttoolPNGbase64payload; decodedrawPNGretainedwithmatchingSHA, payloadSHAretained.'
 if reason:excluded.append({**rec,'reason':reason});continue
 items.append((prefix+rel,data))
oldindex=json.loads((out/'rabbit328-wip-02-compact-archive-index.json').read_text());latest=json.loads((b/'LATEST-WIP03-CHECKPOINT.json').read_text());metadata={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':label,'status':'WIP112_RAW_CANDIDATE_UNAPPROVED_8DIR_REGISTRATION_MAIN','restore_prerequisite':oldindex,'latest_checkpoint':latest,'included_new_art':'Allpersistedremaining80rolesheets includingfailed/revisedraws; E2standalone,W/NW/SW6actualopposites,NWpassing1anatomicalcorrection plusguides/exactprompts/failures/currentcandidateJSON.','source_reference':{'path':'external-references/original-catalog-328.png','sha256':'f4ddb1e1084a79c371a2bd647bfa91a07dce4e9cd6a465b2dea407f84e1735db'},'actual_Main':False,'production_imported':False,'completed_added':0,'old_raw_files_not_duplicated':'RestoreWIP02bothpartsfirstintosameprefix; EXCLUDEDmanifestSHAresolvesoldraws. NoPNGproductionassembly.','diagnostic_videos':'ActualGodotticks VFRencoding withatomicphaselabel assertions; fullcaptureSHA+staticrepskept, loopPNGbodyexcluded.'}
original=Path('/workspace/twilight/assets/catalog/96c155500a24fa3048b0f5d0.png');items.append((prefix+'external-references/original-catalog-328.png',original.read_bytes()))
mapitems=[]
for p in sorted((b/'remaining-roles').rglob('*.generation.json'))+sorted((b/'walk-trial02').rglob('*.generation.json')):
 r=json.loads(p.read_text());raw=Path(r['raw_generated_path']);copy=Path(r['output_copy']);data=copy.read_bytes();assert raw.read_bytes()==data;mapitems.append({'original_tool_raw_path':str(raw),'included_path':prefix+str(copy.relative_to(b)),'sha256':digest(data),'byte_identical_raw_copy':True})
extras={'PORTABLE-INDEX-WIP03.json':metadata,'ALL-SOURCE-EVIDENCE-SHA256-WIP03.json':allsha,'EXCLUDED-CAPTURE-OR-OLD-WIP02-SHA256.json':excluded,'RAW-GENERATED-PATH-MAPPING-WIP03.json':mapitems,'README-PORTABLE-WIP03.txt':'RestoreWIP02compactpartsfirstandWIP03compactpartssametargetfolder. Read README-LATEST-WIP03.md and LATEST-WIP03-CHECKPOINT.json. AllnewrawPNG/exactprompts/failures included; olderrawretainedviaWIP02SHA. Full112rawcandidateNOTcompleted; independent8dir/proportion/registration/Main gatespending. No map/game/profile/importer edits bythisauthor. No assembledPNGproductionasset. Native slash/grounded behaviorpreserved. ZIPs arecontinuityevidence, notplayablegamebuild.\n'}
for name,v in extras.items():items.append((prefix+name,(v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode()))
manifest=[{'path':n,'bytes':len(d),'sha256':digest(d)} for n,d in items];items.append((prefix+'INCLUDED-FILES-SHA256-WIP03.json',(json.dumps(manifest,indent=2)+'\n').encode()))
parts=[];part=[];size=0
for item in items:
 if part and size+len(item[1])>44_000_000:parts.append(part);part=[];size=0
 part.append(item);size+=len(item[1])
if part:parts.append(part)
outputs=[]
for i,part in enumerate(parts,1):
 path=out/f'rabbit328-{label}-part{i:02d}.zip'
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
  for name,data in part:z.writestr(name,data)
 assert path.stat().st_size<50_000_000
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 outputs.append({'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path.read_bytes()),'entries':len(part)})
index={'label':label,'status':metadata['status'],'parts':outputs,'requires_WIP02_parts':oldindex['parts'],'new_raw_generation_records':len(mapitems),'all_evidence_files_hashed':len(allsha),'excluded_SHA_records':len(excluded),'Main':'not_run','completed_added':0};(out/f'rabbit328-{label}-archive-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps(index,indent=2))
