PARENT UPDATE: E4 pilot anatomy/identity/support/registration PASS. Expanding other7directions as a small WALK trial only; still no Main/fullroles/fullcompletion. Oldmovie label indexes were notatomic; latest registered-E-atomic-tempo8333 uses frame_changed/pre_draw/post_draw assertions and .48s gait period.

# transform:328 E single-pose method checkpoint

Current state: E four-phase authoring diagnostic is rendered, pending parent independent anatomy/loop review. This is not Main and adds zero completed actors. Remaining seven directions and all five roles are not approved. Do not expand eight directions until parent review.

Latest evidence:
- `E-opposite-support-proportion-edit.png`: true opposite-support endpoint B, after actual lower-limb edit.
- `E-passing2-proportion-edit.png`: genuine opposite passing phase; banded near front knee raised, plain far leg vertical support.
- `registered-E-fourphase/registered-pose-0.png` through `-3.png`: four actual Godot4.7.2 OpenGL captures.
- `registered-E-fourphase/registered-loop.mp4` and `.gif`: actual recorded Godot playback timing (6.72s encoded, 90 captured PNGs plus final held frame).
- `registered-E-fourphase/video-timing.json`: measured Time.get_ticks_msec timing; ffconcat is reproducible.
- `registered-E-fourphase/godot-preview.json`: runtime/renderer/actual-frame log; scratch scene, never Main.
- `review.json`, `checkpoint.json`, `generation-history.json`, `projected-anatomical-landmarks.json`.

The parent approved only the FIRST new pose's actual opposite physical leg topology. Proportion/registration/loop approval is still pending. No production import, profile, map or Main edits were made by this task.

Registration: world body rootx550, support baseliney600 fixed. Per-source anchorX derives from head/torso correspondences, never from forward toe. Old A / passing1 raw sheet uses virtualcanvas920, new singlepose2048 to match headscale; actual anatomical edits were made before this display normalization. Old passing1 defaultbboxcenter rootx768 caused28px torso drift; fixed metadatax736. All previous renders retained.

Corrections are honestly retained:
- First overall13%growth statement was based on arbitrary1024:2048canvases; it was not an anatomical measurement. Vertical hem-to-ground span also varies with knee articulation. See landmark files; projected manual joints are approximate, not a proportion PASS.
- First passing2 sole wasy1177; focused thigh/shin edit moved it toy1145. The requestedy1124 target was not met exactly. The final anchor uses actualy1145 rather than falsely claiming target contact.
- Initial ffmpeg30fps encodings compressed real6–7s captured playbacks to3s. These are retained under `initial-incorrect-30fps-timing.*`. Latest `registered-loop.*` uses actual recorded ticks via ffconcat. InputPNG artifacts are unchanged.

Exact raw generated images remain under `/workspace/generated_images/`; copies are byte-identical and hashed in generation-history. Prompts are saved before each call. Failed/first attempts, the three-phase preview, and first four-phase preview are preserved. Original catalog SHA and old E/W sheet SHA remain unchanged.

Reproduce the current scratch renderer only (requires DISPLAY:99 socket/network permission): set independent writable XDG_DATA_HOME/XDG_CONFIG_HOME/XDG_CACHE_HOME, then `/workspace/scratch/bin/godot-pr100 --path <this>/registered-E-fourphase --rendering-driver opengl3 --audio-driver Dummy --script res://preview.gd`. It writes90 new runtime capturePNG files and4 static frames to the same scratch directory, so copy the project to a new attempt directory and update OUTPUT/config references to preserve current evidence before rerunning. `encode_actual_capture_time.py` reproduces videos from recorded frame ticks; `finalize_E_checkpoint.py` regenerates checkpoint/manifests. Do not call the render as actualMain validation.
