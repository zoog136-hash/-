extends SceneTree
const OUTPUT := "/workspace/scratch/pr100-continuation/rabbit328-single-pose/registered-E-trial02-standalone"
const FLOOR := Vector2(550,600)
var actor: AnimatedSprite2D
var phase_label: Label
var config: Dictionary
var pre_draw_snapshot: Dictionary={}
class GroundGuide extends Node2D:
 func _draw() -> void:
  draw_rect(Rect2(0,0,1100,720),Color("343c49"))
  for x: int in range(0,1101,50):
   draw_line(Vector2(x,80),Vector2(x,625),Color("414958"),1)
  for y: int in range(100,626,50):
   draw_line(Vector2(0,y),Vector2(1100,y),Color("414958"),1)
  draw_line(Vector2(0,600),Vector2(1100,600),Color("f4c564"),2)
  draw_line(Vector2(550,150),Vector2(550,625),Color("916b45"),1)
  draw_circle(Vector2(550,600),3,Color("ff995e"))
func label_at(value: String, point: Vector2, size: int=18) -> Label:
 var label:=Label.new()
 label.text=value
 label.position=point
 label.add_theme_font_size_override("font_size",size)
 root.add_child(label)
 return label
func _initialize() -> void:
 Engine.max_fps=30
 call_deferred("run")
func normalize_frame() -> void:
 var spec: Dictionary=config.specs[actor.frame]
 actor.scale=Vector2.ONE*float(config.common_preview_canvas)/float(spec.canvas)
 if is_instance_valid(phase_label):
  phase_label.text="Phase %d / %d | %s | 8.333333 poses/s" % [actor.frame+1,config.specs.size(),spec.name]
func snapshot_before_draw() -> void:
 if is_instance_valid(actor) and is_instance_valid(phase_label):
  pre_draw_snapshot={"phase":actor.frame,"label":phase_label.text,"frame_progress":actor.frame_progress,"pre_draw_ticks_msec":Time.get_ticks_msec()}
func run() -> void:
 config=JSON.parse_string(FileAccess.get_file_as_string(OUTPUT+"/config.json"))
 root.add_child(GroundGuide.new())
 RenderingServer.frame_pre_draw.connect(snapshot_before_draw)
 var frames:=SpriteFrames.new()
 frames.remove_animation("default")
 frames.add_animation("E_diagnostic")
 frames.set_animation_loop("E_diagnostic",true)
 frames.set_animation_speed("E_diagnostic",8.333333333333334)
 var texture_cache: Dictionary={}
 for spec: Dictionary in config.specs:
  if not texture_cache.has(spec.path):
   var source:=Image.new()
   if source.load(spec.path)!=OK:
    push_error("Cannot read exact raw image "+spec.path)
    quit(1)
    return
   texture_cache[spec.path]=ImageTexture.create_from_image(source)
  var region: Array=spec.region
  var margin: Array=spec.margin
  var atlas:=AtlasTexture.new()
  atlas.atlas=texture_cache[spec.path]
  atlas.region=Rect2(region[0],region[1],region[2],region[3])
  atlas.margin=Rect2(margin[0],margin[1],margin[2],margin[3])
  atlas.filter_clip=true
  frames.add_frame("E_diagnostic",atlas)
 actor=AnimatedSprite2D.new()
 actor.sprite_frames=frames
 actor.animation="E_diagnostic"
 actor.position=FLOOR-Vector2(0,float(config.common_preview_canvas)/8.0)
 actor.frame_changed.connect(normalize_frame)
 root.add_child(actor)
 normalize_frame()
 label_at("AUTHORING DIAGNOSTIC ONLY | 328 E | NOT MAIN | no completion",Vector2(18,10),20)
 phase_label=label_at("",Vector2(18,40),17)
 label_at("Fixed body-root x550 / support sole y600 | unchanged raw source pixels",Vector2(18,642),18)
 label_at("Actual Godot SpriteFrames playback; anatomical proportions / registration unapproved",Vector2(18,674),17)
 var captures: Array=[]
 for index: int in range(config.specs.size()):
  actor.frame=index
  normalize_frame()
  phase_label.text="Phase %d / %d | %s" % [index+1,config.specs.size(),config.specs[index].name]
  await process_frame
  await RenderingServer.frame_post_draw
  var path:=OUTPUT+"/registered-pose-%d.png" % index
  if root.get_texture().get_image().save_png(path)!=OK:
   push_error("Cannot save capture")
   quit(1)
   return
  captures.append({"phase":index,"path":path,"source_anchor":config.specs[index].source_anchor,"actual_texture_size":actor.sprite_frames.get_frame_texture(actor.animation,index).get_size(),"actor_scale":actor.scale,"actor_position":actor.position})
 DirAccess.make_dir_recursive_absolute(OUTPUT+"/loop-frames")
 actor.frame=0
 actor.play("E_diagnostic")
 var playback: Array=[]
 for index: int in range(90):
  await process_frame
  # Label updates atomically in AnimatedSprite2D.frame_changed, never before animation processing.
  await RenderingServer.frame_post_draw
  var path:=OUTPUT+"/loop-frames/%03d.png" % index
  if root.get_texture().get_image().save_png(path)!=OK:
   push_error("Cannot save loop capture")
   quit(1)
   return
  assert(pre_draw_snapshot.phase==actor.frame)
  assert(pre_draw_snapshot.label.begins_with("Phase %d /" % (actor.frame+1)))
  playback.append({"capture":index,"phase":pre_draw_snapshot.phase,"frame_progress":pre_draw_snapshot.frame_progress,"ticks_msec":Time.get_ticks_msec(),"scale":actor.scale,"drawn_label":pre_draw_snapshot.label,"pre_draw_ticks_msec":pre_draw_snapshot.pre_draw_ticks_msec,"label_frame_signal_atomic":true})
 var report: Dictionary={"status":"rendered_diagnostic_only","engine":Engine.get_version_info(),"renderer":RenderingServer.get_video_adapter_name(),"registered_captures":captures,"loop_capture_count":playback.size(),"playback":playback,"source_pixels_modified":false,"actual_Main":false,"registration_approved":false,"anatomical_proportions_approved":false,"approval_scope":"FreshE2standalone redraw +previousB/passing2; independentfreshreviewpending, not8dir/Main/fullcompletion","animation_speed_poses_per_second":8.333333333333334,"cycle_duration_seconds":0.48,"label_capture_method":"Label updates in frame_changed; pre_draw snapshots phase+label; post_draw captures and asserts current matches.","completed_added":0}
 var file:=FileAccess.open(OUTPUT+"/godot-preview.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(report,"\t")+"\n")
 file.close()
 print("PR100_328_E_DIAGNOSTIC_OK ",captures.size()," registered PNG + ",playback.size()," loop frames")
 quit(0)
