from pathlib import Path
import json,hashlib,math,sys
sys.path.insert(0,"/workspace/twilight/tools")
import import_original_based_motion as motion
import numpy as np
from PIL import Image
from scipy.ndimage import label,find_objects
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');t=b/'eight-direction-walk-trial'
selected={'W':['A','passing1','B','passing2-phase-specific'],'S':['A-fit','passing1-fit','B','passing2'],'N':['A-cap-fix','passing1-fit','B','passing2-buckle-fix'],'SE':['A-phase-specific','passing1-phase-specific','B','passing2-phase-specific'],'NW':['A-phase-specific','passing1-cap-fix','B-phase-specific','passing2-moderate-focused'],'SW':['A-phase-specific','passing1-sw-kinematics','B-phase-specific','passing2-sw-kinematics'],'NE':['A-direction-identity','passing1-ne-locked','B-ne-locked','passing2-ne-locked']}
phase_names=['A','passing1','B','passing2'];out=[]
e=json.loads((b/'registered-E-fourphase/config.json').read_text())['specs']
for i,s in enumerate(e):out.append({'direction':'E','phase':phase_names[i],**s,'independent_E_pilot_approved':True})
for direction,names in selected.items():
 for i,name in enumerate(names):
  p=t/direction/(name+'.png');g=json.loads(p.with_suffix('.diagnostic.json').read_text());assert g['analyze_status']=='PASS' and g['complete_pose_regions_status']=='PASS'
  f=g['geometry']['frames'][0];a=np.asarray(Image.open(p));rgb=a[:,:,:3].astype(int);x,y,w,h=f['region'];max_y=y+int(h*.46)
  mask=(a[:,:,3]>100)&(rgb[:,:,0]>100)&(rgb[:,:,2]>rgb[:,:,0]*.88)&(rgb[:,:,1]>80)&((rgb.max(2)-rgb.min(2))<115)
  mask[:y+int(h*.20),:]=False;mask[y+int(h*.40):,:]=False
  ys,xs=np.where(mask);box=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)];center=(box[0]+box[2])/2
  rec={'direction':direction,'phase':phase_names[i],'path':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'region':f['region'],'canvas':2048,'source_anchor':[round(center),f['source_anchor'][1]],'hair_landmark':{'method':'Union brightlavender pixels in20%-40%bodyheightband, excludingearandcuffs. Hair outlinecanbe disconnectedbydarkstrands, solargest-componentmethodwasrejected. Readonlyregistrationproposal, notgroundtruth.','bbox':box,'width':box[2]-box[0],'height':box[3]-box[1],'center_x':center,'area':int(mask.sum())},'strict_geometry':'PASS','complete_visible_regions':'PASS','independent_pilot_approved':False,'origin':'New2Dauthoredsinglepose; exactrawbytes retained; nooriginalanimationextractionclaim'}
  out.append(rec)
# First diagnostic uses original2048sourcecanvas forallnew7dirs. No out-of-range reviewedcanvas or wholebody scaling to disguise anatomicalproportions.
vec={'E':1,'SE':2**-.5,'S':0,'SW':-2**-.5,'W':-1,'NW':-2**-.5,'N':0,'NE':2**-.5}
for r in out:
 if r['direction']!='E':
  direction=r['direction'];max_width=max(f['hair_landmark']['width'] for f in out if f['direction']==direction)
  requested=math.ceil((2048*r['hair_landmark']['width']/max_width)/8)*8
  dy=r['source_anchor'][1]-r['region'][1];required=math.ceil(dy/5)*8
  r['canvas']=min(2048,max(requested,required));r['resolution_normalization']={'method':'Uniform wholeframe source-resolution normalization from same-direction skull/hairwidth. DoesNOTchangeanatomicalhead/torso/limbratios. Mandatory2048maximum andfootfitguardretained; smallresidualheadvariationclampedratherthanrelaxingguard.','raw_hair_width':r['hair_landmark']['width'],'direction_max_hair_width':max_width,'requested_canvas':requested,'minimum_foot_fit_canvas':required,'chosen_canvas':r['canvas'],'residual_head_width_variance_to_direction_target':r['hair_landmark']['width']/r['canvas']/(max_width/2048)-1}
  r['source_anchor'][0]=round(r['hair_landmark']['center_x']-40*vec[r['direction']]*(r['canvas']/2048))
  verified=motion.analyze(Path(r['path']),rows_count=1,reference_rows=[0],directions_axis='columns',directions=[direction],canvas_size=r['canvas'],source_anchors=[r['source_anchor']]);motion.require_complete_pose_regions(Path(r['path']),verified);r['strict_reanalyze_manual_anchor_canvas']='PASS';r['verified_geometry']=verified
 c=r['canvas'];x,y,w,h=r['region'];ax,ay=r['source_anchor'];r['margin']=[c/2-(ax-x),c*5/8-(ay-y),c-w,c-h]
 assert min(r['margin'][:2])>=0
 assert r['margin'][0]+w<=c and r['margin'][1]+h<=c
 r['body_root_method']='E parentapprovedfixedmanualroots. Others readonlyhair correspondence minus40px projectedfacingoffset, actuallowestplantedsole authorchecked; diagnostic proposal, NOT toe-follow and NOT independentcontactapproval.'
order=['E','SE','S','SW','W','NW','N','NE'];out.sort(key=lambda r:(phase_names.index(r['phase']),order.index(r['direction'])))
hashes=[]
for r in out:
 im=Image.open(r['path']);x,y,w,h=r['region'];data=np.asarray(im)[y:y+h,x:x+w].copy();hashes.append(hashlib.sha256(data.tobytes()).hexdigest())
assert len(out)==32 and len(set(hashes))==32
report={'key':'transform:328','status':'SELECTED32_STATIC_WALK_CANDIDATE_PENDING_REGISTERED_ALLDIR_REVIEW','directions':order,'phases':phase_names,'selected_exact_distinct_crop_hashes':len(set(hashes)),'only_selected_used32poses':True,'source_pixels_modified':False,'scale_note':'E4parentapproved920/2048normalization unchanged. New7dirs use same-direction skull/hairwidth proportionalvirtualcanvas (all<=2048), wholeframeuniform source-resolution calibration only; hardfootfitclampsretainedandrecorded. DoesNOTchangeactualhead/torso/limbproportions; independentanatomicalreviewstillrequired.','frames':out,'new_completed':0,'production_imported':False,'Main':'not_run','all5roles':False,'finalusedsheet_ready':False}
(t/'selected32.json').write_text(json.dumps(report,indent=2)+'\n')
for d in order:
 print(d,[(r['phase'],r['source_anchor'],r.get('hair_landmark',{}).get('width'),r['region'][3]) for r in out if r['direction']==d])
