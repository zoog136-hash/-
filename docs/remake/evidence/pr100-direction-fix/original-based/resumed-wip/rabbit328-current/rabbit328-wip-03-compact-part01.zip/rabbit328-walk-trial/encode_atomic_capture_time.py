from pathlib import Path
import json,subprocess,statistics,hashlib
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose')
for name in ['registered-E-atomic-tempo8333']:
 p=b/name;report=json.loads((p/'godot-preview.json').read_text());frames=report['playback'];dt=[(frames[i+1]['ticks_msec']-frames[i]['ticks_msec'])/1000 for i in range(len(frames)-1)];last=statistics.median(dt)
 lines=['ffconcat version 1.0']
 for i,frame in enumerate(frames):
  lines.extend(["file 'loop-frames/%03d.png'"%i,'duration %.6f'%(dt[i] if i<len(dt) else last)])
 lines.append("file 'loop-frames/%03d.png'"%(len(frames)-1))
 concat=p/'actual-capture-timing.ffconcat';concat.write_text('\n'.join(lines)+'\n')
 for ext in ['mp4','gif']:
  current=p/('registered-loop.'+ext);previous=p/('initial-incorrect-30fps-timing.'+ext)
  if current.exists() and not previous.exists():current.rename(previous)
 mp4=p/'registered-loop.mp4'
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-safe','0','-f','concat','-i',str(concat),'-fps_mode','vfr','-c:v','libx264','-pix_fmt','yuv420p','-video_track_timescale','1000','-crf','18',str(mp4)],check=True)
 gif=p/'registered-loop.gif'
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-safe','0','-f','concat','-i',str(concat),'-vf','fps=15,scale=880:-1:flags=lanczos',str(gif)],check=True)
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,r_frame_rate,avg_frame_rate,nb_frames','-show_entries','format=duration','-of','json',str(mp4)]))
 details={'method':'FFmpeg concat per-capture durations from actual Godot Time.get_ticks_msec recorded after each frame capture. No fixed30fps assumption. Lastframe dwell uses median observed interval. Constant rate initial encodings preserved with incorrect-timing prefix.','observed_first_to_last_seconds':sum(dt),'last_dwell_seconds':last,'intended_display_duration_seconds':sum(dt)+last,'timing_source':'godot-preview.json playback ticks_msec','probe':probe,'mp4_sha256':hashlib.sha256(mp4.read_bytes()).hexdigest(),'gif_sha256':hashlib.sha256(gif.read_bytes()).hexdigest(),'source_PNGs_modified':False}
 (p/'video-timing.json').write_text(json.dumps(details,indent=2)+'\n');print(name,details['intended_display_duration_seconds'],probe['format'])
