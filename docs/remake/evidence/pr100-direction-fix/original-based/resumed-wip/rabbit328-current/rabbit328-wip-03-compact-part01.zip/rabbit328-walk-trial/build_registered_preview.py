import json, pathlib, hashlib
base=pathlib.Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose')
out=base/'registered-E-threephase'
out.mkdir(exist_ok=True)
old='/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/E-W/generated-E-W-walk.png'
specs=[
 {'name':'A near-banded forward support','path':old,'region':[159,24,242,481],'canvas':920,'source_anchor':[256,501],'origin':'Existing exact E endpoint A; no source pixel edits'},
 {'name':'passing1 near-banded stance / far-plain raised','path':old,'region':[668,26,204,480],'canvas':920,'source_anchor':[768,502],'origin':'Existing genuine passing phase; no source pixel edits'},
 {'name':'B near-banded back lifted / far-plain forward support','path':str(base/'E-opposite-support-proportion-edit.png'),'region':[361,75,590,1053],'canvas':2048,'source_anchor':[617,1124],'origin':'New single-pose edited artwork; never original animation extraction'}
]
for s in specs:
 s['source_sha256']=hashlib.sha256(pathlib.Path(s['path']).read_bytes()).hexdigest()
 c=s['canvas']; x,y,w,h=s['region']; ax,ay=s['source_anchor']
 s['margin']=[c/2-(ax-x),c*5/8-(ay-y),c-w,c-h]
config={'specs':specs,'common_preview_canvas':800,'fixed_world_body_root':[550,600], 'method':'Per-image virtual-canvas metadata matches face scale old57/920 ~ new127/2048. Source anchor X uses same body/head correspondence, not forward toe. Source anchor Y uses actual support sole. Pixels never scaled or modified on disk. Per-frame Sprite2D display normalization only.', 'body_root_note':'B root617 is inferred from face-center offset of A: 740.5-(311.5-256)*2048/920=616.95; pelvis correspondence also consistent. This registration remains diagnostic and unapproved.', 'actual_Main':False,'leg_proportions_approved':False,'completed_added':0}
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
(out/'project.godot').write_text('''config_version=5
[application]
config/name="PR100 328 E gait diagnostic preview"
[display]
window/size/viewport_width=1100
window/size/viewport_height=720
window/size/window_width_override=1100
window/size/window_height_override=720
[rendering]
renderer/rendering_method="gl_compatibility"
renderer/rendering_method.mobile="gl_compatibility"
textures/default_filters/use_nearest_mipmap_filter=false
''')
gd='''extends SceneTree
const OUTPUT := "__OUTPUT__"
const FLOOR := Vector2(550,600)
var actor: AnimatedSprite2D
var phase_label: Label
var config: Dictionary
class GroundGuide extends Node2D:
 func _draw() -> void:
  draw_rect(Rect2(0,0,1100,720),Color("343c49"))
  for x: int in range(0,1101,50):
   draw_line(Vector2(x,80),Vector2(x,625),Color("414958"),1)
  for y: int in range(100,626,50):
   draw_line(Vector2(0,y),Vector2(1100,y),Color("414958"),1)
  draw_line(Vector2(0,600),Vector2(1100,600),Color("f4c564"),2)
  draw_line(Vector2(550,150),Vector2(550,625),Color("916b45"),1)
  draw_circle(Vector2(550,600),3,Color("ff995e"))
func label_at(value: String, point: Vector2, size: int=18) -> Label:
 var label:=Label.new()
 label.text=value
 label.position=point
 label.add_theme_font_size_override("font_size",size)
 root.add_child(label)
 return label
func _initialize() -> void:
 Engine.max_fps=30
 call_deferred("run")
func normalize_frame() -> void:
 var spec: Dictionary=config.specs[actor.frame]
 actor.scale=Vector2.ONE*float(config.common_preview_canvas)/float(spec.canvas)
func run() -> void:
 config=JSON.parse_string(FileAccess.get_file_as_string(OUTPUT+"/config.json"))
 root.add_child(GroundGuide.new())
 var frames:=SpriteFrames.new()
 frames.remove_animation("default")
 frames.add_animation("E_diagnostic")
 frames.set_animation_loop("E_diagnostic",true)
 frames.set_animation_speed("E_diagnostic",6.25)
 var texture_cache: Dictionary={}
 for spec: Dictionary in config.specs:
  if not texture_cache.has(spec.path):
   var source:=Image.new()
   if source.load(spec.path)!=OK:
    push_error("Cannot read exact raw image "+spec.path)
    quit(1)
    return
   texture_cache[spec.path]=ImageTexture.create_from_image(source)
  var region: Array=spec.region
  var margin: Array=spec.margin
  var atlas:=AtlasTexture.new()
  atlas.atlas=texture_cache[spec.path]
  atlas.region=Rect2(region[0],region[1],region[2],region[3])
  atlas.margin=Rect2(margin[0],margin[1],margin[2],margin[3])
  atlas.filter_clip=true
  frames.add_frame("E_diagnostic",atlas)
 actor=AnimatedSprite2D.new()
 actor.sprite_frames=frames
 actor.animation="E_diagnostic"
 actor.position=FLOOR-Vector2(0,float(config.common_preview_canvas)/8.0)
 actor.frame_changed.connect(normalize_frame)
 root.add_child(actor)
 normalize_frame()
 label_at("AUTHORING DIAGNOSTIC ONLY | 328 E | NOT MAIN | no completion",Vector2(18,10),20)
 phase_label=label_at("",Vector2(18,40),17)
 label_at("Fixed body-root x550 / support sole y600 | unchanged raw source pixels",Vector2(18,642),18)
 label_at("Actual Godot SpriteFrames playback; anatomical proportions / registration unapproved",Vector2(18,674),17)
 var captures: Array=[]
 for index: int in range(config.specs.size()):
  actor.frame=index
  normalize_frame()
  phase_label.text="Phase %d / %d | %s" % [index+1,config.specs.size(),config.specs[index].name]
  await process_frame
  await RenderingServer.frame_post_draw
  var path:=OUTPUT+"/registered-pose-%d.png" % index
  if root.get_texture().get_image().save_png(path)!=OK:
   push_error("Cannot save capture")
   quit(1)
   return
  captures.append({"phase":index,"path":path,"source_anchor":config.specs[index].source_anchor,"actual_texture_size":actor.sprite_frames.get_frame_texture(actor.animation,index).get_size(),"actor_scale":actor.scale,"actor_position":actor.position})
 DirAccess.make_dir_recursive_absolute(OUTPUT+"/loop-frames")
 actor.frame=0
 actor.play("E_diagnostic")
 var playback: Array=[]
 for index: int in range(90):
  await process_frame
  phase_label.text="Phase %d / %d | 6.25 poses/s | root and sole fixed" % [actor.frame+1,config.specs.size()]
  await RenderingServer.frame_post_draw
  var path:=OUTPUT+"/loop-frames/%%03d.png" % index
  if root.get_texture().get_image().save_png(path)!=OK:
   push_error("Cannot save loop capture")
   quit(1)
   return
  playback.append({"capture":index,"phase":actor.frame,"frame_progress":actor.frame_progress,"ticks_msec":Time.get_ticks_msec(),"scale":actor.scale})
 var report: Dictionary={"status":"rendered_diagnostic_only","engine":Engine.get_version_info(),"renderer":RenderingServer.get_video_adapter_name(),"registered_captures":captures,"loop_capture_count":playback.size(),"playback":playback,"source_pixels_modified":false,"actual_Main":false,"registration_approved":false,"anatomical_proportions_approved":false,"completed_added":0}
 var file:=FileAccess.open(OUTPUT+"/godot-preview.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(report,"\\t")+"\\n")
 file.close()
 print("PR100_328_E_DIAGNOSTIC_OK ",captures.size()," registered PNG + ",playback.size()," loop frames")
 quit(0)
'''.replace('__OUTPUT__',str(out)).replace('%%03d','%03d')
(out/'preview.gd').write_text(gd)
print(out)
