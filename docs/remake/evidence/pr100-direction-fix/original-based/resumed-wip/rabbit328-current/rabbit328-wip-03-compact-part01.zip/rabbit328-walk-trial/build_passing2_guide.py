import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pathlib,json
b=pathlib.Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose')
fig,ax=plt.subplots(figsize=(7,7),dpi=160)
ax.set_xlim(-.7,.85);ax.set_ylim(-.13,1.4);ax.set_aspect('equal');ax.axis('off');ax.axhline(0,color='#333333',linewidth=2)
near=[[.03,1.02],[.36,.76],[.22,.40]]
far=[[-.03,1.00],[-.04,.55],[-.04,.10]]
ax.plot([0,0],[1.02,1.24],color='#777777',linewidth=5)
ax.plot(*zip(*far),color='#008fbb',linewidth=12,solid_capstyle='round',zorder=2)
ax.plot(*zip(*near),color='#b32a83',linewidth=12,solid_capstyle='round',zorder=3)
for pts,c,z in [(far,'#005c79',4),(near,'#761a56',5)]: ax.scatter(*zip(*pts),s=125,c=c,edgecolors='white',linewidths=1.2,zorder=z)
ax.plot([-.08,-.00,.22],[0,0,0],color='#008fbb',linewidth=11,solid_capstyle='round',zorder=2)
ax.plot([.19,.28,.47],[.33,.30,.30],color='#b32a83',linewidth=11,solid_capstyle='round',zorder=3)
ax.plot([.08,.16],[.98,.91],color='black',linewidth=13,zorder=8)
ax.annotate('FACING E / RIGHT',xy=(.62,1.29),xytext=(-.15,1.29),arrowprops={'arrowstyle':'->','lw':2},fontsize=14,weight='bold')
ax.annotate('NEAR / BANDED\nfront knee LIFTED',xy=(.22,.86),xytext=(.37,1.08),arrowprops={'arrowstyle':'->','color':'#b32a83'},fontsize=10,color='#761a56')
ax.annotate('FAR / PLAIN\nvertical SUPPORT',xy=(-.04,.55),xytext=(-.65,.65),arrowprops={'arrowstyle':'->','color':'#008fbb'},fontsize=10,color='#005c79')
ax.annotate('near boot raised\npoint RIGHT',xy=(.40,.30),xytext=(.45,.48),arrowprops={'arrowstyle':'->','color':'#b32a83'},fontsize=10,color='#761a56')
ax.annotate('far sole PLANTED',xy=(.13,0),xytext=(-.65,.15),arrowprops={'arrowstyle':'->','color':'#008fbb'},fontsize=10,color='#005c79')
ax.text(-.65,-.105,'KINEMATICS ONLY. Preserve the rabbit girl; no diagram colors or labels.',fontsize=8,color='#555555')
fig.savefig(b/'desired-E-passing2-guide.png',bbox_inches='tight',facecolor='white');plt.close(fig)
(b/'passing2-kinematic-guide.json').write_text(json.dumps({'near_banded_leg':near,'far_plain_leg':far,'source_pixels_modified':False,'purpose':'Genuine second passing phase, inverse support leg from existing passing1.'},indent=2)+'\n')
