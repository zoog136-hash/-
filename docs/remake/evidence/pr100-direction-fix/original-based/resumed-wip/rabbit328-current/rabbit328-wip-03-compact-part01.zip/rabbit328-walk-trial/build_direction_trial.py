from pathlib import Path
import math,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');out=b/'eight-direction-walk-trial';out.mkdir(exist_ok=True)
old='/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/'
source={'W':old+'E-W/generated-E-W-walk.png','S':old+'S-N/candidate.png','N':old+'S-N/candidate.png','SE':old+'SE-NW/generated.png','NW':old+'SE-NW/generated.png','SW':old+'SW-NE/generated-walk-SW-NE.png','NE':old+'SW-NE/generated-walk-SW-NE.png'}
facing={'W':(-1,0),'S':(0,1),'N':(0,-1),'SE':(.707,.707),'NW':(-.707,-.707),'SW':(-.707,.707),'NE':(.707,-.707)}
views={'W':'strict LEFT side profile. Face and both boot toes point screen LEFT. A genuinely newly drawn opposite-side view, not a horizontal mirror of E. The physical RIGHT banded leg is FAR from viewer, the plain LEFT leg is NEAR.', 'S':'straight FRONT view facing the viewer / screen DOWN. Both eyes, front bodice and front apron visible, boots toe toward viewer. Physical RIGHT banded leg is VIEWER-LEFT; plain LEFT leg is VIEWER-RIGHT.', 'N':'straight BACK view facing directly AWAY / screen UP. Back of cap and silver bob and compact purple back waist bow visible; NO eyes, face or cleavage. Boots point AWAY, heels toward viewer. Physical RIGHT banded leg is VIEWER-RIGHT; plain LEFT leg is VIEWER-LEFT.', 'SE':'FRONT-RIGHT THREE-QUARTER view facing screen DOWN-RIGHT. Both eyes/face and front bodice visible at oblique angle, nose and boot toes down-right. Physical RIGHT banded leg is near-side / viewer-left of hip; plain LEFT leg far-side / viewer-right.', 'NW':'BACK-LEFT THREE-QUARTER view facing screen UP-LEFT. Back of cap/hair, compact waist bow and leftward contour; NO frontal eyes or chest. Boots point up-left. Physical RIGHT banded leg is far-side toward viewer-right of hip; plain LEFT leg near-side toward viewer-left.', 'SW':'FRONT-LEFT THREE-QUARTER view facing screen DOWN-LEFT. Both eyes/face and front bodice visible at oblique angle, nose and boot toes down-left. Physical RIGHT banded leg is far-side / viewer-left of hip; plain LEFT leg near-side / viewer-right.', 'NE':'BACK-RIGHT THREE-QUARTER view facing screen UP-RIGHT. Back of cap/hair, compact waist bow and rightward contour; NO frontal eyes or chest. Boots point up-right. Physical RIGHT banded leg is near-side toward viewer-right of hip; plain LEFT leg far-side toward viewer-left.'}
states={
 'A':{'banded':[(.0,1.0),(.20,.57),(.43,.10)],'plain':[(.0,1.0),(-.18,.59),(-.38,.23)],'support':'banded','name':'banded RIGHT leg FORWARD planted; plain LEFT leg BACK lifted'},
 'passing1':{'banded':[(.0,1.0),(.0,.55),(-.01,.10)],'plain':[(.0,1.0),(.31,.82),(.20,.43)],'support':'banded','name':'banded RIGHT leg vertical SUPPORT; plain LEFT FRONT knee raised'},
 'B':{'banded':[(.0,1.0),(-.18,.59),(-.38,.23)],'plain':[(.0,1.0),(.20,.57),(.43,.10)],'support':'plain','name':'banded RIGHT leg BACK lifted; plain LEFT leg FORWARD planted'},
 'passing2':{'banded':[(.0,1.0),(.31,.82),(.20,.43)],'plain':[(.0,1.0),(.0,.55),(-.01,.10)],'support':'plain','name':'banded RIGHT FRONT knee raised; plain LEFT vertical SUPPORT'}
}
manifest=[]
for direction in facing:
 d=out/direction;d.mkdir(exist_ok=True);fx,fy=facing[direction];right=(-fy,fx)
 for phase,state in states.items():
  fig,ax=plt.subplots(figsize=(6,6),dpi=150);ax.set_xlim(-.85,.85);ax.set_ylim(-.2,1.5);ax.set_aspect('equal');ax.axis('off')
  lines={}
  for leg,sign in [('banded',1),('plain',-1)]:
   p=[]
   for forward,height in state[leg]:
    wx=fx*forward+right[0]*.12*sign;wy=fy*forward+right[1]*.12*sign;p.append([wx,height-wy*.35])
   lines[leg]=p
  support=state['support'];ankle=lines[support][-1];sole=[ankle[0],ankle[1]-.1];shift=-sole[1]
  for leg in lines:
   for pt in lines[leg]:pt[1]+=shift
  ax.axhline(0,color='#333333',linewidth=2)
  for leg in sorted(lines,key=lambda name: right[1]*(1 if name=='banded' else -1)):
   pts=lines[leg];color='#b32a83' if leg=='banded' else '#008fbb';ax.plot(*zip(*pts),color=color,linewidth=12,solid_capstyle='round');ax.scatter(*zip(*pts),s=100,c=color,edgecolors='white',zorder=5)
   ankle=pts[-1];by=ankle[1]-.1;ax.annotate('',xy=(ankle[0]+fx*.23,by-fy*.23*.35),xytext=(ankle[0]-.06*fx,by+.06*fy*.35),arrowprops={'arrowstyle':'->','lw':8,'color':color})
  p0,p1=lines['banded'][:2];a=[p0[i]*.78+p1[i]*.22 for i in range(2)];v=[p1[i]-p0[i] for i in range(2)];mag=math.hypot(*v);norm=[-v[1]/mag*.08,v[0]/mag*.08];ax.plot([a[0]-norm[0],a[0]+norm[0]],[a[1]-norm[1],a[1]+norm[1]],color='black',linewidth=14,zorder=9)
  ax.text(-.8,1.4,f'{direction} / {phase}',fontsize=17,weight='bold');ax.text(-.8,1.25,state['name'],fontsize=9);ax.text(-.8,1.14,'MAGENTA = physical RIGHT / BANDED\nCYAN = physical LEFT / PLAIN',fontsize=9);ax.text(-.8,-.15,'KINEMATICS ONLY. Preserve rabbit identity, not diagram colors.',fontsize=8)
  guide=d/(phase+'-kinematic-guide.png');fig.savefig(guide,bbox_inches='tight',facecolor='white');plt.close(fig)
  prompt=f'''Create ONE SINGLE full-body 2D authored animation pose of the exact Black Rabbit Girl transform328. It is newly drawn animation, never extracted original animation. Transparent alpha1254x1254, one figure only, no text/diagrams, ground, shadows, particles, detached fragments or cropped parts. Preserve generous margins, the same high-quality linework and coherent chibi anatomy as the first accepted reference. No wholebody reflection/mirroring or translated still.

References: FIRST accepted E anatomical/identity reference is the benchmark for exact cap/ear/hair/face/torso/leg proportions and costume, not the requested direction or pose. SECOND old direction sheet is ONLY the directional upperbody/cap/backbow appearance reference; ignore its failed repeated endpoints/band positions and background. THIRD tiny catalog is exact original identity. FOURTH abstract diagram is ONLY explicit hip-knee-ankle and physical leg identity, not its colors/proportions/clothes.

REQUIRED VIEW: {views[direction]}

REQUIRED SINGLE PHASE {phase}: {state['name']}. The physical RIGHT thigh ALWAYS owns the one black stocking band; the physical LEFT thigh is plain. Track actual continuous hip->knee->ankle->boot paths, not band repaint. The phase is opposite for A versus B and for passing1 versus passing2. {('Forward RIGHT leg has an extended hip/knee/ankle and planted sole. LEFT leg flexes backward and its heel/boot is visibly lifted.' if phase=='A' else 'Forward LEFT leg has an extended hip/knee/ankle and planted sole. RIGHT leg flexes backward and its heel/boot is visibly lifted.' if phase=='B' else 'RIGHT leg is nearly vertical beneath its own hip and planted. LEFT thigh swings forward to a clearly raised knee, shin folds downward/back, LEFT boot is raised.' if phase=='passing1' else 'LEFT leg is nearly vertical beneath its own hip and planted. RIGHT thigh swings forward to a clearly raised knee, shin folds downward/back, RIGHT boot is raised.')}

Draw two and only two connected stocking legs and two boots. Make genuine visible leg articulation for this facing direction; right/left hip continuity must remain clear through overlap. Show knees, ankles and shoe orientation correctly for view. Blackband stays on its own right thigh ABOVE its knee, never teleports to other leg. Both toes face requested direction. One actual support sole contacts an imaginary horizontal baseline, other boot visibly raised; no drawn baseline. Preserve original short skirt with black/white pleats and gold hem, dark fitted bodice/puffed sleeves, white cuffs, black gloves, silver-lilac bob, dark cap with bent rabbit ears/lilac inner and buckle, compact purple back bow, translucent gray stockings, black boots with WHITE insteps and purple ankle bows. Do not invent tail, weapons, exposed shorts or extra ribbons. Source face/head and upperbody size coherent with first reference: head/face must not shrink to hide excessively long legs; actual thigh and shin lengths match accepted source proportions. Modest arm/skirt response only. Fit cap through support sole aroundy75..1140 on same1254canvas, body-root nearx620; exact support coordinate is a target, not excuse to cut/scale anatomy. Keep visible-body height about1060, face height about125 if facing shows face. One genuine pose only, no sheet.'''
  pf=d/(phase+'.prompt.txt');pf.write_text(prompt+'\n')
  refs=[str(b/'E-opposite-support-proportion-edit.png'),source[direction],'/workspace/twilight/assets/catalog/96c155500a24fa3048b0f5d0.png',str(guide)]
  manifest.append({'direction':direction,'phase':phase,'prompt':str(pf),'reference_images':refs,'guide':str(guide),'state':state['name'],'requested_canvas':[1254,1254],'output_copy':str(d/(phase+'.png'))})
(out/'authoring-plan.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(manifest),'single-pose exact prompts and abstract kinematic guides ready')
