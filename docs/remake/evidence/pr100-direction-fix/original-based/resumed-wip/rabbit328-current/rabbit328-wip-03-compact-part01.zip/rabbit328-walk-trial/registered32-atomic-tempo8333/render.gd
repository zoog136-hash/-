extends SceneTree
const OUT: String="/workspace/scratch/pr100-continuation/rabbit328-single-pose/registered32-atomic-tempo8333"
const INPUT: String="/workspace/scratch/pr100-continuation/rabbit328-single-pose/eight-direction-walk-trial/selected32.json"
const DIRS: Array[String]=["E","SE","S","SW","W","NW","N","NE"]
const PHASES: Array[String]=["A","passing1","B","passing2"]
var selected: Dictionary
var textures: Dictionary={}
var actors: Array[AnimatedSprite2D]=[]
var phase_labels: Array[Label]=[]
var draw_snapshot: Array=[]
var pre_ticks: int=0
class GroundGuide extends Node2D:
 var dimensions:=Vector2(1600,800)
 var floors: Array[int]=[650]
 func _draw() -> void:
  draw_rect(Rect2(Vector2.ZERO,dimensions),Color("343c49"))
  for x: int in range(0,1601,50):
   draw_line(Vector2(x,65),Vector2(x,dimensions.y-35),Color("414958"),1)
  for y: int in range(100,int(dimensions.y)-35,50):
   draw_line(Vector2(0,y),Vector2(1600,y),Color("414958"),1)
  for y: int in floors:
   draw_line(Vector2(0,y),Vector2(1600,y),Color("f4c564"),2)
   for x: int in [200,600,1000,1400]:
    draw_line(Vector2(x,y-390),Vector2(x,y+16),Color("916b45"),1)
    draw_circle(Vector2(x,y),3,Color("ff995e"))
func _initialize() -> void:
 Engine.max_fps=30
 call_deferred("run")
func add_label(parent: Node,value: String,point: Vector2,size: int=18) -> Label:
 var result:=Label.new()
 result.text=value
 result.position=point
 result.add_theme_font_size_override("font_size",size)
 parent.add_child(result)
 return result
func record_for(direction: String,phase: int) -> Dictionary:
 for entry: Dictionary in selected.frames:
  if entry.direction==direction and entry.phase==PHASES[phase]:return entry
 assert(false,"Missing actual selected source pose")
 return {}
func atlas_for(entry: Dictionary) -> AtlasTexture:
 if not textures.has(entry.path):
  var image:=Image.new()
  assert(image.load(entry.path)==OK)
  textures[entry.path]=ImageTexture.create_from_image(image)
 var region: Array=entry.region
 var margin: Array=entry.margin
 var atlas:=AtlasTexture.new()
 atlas.atlas=textures[entry.path]
 atlas.region=Rect2(region[0],region[1],region[2],region[3])
 atlas.margin=Rect2(margin[0],margin[1],margin[2],margin[3])
 atlas.filter_clip=true
 return atlas
func make_viewport(dimensions: Vector2i,transparent: bool) -> SubViewport:
 var viewport:=SubViewport.new()
 viewport.size=dimensions
 viewport.transparent_bg=transparent
 viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS
 root.add_child(viewport)
 return viewport
func save_viewport(viewport: SubViewport,path: String) -> void:
 await process_frame
 await RenderingServer.frame_post_draw
 assert(viewport.get_texture().get_image().save_png(path)==OK)
func sync_actor(index: int) -> void:
 var actor: AnimatedSprite2D=actors[index]
 var entry: Dictionary=record_for(DIRS[index],actor.frame)
 actor.scale=Vector2.ONE*600.0/float(entry.canvas)
 phase_labels[index].text="%s / %s | 8.333 poses/s" % [DIRS[index],PHASES[actor.frame]]
func snapshot_before_draw() -> void:
 if actors.size()!=8:return
 draw_snapshot=[]
 pre_ticks=Time.get_ticks_msec()
 for i: int in range(8):
  draw_snapshot.append({"direction":DIRS[i],"phase_index":actors[i].frame,"phase":PHASES[actors[i].frame],"label":phase_labels[i].text,"frame_progress":actors[i].frame_progress})
func run() -> void:
 selected=JSON.parse_string(FileAccess.get_file_as_string(INPUT))
 assert(selected.frames.size()==32)
 # DIAGNOSTIC contact sheet ONLY, never a production asset or importer input.
 # Raw source PNG files remain byte-identical; normal Godot rendering is evidence only.
 var pack:=make_viewport(Vector2i(4096,2048),true)
 for phase: int in range(4):
  for direction: int in range(8):
   var entry: Dictionary=record_for(DIRS[direction],phase)
   var sprite:=Sprite2D.new()
   sprite.texture=atlas_for(entry)
   sprite.scale=Vector2.ONE*512.0/float(entry.canvas)
   sprite.position=Vector2(direction*512+256,phase*512+256)
   pack.add_child(sprite)
 await save_viewport(pack,OUT+"/DIAGNOSTIC-ONLY-32pose-contact-sheet.png")
 pack.queue_free()
 var strips: Array=[]
 for direction: String in DIRS:
  var viewport:=make_viewport(Vector2i(1600,800),false)
  var ground:=GroundGuide.new()
  viewport.add_child(ground)
  add_label(viewport,"AUTHORING DIAGNOSTIC ONLY | 328 %s | FOUR SELECTED WALK POSES | NOT MAIN"%direction,Vector2(16,8),20)
  for phase: int in range(4):
   var entry: Dictionary=record_for(direction,phase)
   var sprite:=Sprite2D.new()
   sprite.texture=atlas_for(entry)
   sprite.scale=Vector2.ONE*800.0/float(entry.canvas)
   sprite.position=Vector2(200+phase*400,650)-Vector2(0,100)
   viewport.add_child(sprite)
   add_label(viewport,"%s / %s"%[direction,PHASES[phase]],Vector2(phase*400+20,42),19)
   add_label(viewport,"root x%d | sole y650"%(200+phase*400),Vector2(phase*400+20,690),17)
  add_label(viewport,"Uniform source-resolution calibration only. Anatomical / hip identity / direction / floor review pending. No completed actor.",Vector2(16,748),17)
  var path: String=OUT+"/direction-"+direction+"-fourphase.png"
  await save_viewport(viewport,path)
  strips.append({"direction":direction,"capture":path,"actual_Main":false})
  viewport.queue_free()
 var overview:=make_viewport(Vector2i(1600,1000),false)
 var guide:=GroundGuide.new()
 guide.dimensions=Vector2(1600,1000)
 guide.floors=[440,940]
 overview.add_child(guide)
 add_label(overview,"328 / EIGHT DIRECTIONS / ACTUAL GODOT WALK TRIAL / NOT MAIN / COMPLETED +0",Vector2(12,7),20)
 for index: int in range(8):
  var frames:=SpriteFrames.new()
  frames.remove_animation("default")
  frames.add_animation(DIRS[index])
  frames.set_animation_speed(DIRS[index],8.333333333333334)
  frames.set_animation_loop(DIRS[index],true)
  for phase: int in range(4):frames.add_frame(DIRS[index],atlas_for(record_for(DIRS[index],phase)))
  var actor:=AnimatedSprite2D.new()
  actor.sprite_frames=frames
  actor.animation=DIRS[index]
  actor.position=Vector2(200+(index%4)*400,440+(index/4)*500)-Vector2(0,75)
  var caption:=add_label(overview,"",Vector2((index%4)*400+16,42+(index/4)*500),18)
  actors.append(actor)
  phase_labels.append(caption)
  actor.frame_changed.connect(sync_actor.bind(index))
  overview.add_child(actor)
  sync_actor(index)
 RenderingServer.frame_pre_draw.connect(snapshot_before_draw)
 var overview_static: Array=[]
 for phase: int in range(4):
  for index: int in range(8):
   actors[index].frame=phase
   sync_actor(index)
  var path: String=OUT+"/overview-phase-%d.png"%phase
  await save_viewport(overview,path)
  overview_static.append({"phase":PHASES[phase],"capture":path})
 DirAccess.make_dir_recursive_absolute(OUT+"/loop-frames")
 for index: int in range(8):
  actors[index].frame=0
  sync_actor(index)
  actors[index].play(DIRS[index])
 var playback: Array=[]
 for capture_index: int in range(64):
  await process_frame
  await RenderingServer.frame_post_draw
  assert(draw_snapshot.size()==8)
  for index: int in range(8):
   assert(draw_snapshot[index].phase_index==actors[index].frame)
   assert(draw_snapshot[index].label==phase_labels[index].text)
   assert(phase_labels[index].text.begins_with(DIRS[index]+" / "+PHASES[actors[index].frame]))
  var path: String=OUT+"/loop-frames/%03d.png"%capture_index
  assert(overview.get_texture().get_image().save_png(path)==OK)
  playback.append({"capture":capture_index,"ticks_msec":Time.get_ticks_msec(),"pre_draw_ticks_msec":pre_ticks,"drawn_actors":draw_snapshot.duplicate(true),"label_capture_atomic":true})
 var report: Dictionary={"status":"RENDERED_WALK32_DIAGNOSTIC_ONLY_PENDING_INDEPENDENT_REVIEW","engine":Engine.get_version_info(),"renderer":RenderingServer.get_video_adapter_name(),"diagnostic_contact_sheet":OUT+"/DIAGNOSTIC-ONLY-32pose-contact-sheet.png","diagnostic_cells":32,"only_selected_used_frames":true,"atlas_size":[4096,2048],"cell_canvas":[512,512],"phase_major_order":PHASES,"direction_order":DIRS,"source_input_manifest":INPUT,"direction_strips":strips,"overview_static":overview_static,"loop_capture_count":playback.size(),"animation_speed_poses_per_second":8.333333333333334,"cycle_seconds":0.48,"atomic_label_method":"frame_changedupdateslabel+scale; frame_pre_draw snapshots; post_draw asserts phase+label beforecapture","playback":playback,"source_pixels_modified":false,"diagnostic_render_only":true,"production_asset_created":false,"may_use_render_as_import_source":false,"anatomical_proportions_approved":false,"physical_leg_identity_approved_all8":false,"registration_approved_all8":false,"all5roles":false,"actual_Main":false,"production_imported":false,"completed_added":0}
 var file:=FileAccess.open(OUT+"/godot-preview.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(report,"\t")+"\n")
 file.close()
 print("RABBIT328_WALK32_RENDER_OK atlas32 strips8 overview4 loop",playback.size()," atomiclabels8/8 period.48 Mainfalse completed0")
 quit(0)
