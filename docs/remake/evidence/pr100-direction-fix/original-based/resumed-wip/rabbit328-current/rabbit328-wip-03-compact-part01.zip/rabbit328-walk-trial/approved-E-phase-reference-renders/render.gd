extends SceneTree
const OUTPUT="/workspace/scratch/pr100-continuation/rabbit328-single-pose/approved-E-phase-reference-renders"
const NAMES=["A","passing1","B","passing2"]
func _initialize() -> void:
 Engine.max_fps=30
 call_deferred("run")
func run() -> void:
 root.transparent_bg=true
 RenderingServer.set_default_clear_color(Color(0,0,0,0))
 var config: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(OUTPUT+"/config.json"))
 var sprite:=Sprite2D.new()
 root.add_child(sprite)
 var records: Array=[]
 for index: int in range(4):
  var spec: Dictionary=config.specs[index]
  var source:=Image.new()
  assert(source.load(spec.path)==OK)
  var atlas:=AtlasTexture.new()
  atlas.atlas=ImageTexture.create_from_image(source)
  var r: Array=spec.region
  var m: Array=spec.margin
  atlas.region=Rect2(r[0],r[1],r[2],r[3])
  atlas.margin=Rect2(m[0],m[1],m[2],m[3])
  atlas.filter_clip=true
  sprite.texture=atlas
  sprite.scale=Vector2.ONE*2048.0/float(spec.canvas)
  sprite.position=Vector2(627,1140)-Vector2(0,256)
  await process_frame
  await RenderingServer.frame_post_draw
  var path: String=OUTPUT+"/E-"+NAMES[index]+"-reference.png"
  assert(root.get_texture().get_image().save_png(path)==OK)
  records.append({"phase":NAMES[index],"output":path,"source":spec,"rendered_only_for_imagegen_kinematic_reference":true,"new_authored_pose":false,"original_source_pixels_modified":false})
 var file:=FileAccess.open(OUTPUT+"/render-provenance.json",FileAccess.WRITE)
 file.store_string(JSON.stringify({"engine":Engine.get_version_info(),"transparent_viewport":true,"purpose":"Render existing approved E4 phases for phase-specific imagegen reference. No new motion or original extraction claim.","records":records},"\t")+"\n")
 file.close()
 print("E_PHASE_REFERENCE_RENDER_OK 4")
 quit(0)
