from pathlib import Path
import hashlib,json,zipfile,datetime
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');out=Path('/workspace/scratch/pr100-continuation/rabbit328-portable');out.mkdir(exist_ok=True)
label='wip-02-compact';prefix='rabbit328-walk-trial/'
excluded=[];items=[];allsha=[]
for p in sorted(b.rglob('*')):
 if not p.is_file() or '.godot' in p.parts or any(x.startswith('xdg-') for x in p.parts) or 'mplconfig' in p.parts:continue
 data=p.read_bytes();rel=str(p.relative_to(b));entry={'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};allsha.append(entry)
 if ('loop-frames' in p.parts and p.suffix=='.png') or p.suffix=='.gif':excluded.append({**entry,'reason':'Redundant diagnostic capturebody excluded; full SHA/provenance/representative static captures and actualtimingvideo retained.'});continue
 items.append((prefix+rel,data))
external=[
 '/workspace/twilight/assets/catalog/96c155500a24fa3048b0f5d0.png',
 '/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/E-W/generated-E-W-walk.png',
 '/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/S-N/candidate.png',
 '/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/SE-NW/generated.png',
 '/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/SW-NE/generated-walk-SW-NE.png',
 '/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resume-20261015/rabbit328-wip/focused-walk/independent-review.json',
 '/workspace/twilight/tools/import_original_based_motion.py',
 '/workspace/scratch/pr100-continuation/dancing-sword-authoring/analyze_stage.py']
mapping=[]
for original in external:
 p=Path(original);data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();target=prefix+'external-references/'+sha[:16]+'-'+p.name;items.append((target,data));mapping.append({'original_absolute_path':original,'package_path':target,'bytes':len(data),'sha256':sha})
for p in sorted((b/'eight-direction-walk-trial').rglob('*.generation.json')):
 r=json.loads(p.read_text());mapping.append({'original_absolute_path':r['raw_generated_path'],'package_path':prefix+str(Path(r['output_copy']).relative_to(b)),'sha256':hashlib.sha256(Path(r['output_copy']).read_bytes()).hexdigest(),'meaning':'Generatedraw andsavedcopy exactbytes; map oldabsolute raw path to includedPNG.'})
selection=json.loads((b/'eight-direction-walk-trial/selected32.json').read_text())
meta={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'WIP_ONLY_E_PILOT_PARENT_PASS_WALK32_RENDERED_8DIR_REVIEW_PENDING','Main':'not_run','new_completed':0,'no_repo_production_edits_by_this_authoring_task':True,'selected_frame_plan':selection,'current_gen_record_count':len(list((b/'eight-direction-walk-trial').rglob('*.generation.json'))),'raw_failures_preserved_included':True,'known_evidence_gap':'One NWmoderate raw was displayed but output_hint/localfile notavailable aftertransporterror; explicitfailureJSON included, cannot falsely claimthatrawretained. Latermoderatereplacement rawsaved.','path_mapping':mapping,'excluded_redundant_capture_png_count':sum(x['path'].endswith('.png') for x in excluded),'excluded_duplicate_GIF_derivatives':sum(x['path'].endswith('.gif') for x in excluded),'diagnostic_render_is_not_import_source':True,'walk32_frozen':True,'included_rawPNG_note':'All persisted raw PNG for32 selected poses plus failed/revised attempts included; walk32 frozen. 8direction registered diagnostic render complete, independently approved E4 only. No production assembled PNG. GIF excluded withSHA; MP4/static included.','runtime_timing_note':'Old6.25sprite-labelmovies haveoccasionalframemismatch; latest32pose atomic8.333 signal/pre_draw/post_draw logs64captures times8actors=512matchinglabel assertions; separate Eatomic evidence90captures. MP4timingusesactualticks, notfixed30fpsassumption.'}
extras={'PORTABLE-INDEX.json':meta,'ALL-SOURCE-EVIDENCE-SHA256.json':allsha,'EXCLUDED-CAPTURE-BODIES-SHA256.json':excluded,'README-PORTABLE.txt':'WIP transform328 rabbitwalk only. E4 anatomy/identity/support/registration pilot passedparentreview; sevenotherdirections notapproved. NoMain/fullroles/completedactorclaim. ReadPORTABLE-INDEX andeight-direction-walk-trial/checkpoint.json. All persistedrawimages/prompts/failures + exactsourceSHA/pathmapping included. ZIPparts formonefoldertree; extractalltothesamefolder. Absolute sourcepaths arehistorical; usepath_mapping toresolveincludedcopies. Restoreproject OUTPUT/configpaths tothisnewfolder beforeGodotdiagnostics. RequiredGodot4.7.2 notincluded; rootruntimechecksprovideenginechecksum. Whole-role importer min2/partition/visible-regionguards areunchanged.\n'}
for name,value in extras.items():items.append((prefix+name,(value if isinstance(value,str) else json.dumps(value,indent=2)+'\n').encode()))
filemanifest=[{'package_path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for path,data in items];items.append((prefix+'INCLUDED-FILES-SHA256.json',(json.dumps(filemanifest,indent=2)+'\n').encode()))
parts=[];current=[];size=0
for item in items:
 if current and size+len(item[1])>44_000_000:parts.append(current);current=[];size=0
 current.append(item);size+=len(item[1])
if current:parts.append(current)
outputs=[]
for i,part in enumerate(parts,1):
 z=out/f'rabbit328-{label}-part{i:02d}.zip'
 with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
  for path,data in part:archive.writestr(path,data)
 assert z.stat().st_size<50_000_000
 with zipfile.ZipFile(z) as archive:assert archive.testzip() is None
 outputs.append({'path':str(z),'bytes':z.stat().st_size,'sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'entries':len(part)})
index={'label':label,'status':meta['status'],'parts':outputs,'excluded_redundant_capture_PNGs':sum(x['path'].endswith('.png') for x in excluded),'excluded_duplicate_GIFs':sum(x['path'].endswith('.gif') for x in excluded),'source_evidence_files_hashed':len(allsha),'Main':'not_run','new_completed':0}
(out/f'rabbit328-{label}-archive-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps(index,indent=2))
