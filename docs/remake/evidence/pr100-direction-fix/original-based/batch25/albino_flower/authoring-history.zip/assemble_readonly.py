from pathlib import Path
import json,sys,hashlib,math
from PIL import Image
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
out=Path(__file__).resolve().parent
specs=[
 ('idle-walk-E-SE-narrow',['E','SE'],5,{'idle':[0,1],'walk':[2,3,4]},[0,1]),
 ('idle-walk-S-SW-facingfix',['S','SW'],5,{'idle':[0,1],'walk':[2,3,4]},[0,1]),
 ('idle-walk-W-NW-narrow',['W','NW'],5,{'idle':[0,1],'walk':[2,3,4]},[0,1]),
 ('idle-walk-N-NE-narrow',['N','NE'],5,{'idle':[0,1],'walk':[2,3,4]},[0,1]),
 ('attack-E-SE-spaced',['E','SE'],3,{'attack':[0,1,2]},[2]),
 ('attack-S-SW-facingfix',['S','SW'],3,{'attack':[0,1,2]},[2]),
 ('attack-W-NW-spaced',['W','NW'],3,{'attack':[0,1,2]},[2]),
 ('attack-N-NE-backfix',['N','NE'],3,{'attack':[0,1,2]},[2]),
 ('hit-death-E-SE-narrow',['E','SE'],5,{'hit':[0,1],'death':[2,3,4]},[1]),
 ('hit-death-S-SW-narrow',['S','SW'],5,{'hit':[0,1],'death':[2,3,4]},[1]),
 ('hit-death-W-NW-narrow',['W','NW'],5,{'hit':[0,1],'death':[2,3,4]},[1]),
 ('hit-death-N-NE-narrow',['N','NE'],5,{'hit':[0,1],'death':[2,3,4]},[1]),
]
basis=json.load(open(out/'idle-walk-E-SE-narrow-geometry.json'))['neutral_height']/640
sheets=[];checks=[];frames=[];roles={role:{d:[] for d in m.DIRECTIONS} for role in m.ROLES};visible=[];raw=[];errors=[]
for i,(slug,dirs,n,rs,refs) in enumerate(specs):
 path=out/(slug+'.png');baseline=m.analyze(path,rows_count=n,reference_rows=refs,canvas_size=1024,directions=dirs)
 desired=max(64,int(round((baseline['neutral_height']/basis)/8)*8));canvas=desired
 while True:
  try:g=m.analyze(path,rows_count=n,reference_rows=refs,canvas_size=canvas,directions=dirs);break
  except ValueError as exc:
   if str(exc)=='Pose cannot fit the foot-anchored canvas' and canvas<2048:canvas+=8;continue
   raise
 m.require_complete_pose_regions(path,g)
 anchors=[f['source_anchor'] for f in g['frames']]
 # Revalidate exact integer per-pose anchor metadata, preserving image bytes.
 g=m.analyze(path,rows_count=n,reference_rows=refs,canvas_size=canvas,source_anchors=anchors,directions=dirs);m.require_complete_pose_regions(path,g)
 with Image.open(path) as im:
  pixels=np.asarray(im)
  for f in g['frames']:
   x,y,w,h=f['region'];visible.append(m._visible_pose_fingerprint(pixels[y:y+h,x:x+w]));raw.append(f['rgba_sha256'])
 offset=len(frames)
 for f in g['frames']:f['sheet']=i
 frames.extend(g['frames'])
 for role,rows in rs.items():
  for j,d in enumerate(dirs):
   if roles[role][d]:errors.append('duplicate_role_direction:'+role+'/'+d)
   roles[role][d]=[offset+row*len(dirs)+j for row in rows]
 note=('PROVISIONAL geometry-only canvas: neutral/recovery body-height normalization versus E/SE idle canvas640; '
       f'calculated{desired}, safe-foot-fit{canvas}. Source pixels unchanged. Per-pose anchors are original default column/lowest-opaque contact candidates, not final anatomical support approval. '
       'Head/petal/stalk proportion matching and ground contact require independent rendered review and actual Main before approval.')
 sheets.append({'output_path':str(path),'directions':dirs,'directions_axis':'columns','rows':n,'reference_rows':refs,'roles':rs,'canvas_size':canvas,'source_anchors':anchors,'scale_review_note':note})
 checked={'slug':slug,'source':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'image_size':g['image_size'],'directions':dirs,'roles':rs,'unique_poses':g['distinct_pixel_frames'],'strict_analyze':'pass','complete_visible_pixels':'pass','explicit_anchor_preflight':'pass','provisional_canvas':canvas,'neutral_reference_height_pixels':g['neutral_height']};checks.append(checked)
 (out/(slug+'-assembled-geometry.json')).write_text(json.dumps(g,indent=2)+'\n')
for role in m.ROLES:
 for d in m.DIRECTIONS:
  if not roles[role][d]:errors.append('missing_role_direction:'+role+'/'+d)
if len(raw)!=104 or len(set(raw))!=104 or len(set(visible))!=104:errors.append('104_unique_pose_guard')
used=[]
for role in m.ROLES:
 for d in m.DIRECTIONS:used.extend(roles[role][d])
if len(used)!=104 or len(set(used))!=104:errors.append('mandatory_pose_reuse_or_missing')
source=Path('/workspace/twilight/assets/monsters/original/atlas_4.png');source_sha=hashlib.sha256(source.read_bytes()).hexdigest();expected='a61ece92aeaa0dabd485fb724aa968cebb1dca4d6559cef50e26d62bf993f127'
if source_sha!=expected:errors.append('original_source_sha')
record=json.load(open(out/'authoring-record.json'))
prompts={p.name:p.read_text() for p in sorted(out.glob('*exact-prompt.txt'))}
candidate={'key':'monster:알비노 플라워','prompt':json.dumps(prompts,ensure_ascii=False,indent=2),'prompt_record_kind':'exact_prompts_for_initial_failed_sheets_narrow_subsets_and_focused_corrections','sheets':sheets,'review':{'identity_preserved':True,'eight_views':False,'motion_roles':True,'no_clipping':True,'notes':'Own static inspection: ivory/red-veined toothed blossom, attached pink tongue, green/brown root-stalk and root limbs preserved; distinct root-crawl/bite/recoil and progressive attached low wilted corpse authored. All104 geometric/crop/visible uniqueness guards pass. NOT independent final approval: SW neutral/windup heading remains ambiguous to this author, and N versus NE attack contact reach requires parent review; explicit anchors/canvases are provisional. Actual Main, attack target contact, full playback and scale comparison unrun. Do not turn eight_views true until independent review passes.'},'status':'FULL104_GEOMETRY_PASS_PENDING_INDEPENDENT_VISUAL_REVIEW','source_claim':'New2D artwork from existing project atlas; not extracted original animation. Exact original region and SHA remain unchanged; same-atlas wholebody-context supplemental reference only.','actual_Main':'not_run','completed_added':0}
(out/'candidate.json').write_text(json.dumps(candidate,ensure_ascii=False,indent=2)+'\n')
review={'status':'STATIC_REVIEW_REQUIRES_INDEPENDENT_DIRECTION_AND_RENDERED_APPROVAL','static_passes':['Original ivory petals/red veins/dark toothed mouth/attached pink tongue/woody green-brown rootbody retained; no invented humanoid limbs or weapons.','Distinct actual root-joint/bend/overlap changes across locomotion candidates, no identical rendered poses.','Bite windup/contact/recovery visibly differ; sourcebody remains attached to rootbase.','All8directions have2hit and3death poses; final corpse is low grounded wilted complete flower/stalk/rootmass.','Corrected N/NE attack contact no longer displays full frontal mouth; rear sepals/petals remain visible.','All104 strict pose-region/unique-visible/mandatory-role coverage checks pass with unchanged source bytes.'],'unresolved':['SW idle neutral and attack windup orientation remains ambiguous: curled tongue projects right while latercontact points left; independent review must decide wholehead orientation, not tongue-tip alone.','N/NE attack corrected rearcontact bends to screenright and may not sufficiently distinguish true north/up reach from NE; actualMain target-contact review required.','Canvas normalization is provisional neutral/recovery fullbody-height geometry. Petal/head/stalk proportion consistency across different source resolutions and supporting-root ground anchors need rendered comparison.','Hiddenalpha0RGB and sparse lowalpha antialiasing require proper checker/white/black composition; raw PNG display background is not proof of opaque matte.','No actual Main or existing highquality completed actor comparison performed by this author.'],'actual_Main':'not_run','runtime_connected':False,'completed_added':0}
(out/'static-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
guards={'status':'PASS_GEOMETRIC_PREFLIGHT_NOT_FINAL_VISUAL_APPROVAL' if not errors else 'FAIL','total_poses':len(frames),'unique_raw_crop_poses':len(set(raw)),'unique_visible_poses':len(set(visible)),'mandatory_pose_assignment_count':len(used),'mandatory_unique_assignment_count':len(set(used)),'role_direction_counts':{r:{d:len(ids) for d,ids in row.items()} for r,row in roles.items()},'errors':errors,'sheets':checks,'original_reference_sha256':source_sha,'original_reference_sha_matches':source_sha==expected,'source_pixels_modified':False,'guard_thresholds_changed':False,'production_files_modified':False,'importer_apply':'not_run; candidate eight_views flag false pending parent visual approval','actual_Main':'not_run','completed_added':0}
(out/'full104-guard-report.json').write_text(json.dumps(guards,ensure_ascii=False,indent=2)+'\n')
record['active_checkpoint']={'stage':'full104 read-only preflight complete; candidate ready for independent QA','candidate':str(out/'candidate.json'),'guard_report':str(out/'full104-guard-report.json'),'static_review':str(out/'static-review.json'),'strict_geometric_status':guards['status'],'next':'Independent directional/contact/scale/anchor review; do not approve/import blindly; parent Main afterward','completed_added':0};record['selected_sheets']=checks
for p in out.glob('*exact-prompt.txt'):record['prompts'][p.stem]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'authoring-record.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':guards['status'],'total_poses':len(frames),'unique_visible':len(set(visible)),'errors':errors,'canvases':[s['canvas_size'] for s in sheets],'candidate':str(out/'candidate.json'),'review':str(out/'static-review.json')},ensure_ascii=False))
