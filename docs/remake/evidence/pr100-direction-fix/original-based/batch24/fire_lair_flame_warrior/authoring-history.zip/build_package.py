import hashlib,json,pathlib,sys,datetime
import numpy as np
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
b=pathlib.Path('/workspace/scratch/pr100-continuation/fire-warrior-authoring')
source=next(c for c in json.loads((b.parent/'candidate-selection.json').read_text())['candidates'] if c['key']=='monster:화룡의 둥지 화염전사')
configs=[
 ('idle-walk-final-front-half',5,['E','SE','S','SW'],{'idle':[0,1],'walk':[2,3,4]},512),
 ('idle-walk-final-rear-half',5,['W','NW','N','NE'],{'idle':[0,1],'walk':[2,3,4]},512),
 ('attack-front-half',3,['E','SE','S','SW'],{'attack':[0,1,2]},640),
 ('attack-rear-half',3,['W','NW','N','NE'],{'attack':[0,1,2]},640),
 ('hit-death-front-half',5,['E','SE','S','SW'],{'hit':[0,1],'death':[2,3,4]},512),
 ('hit-death-rear-half',5,['W','NW','N','NE'],{'hit':[0,1],'death':[2,3,4]},512)]
sheets=[];probes=[];hashes=[];visible_hashes=[];complete_pass_pose_count=0
role_counts={role:{d:0 for d in m.DIRECTIONS} for role in ['idle','walk','attack','hit','death']}
for name,rows,dirs,roles,canvas in configs:
 p=b/(name+'.png');g=m.analyze(p,rows_count=rows,directions_axis='columns',directions=dirs,canvas_size=canvas,reference_rows=[0,1])
 probe={'name':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'analyze_status':'PASS','frames':len(g['frames']),'canvas_size':canvas,'neutral_height':g['neutral_height'],'directions':dirs,'geometry':g,'anchors_manually_approved':False}
 try:m.require_complete_pose_regions(p,g);probe['complete_pose_regions']='PASS';complete_pass_pose_count+=len(g['frames'])
 except Exception as e:probe['complete_pose_regions']='FAIL';probe['complete_pose_regions_error']=str(e)
 im=Image.open(p);a=np.asarray(im);covered=np.zeros(a.shape[:2],bool)
 for f in g['frames']:
  x,y,w,h=f['region'];covered[y:y+h,x:x+w]=True;hashes.append(f['rgba_sha256']);visible_hashes.append(m._visible_pose_fingerprint(a[y:y+h,x:x+w]))
 probe['alpha_gt100_omitted_pixels']=int(((a[:,:,3]>100)&~covered).sum())
 probe['alpha_1_to100_outside_regions_pixels']=int(((a[:,:,3]>0)&(a[:,:,3]<=100)&~covered).sum())
 probe['max_region_width_to_cell_ratio']=round(max(f['region'][2]/(im.width/len(dirs)) for f in g['frames']),3)
 probe['max_region_height_to_cell_ratio']=round(max(f['region'][3]/(im.height/rows) for f in g['frames']),3)
 probe['requested_40_to45percent_cell_density_met']=probe['max_region_width_to_cell_ratio']<=.45 and probe['max_region_height_to_cell_ratio']<=.45
 (b/(name+'.final-geometry.json')).write_text(json.dumps(probe,ensure_ascii=False,indent=2)+'\n')
 probes.append({k:v for k,v in probe.items() if k!='geometry'})
 for role,indices in roles.items():
  for d in dirs:role_counts[role][d]+=len(indices)
 sheets.append({'output_path':str(p),'rows':rows,'roles':roles,'directions_axis':'columns','directions':dirs,'canvas_size':canvas,'source_anchors':[f['source_anchor'] for f in g['frames']], 'source_anchors_approved':False,'scale_review_note':f'Diagnosticonly: sourcePNG{im.width}x{im.height}, neutralheight{g["neutral_height"]:.1f}px, virtualcanvas{canvas}px. Canonicalsource86px/floatingtrue. Perrolehead/anatomy/canvasratio and individualbody-baseanchors are not approved; independentreview and actualMain required.','exact_prompt_path':str(b/(name+'.prompt.txt')),'sha256':probe['sha256']})
source_path=pathlib.Path('/workspace/twilight')/source['reference']['path'].removeprefix('res://')
actual_source_hash=hashlib.sha256(source_path.read_bytes()).hexdigest();assert actual_source_hash==source['reference']['sha256']
records=json.loads((b/'generation-records.json').read_text())
for record in records:
 p=b/record['unchanged_copy'];original=pathlib.Path(record['generated_path']);record.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),unchanged_from_generated=hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(original.read_bytes()).digest())
 assert record['unchanged_from_generated']
(b/'generation-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
review={'status':'HOLD_NOT_IMPORTABLE','subject':source['key'],'newly_authored_2D_not_original_animation_extraction':True,'source':source['reference'],'supplementary_context':source['wholebody_context_png'],'source_context_limit':'Same-atlas additionalview restores realcrown tip; exactreferencepath/region/SHA unchanged. Ignore unrelatedpartialneighbor in exactregion.','source_sha_unchanged':actual_source_hash,'effective_record_settings':source['effective_record_settings'],'anatomy':'Existingflamehead/white-hoteyes/angularhumanoidupperbody/twoconnectedclawarms/oneattachedfirevortex; nolegs/feet invented. Alivefloatingtrue and magic attack retained as required settings, no productionchanges.', 'proposed_pose_slots':104,'global_exact_crop_hashes':len(set(hashes)),'global_visible_pose_hashes':len(set(visible_hashes)),'all5role8direction_counts':role_counts,'analyze_pass_pose_slots':sum(p['frames'] for p in probes),'complete_visible_region_pass_pose_slots':complete_pass_pose_count,'full_complete_visible_region_gate_passed':complete_pass_pose_count==104,'strict_probes':probes,'author_visual_findings':[
 'Persistent finalfrontsheet directionfailure: row5 columnE (travelC) turns LEFT/W while earlierE phasesfaceRIGHT/E. Do not count a correctEwalkcycle.',
 'Initial8column40sheet incorrectly showedface inN column; preserved as rejectedattempt. First2directionsubsetcorrection had diffuse lowalphahaze; S/N subsetalso failed safecrop and NtravelC becamefrontal.',
 'Finalfront idle/travel sheet leaves13 alpha>100 pixels outsideallstrictpose regions. Do not trim, ignore or inventownership. Reauthor exactsheet/pose before import.',
 'Allgeneratedsheets remain muchdenser than requested40-45percentcelloccupancy. Inspect fringing and interposegutters before acceptance.',
 'FinalrearN head/back hidesface consistently in displayedfullsheet. Diagonalrear and exactE/Wcardinalprofile fidelity still requireindependentQA; no8viewapproval given.',
 'Attack visiblychanges gatherclaws -> extendedclaws -> loweredrecovery. S/N handspread/release vector and eventual actualprojectile alignment remain for independentMainreview.',
 'Hit has two visiblydifferent torso/armrecoils. Death progresses fromdroop tolowcoil tocoherentflattenedvisiblebody, not emptyextinction or detachedscatter. Terminalbaseanchors not yet manuallyapproved.',
 '512canvas failed frontattack fit;640canvas passed without pixel edits. Bothattackhalves now share640diagnosticcanvas, otherroles512. Crossrolehead/anatomyscale not approved.'
 ],'anchors':{'status':'DIAGNOSTIC_ONLY_NOT_MANUALLY_APPROVED','method':'Existingstrictanalyze defaultbodybboxbottom withneutralcolumncenter, no inventedfeet. All104coordinatepairs preservedin candidate; parent must verify actualvortexbase/terminalcorpsecontact individually.','floating_alive':True,'terminal_death_should_be_grounded':True},'Main':'not_run','production_imported':False,'runtime_connected':False,'map_modified':False,'completed_added':0,'next':'IndependentQA mayreview full104set. Reauthor frontidle/travel (EtravelC heading and13outsidepixels), cleanup anyvisiblefringe, review8views/anatomyscale/anchors, then existingmandatorypipeline before Main. Do not partiallyimport or countsucceed.'}
(b/'specimen-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
exact_prompts=[{'file':str(b/r['exact_prompt']),'text':(b/r['exact_prompt']).read_text()} for r in records]
candidate={'key':source['key'],'prompt_record_kind':'exact_prompts','prompt':'Full exactprompt history is embedded below; selected6sheets drawn as new2D reference-basedmotion. HOLD; no originalanimation extraction claim.','exact_prompts':exact_prompts,'sheets':sheets,'review':{'identity_preserved':True,'eight_views':False,'motion_roles':False,'no_clipping':False,'notes':'HOLD: finalEtravelC reversesheading; frontidle/travel has13outsidevisiblepixels. Densepacking/fringing, crossrolescale andanchors requireindependentQA.104slotcount/uniquehashes do not provegenuineanimationquality. See specimen-review.json.'},'status':'HOLD_NOT_IMPORTABLE','Main':'not_run','production_imported':False,'completed_added':0}
(b/'candidate-wip.json').write_text(json.dumps(candidate,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in review.items() if k in ['status','proposed_pose_slots','global_exact_crop_hashes','global_visible_pose_hashes','analyze_pass_pose_slots','complete_visible_region_pass_pose_slots','full_complete_visible_region_gate_passed','Main','completed_added']},indent=2))
