from pathlib import Path
import json,hashlib,sys
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as imp
D=Path(__file__).parent;P=D.parent;c=json.loads((P/'candidate-root-reviewed-v2.json').read_text());records=[]
for direction in ['W','NW','N','NE']:
 s=c['sheets'][5 if direction=='W' else 6];g=imp.analyze(Path(s['output_path']),rows_count=s['rows'],reference_rows=s['reference_rows'],directions=s['directions'],canvas_size=s['canvas_size'],directions_axis=s.get('directions_axis','columns'),source_anchors=s.get('source_anchors'))
 f=next(x for x in g['frames'] if x['direction']==direction and x['row']==0);x,y,w,h=f['region'];im=Image.open(s['output_path']);dst=D/f'{direction}-own-idle-primary-reference-DIAGNOSTIC.png';im.crop((x,y,x+w,y+h)).save(dst)
 records.append({'direction':direction,'source_original_png':s['output_path'],'source_png_sha256':imp.sha(Path(s['output_path'])),'source_region':f['region'],'source_canvas_size':s['canvas_size'],'source_anchor':f['source_anchor'],'diagnostic_reference':str(dst),'diagnostic_sha256':imp.sha(dst),'purpose':'Identity/core/head/palette reference only, never shipping or counted as authored output. Exact whole-body crop from existing unmodified Hell idle source.'})
(D/'reference-provenance.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records))
