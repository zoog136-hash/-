from pathlib import Path
import json,sys,hashlib,math
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as imp
D=Path(__file__).parent;P=D.parent;base_path=P/'candidate-root-reviewed-v2.json';base=json.loads(base_path.read_text())
settings={
'W':('W-fivepose-proportion-pilot1',568,[217,652,1086,1520,1895]),
'NW':('NW-fivepose-proportion-stagger5',1056,[250,515,809,1056,1339]),
'N':('N-fivepose-proportion-pilot3',1368,[154,461,768,1075,1382]),
'NE':('NE-fivepose-proportion-stagger5',920,[208,478,756,1056,1348])}
# Human source-coordinate observations, with ±4..8 px uncertainty. These are anatomical
# skull/ear/core landmarks; never alpha-height or a fitted living silhouette.
landmarks={
'W':{'idle':{'head_points':[[248,191],[286,179],[329,163],[273,224]],'core_segment':[[620,140],[620,247]],'note':'Muzzle tip, outer visible eye, ear root, lower jaw. Core vertical section through upper hip; hock/paw/tail excluded.'},'new_phase0':{'head_points':[[32,368],[53,352],[85,340],[45,386]],'core_segment':[[275,331],[275,410]],'note':'Same profile features. Human uncertainty±4px; provisional568 balances skull/core observations, not total body height.'}},
'NW':{'idle':{'ear_span':[[94,112],[184,105]],'core_segment':[[262,332],[378,221]]},'new_phase0':{'ear_span':[[67,595],[151,586]],'core_segment':[[199,803],[303,702]]},'note':'Core segment crosses haunches perpendicular to NW spine, not an axis-aligned body/tail boundingbox. ~0.90 same-feature source ratio, idle1166→trial1056.'},
'N':{'idle':{'ear_span':[[703,109],[801,106]],'core_segment':[[666,300],[828,300]]},'new_phase0':{'ear_span':[[95,342],[204,339]],'core_segment':[[55,582],[253,582]]},'note':'Trial1368 vs idle1166 leaves rear ear/skull about5–8% smaller and core about3–5% wider by manualapproximation. Muchcloserthan prior1.4–1.5×core. Hitcrouch lowers/foreshortens neck/head without inflatingcore. Root independent review/Main still required.'},
'NE':{'idle':{'ear_span':[[1352,109],[1445,108]],'core_segment':[[1305,330],[1165,222]]},'new_phase0':{'ear_span':[[237,613],[311,611]],'core_segment':[[262,759],[154,670]]},'note':'Same rearquarter ear span and pelvis transverse line; source ratio~0.79, idle1166→trial920. Full-height change from crouch/tail not scale criterion.'}}
new_specs=[];new_geometries={};rawset=set();visset=set()
for direction,(stem,canvas,xs) in settings.items():
 path=D/(stem+'.png');a=json.loads((D/(stem+'-audit.json')).read_text());assert a['geometry_status']=='PASS'
 anchors=[[x,f['source_anchor'][1]] for x,f in zip(xs,a['geometry']['frames'])]
 g=imp.analyze(path,rows_count=5,reference_rows=[0,2],directions=[direction],directions_axis='rows',canvas_size=canvas,source_anchors=anchors);imp.require_complete_pose_regions(path,g)
 spec={'output_path':str(path),'sha256':imp.sha(path),'rows':5,'reference_rows':[0,2],'directions':[direction],'directions_axis':'rows','canvas_size':canvas,'source_anchors':anchors,'roles':{'attack':[0,1,2],'hit':[3,4]},'scale_review_note':f'PROPOSED FOR ROOT REVIEW ONLY. Own same-heading idle skull/ear landmarks and transverse hip/core comparison in rear20-landmarks-and-anchors.json; canvas{canvas}. No full-alpha-height normalization or max_living fitting. New PNG byte-unchanged, whole5poses fullyused.','anchor_review_note':'PROPOSED FOR ROOT REVIEW ONLY. SourceX explicitly follows pelvic/spine projection, not tailbboxcenter or sourcecolumncenter. Y is actual closest loaded paw/heel sole at alpha>100 (allselectedtailstips above soles). Root must verify fixed-root Main contact and bodyground.'}
 new_specs.append(spec);new_geometries[direction]=g
 pixels=np.asarray(Image.open(path))
 for f in g['frames']:
  x,y,w,h=f['region'];a=pixels[y:y+h,x:x+w];rh=hashlib.sha256(a.tobytes()).hexdigest();vh=imp._visible_pose_fingerprint(a);assert rh not in rawset and vh not in visset;rawset.add(rh);visset.add(vh)
# Read-only full104 validation combining original unmodified84 with whole20 replacements.
kept=[s for i,s in enumerate(base['sheets']) if i not in [11,13]];combined=kept+new_specs;pose_counts={r:{d:0 for d in imp.DIRECTIONS} for r in imp.ROLES};allraw=set();allvis=set();kept_sha=[]
for s in combined:
 path=Path(s['output_path']);g=imp.analyze(path,rows_count=s['rows'],reference_rows=s.get('reference_rows'),directions=s.get('directions',imp.DIRECTIONS),directions_axis=s.get('directions_axis','columns'),canvas_size=s.get('canvas_size'),source_anchors=s.get('source_anchors'));imp.require_complete_pose_regions(path,g)
 arr=np.asarray(Image.open(path));used=set()
 for role,rows in s['roles'].items():
  for f in g['frames']:
   if f['row'] in rows:
    key=(f['row'],f['direction']);assert key not in used;used.add(key);pose_counts[role][f['direction']]+=1
 assert len(used)==len(g['frames'])
 for f in g['frames']:
  x,y,w,h=f['region'];a=arr[y:y+h,x:x+w];rh=hashlib.sha256(a.tobytes()).hexdigest();vh=imp._visible_pose_fingerprint(a);assert rh not in allraw and vh not in allvis;allraw.add(rh);allvis.add(vh)
 if s in kept:kept_sha.append({'path':str(path),'sha256':imp.sha(path),'poses':len(g['frames'])})
assert len(allraw)==104 and len(allvis)==104 and sum(r['poses'] for r in kept_sha)==84
for role,expected in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)]:assert set(pose_counts[role].values())=={expected}
(D/'rear20-proposed-four-sheet-specs-HOLD.json').write_text(json.dumps({'status':'PROPOSED_104_GEOMETRY_PASS_ROOT_MAIN_PENDING','base_candidate':str(base_path),'base_candidate_sha256':imp.sha(base_path),'remove_base_sheet_indices':[11,13],'remove_full20_not_partial_sources':True,'replace_with_whole_sources':new_specs,'new_pose_count':20,'new_visible_unique':len(visset),'combined104_visible_unique':len(allvis),'combined_role_coverage':pose_counts,'unchanged84_source_bytes':kept_sha,'review_flags_changed':False,'production_imported':False,'completed_added':0},ensure_ascii=False,indent=2)+'\n')
(D/'rear20-landmarks-and-anchors.json').write_text(json.dumps({'status':'MANUAL_PROVISIONAL_ROOT_REVIEW_REQUIRED','method':'Homologous same-heading skull/ear/eye/jaw and transverse pelvic core coordinates. Source spine/pelvis X and actual loaded heel sole Y. No alpha-height normalization. Points have ±4..8px manual uncertainty, not automatic precision claims.','landmarks':landmarks,'specs':new_specs,'new_geometry':new_geometries},ensure_ascii=False,indent=2)+'\n')
# Same normalized pixel scale, same root/support baseline: own idle0 + five new poses.
out=D/'registered-proposal';out.mkdir(exist_ok=True)
refs={r['direction']:r for r in json.loads((D/'reference-provenance.json').read_text())}
for direction,(stem,canvas,xs) in settings.items():
 ref=refs[direction];items=[{'path':ref['source_original_png'],'region':ref['source_region'],'source_anchor':ref['source_anchor'],'canvas':ref['source_canvas_size'],'label':direction+' own IDLE0'}]+[{'path':str(D/(stem+'.png')),'region':f['region'],'source_anchor':f['source_anchor'],'canvas':canvas,'label':direction+(' attack' if i<3 else ' hit')+str(i if i<3 else i-3)} for i,f in enumerate(new_geometries[direction]['frames'])]
 im=Image.new('RGB',(6*430,350),'#eeeeee');dr=ImageDraw.Draw(im)
 for i,item in enumerate(items):
  x,y,w,h=item['region'];im0=Image.open(item['path']).crop((x,y,x+w,y+h));ratio=384/item['canvas'];im0=im0.resize((round(w*ratio),round(h*ratio)),Image.Resampling.LANCZOS);ax,ay=item['source_anchor'];dx=215+round((x-ax)*ratio);dy=295+round((y-ay)*ratio)
  assert 0<=dx and dx+im0.width<=430 and 20<=dy and dy+im0.height<=350,(direction,i,dx,dy,im0.size)
  dr.line((i*430,295,(i+1)*430-1,295),fill='#aaaaaa');dr.line((i*430+215,289,i*430+215,301),fill='red');im.paste(im0,(i*430+dx,dy),im0);dr.text((i*430+5,5),item['label']+' canvas'+str(item['canvas']),fill='black')
 im.save(out/(direction+'-idle-and-five-new-fixed-root.png'))
print(json.dumps({'new20_global_unique':len(visset),'combined104_global_unique':len(allvis),'unchanged_source84':sum(r['poses'] for r in kept_sha),'proposed_canvases':{d:v[1] for d,v in settings.items()},'production_imported':False,'completed_added':0}))
