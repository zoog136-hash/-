from pathlib import Path
from PIL import Image
import hashlib,json,sys
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as motion
p=Path('/workspace/scratch/pr100-continuation/hell-cougar-authoring')
w=json.loads((p/'walk-progress-checkpoint.json').read_text())
proposed=[864,1296,1296,1856,1296,864,1296,1296,1984,2048]
items=[]
for s,cv in zip(w['selected_idle_walk'],proposed):
 items.append((Path(s['output_path']),s['rows'],s['directions'],s['directions_axis'],s['roles'],cv))
q=p/'attack-hit-death'
items.extend([(q/'attack-front-attempt1.png',3,['E','SE','S','SW'],'rows',{'attack':[0,1,2]},680),(q/'attack-back-attempt1.png',3,['W','NW','N','NE'],'rows',{'attack':[0,1,2]},680),(q/'hit-front-attempt3.png',2,['E','SE','S','SW'],'columns',{'hit':[0,1]},720),(q/'hit-back-attempt2.png',2,['W','NW','N','NE'],'columns',{'hit':[0,1]},768),(q/'death-front-attempt2.png',3,['E','SE','S','SW'],'columns',{'death':[0,1,2]},592),(q/'death-back-attempt3.png',3,['W','NW','N','NE'],'columns',{'death':[0,1,2]},800)])
raw=[];visible=[];coverage={r:{} for r in ['idle','walk','attack','hit','death']};sheets=[];audit=[]
for image,rows,dirs,axis,roles,cv in items:
 diag=json.loads(image.with_suffix('.diagnostic.json').read_text());assert diag['analyze_status']=='PASS' and diag['complete_pose_regions_status']=='PASS'
 anchors=[f['source_anchor'] for f in diag['geometry']['frames']]
 geom=motion.analyze(image,rows_count=rows,reference_rows=[0,1],directions_axis=axis,canvas_size=cv,source_anchors=anchors,directions=dirs)
 motion.require_complete_pose_regions(image,geom)
 a=np.asarray(Image.open(image))
 for f in geom['frames']:
  x,y,wi,he=f['region'];raw.append(f['rgba_sha256']);visible.append(motion._visible_pose_fingerprint(a[y:y+he,x:x+wi]))
 for role,phases in roles.items():
  for direction in dirs:
   assert direction not in coverage[role];coverage[role][direction]=len(phases)
 note='PROPOSED_NOT_APPROVED: per-sheet virtual canvas from homologous living skull/ear/eye/core landmarks, never corpse silhouette height. E7/W2 compactskull proxies about87-94px at864; frontidle1296 basis, S walk frontal skull about1.43x idle→1856; N walk rear ear/skull about1.52x rearidle→1984; NE walk rear skull about1.58x rearidle→2048. Other same-heading attack/hit/death sources matched approximate living side-skull/core proportions with remaining pose/yaw uncertainty. No within-sheet head growth is corrected by metadata. All final shared scale and root/paw/corpse anchors require parent independent review. Source PNG byte unchanged.'
 spec={'output_path':str(image),'rows':rows,'reference_rows':[0,1],'directions':dirs,'directions_axis':axis,'canvas_size':cv,'source_anchors':anchors,'source_anchors_review_status':'PROPOSED_NOT_APPROVED','scale_review_note':note,'roles':roles,'sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'prompt_path':str(image.with_suffix('.prompt.txt'))}
 sheets.append(spec);audit.append({'image':str(image),'rows':rows,'directions':dirs,'roles':roles,'proposed_canvas':cv,'strict_analyze':'PASS','complete_visible_regions':'PASS','frames':len(geom['frames'])})
 im=Image.open(image).convert('RGBA')
 for c,col in [('white',(255,255,255,255)),('black',(0,0,0,255))]:
  bg=Image.new('RGBA',im.size,col);bg.alpha_composite(im);bg.convert('RGB').save(image.with_suffix('.proof-'+c+'.jpg'),quality=94)
assert len(raw)==104 and len(set(raw))==104 and len(set(visible))==104
assert all(len(d)==8 for d in coverage.values())
proof=json.loads((p/'target-source-proof.json').read_text())['target']
review_notes='Author static104pose candidate only; NOT production-ready or complete. All16 source sheets strict analyze/complete visible regions PASS and104 RGBA/visible fingerprints unique. All8directions each idle2/walk3/attack3/hit2/death3. E7/W2imagegen corrections preserve actualnear/far foreANDhind root-to-paw contactA→B opposition and reduce per-sheet headgrowth to approximate5-6% skullproxy range; failed earlierposes preserved. S/N actualoppositeleft/rightsupport visible, NW/NEbodyrear andtrueheading. Forelimbs partiallyoccluded bybody inN need independentanatomyreview. RearNE repeatedleg broad attemptsHOLD; singleownB +jointdiagram→portraitNE5 retained actualopposition. Frontattack E retains3quarter sourcehead tilt, Wbackattack similarlyneedsprofilecamera review; NW/NEattack show sideeye/muzzle slivers fromrearbody duringstrike, judge truecompassgeometry andcamera independently. Recoil2 andwholeattachedbodydeath3 articulated, finalfrontS/backN flatcorpseworldplane/bodymass/rootcontinuity needs actualMain verification; projectedNcorpse silhouetteheight is not scale basis. Proportionalvirtualcanvases/anchors are author proposals with uncertainhead/core landmarks, never final approval. All104newlydrawn from exactexistingprojectblackcougar neutral portrait, not recovered originalmotion; Waring sharesneutralatlas but noanimationimages/aliases/counts reused. Existing native128/melee/slash/floatingFALSE/attackratio.44/variant4presentation preserved inproof only, repo untouched. Main/attacktiming/combat/drop/pickup/regressions/Android NOTRUNhere. Parent independentQA andfinalscale/contact review REQUIRED. Completion0.'
c={'schema':1,'actor':'hell_cougar_source','target_keys':[proof['key']],'source':'Newly authored from existing neutral project atlas portrait; not recovered original animation or verified external original game art','reference':proof['reference'],'supplemental_body_context':{'path':'/workspace/scratch/pr100-continuation/next-boss-source-review/waring-cougar-body-context.png','sha256':'fcefa7d42e0758c0daf7ef238ec752ecb24502a129768acc32fac606f177180e'},'presentation_to_preserve':proof['presentation_to_preserve'],'display_height_basis':'max_living_frame','prompt':'\n\n'.join(Path(s['prompt_path']).name+' EXACT PROMPT:\n'+Path(s['prompt_path']).read_text() for s in sheets),'prompt_record_kind':'Exact selected prompts saved beforeimagegen; allfailed andintermediateprompts/rawPNGs remainseparatelypreserved','sheets':sheets,'review':{'identity_preserved':True,'eight_views':True,'motion_roles':True,'no_clipping':True,'notes':review_notes},'status':'HOLD_PENDING_INDEPENDENT_QA_FINAL_SCALE_AND_MAIN','actual_import_performed':False,'runtime_profiles_changed':False,'main_scene_verified':False,'map_changes':False,'complete_count_added':0}
(p/'candidate.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
a={'target':proof['key'],'status':'ALL104_STRICT_PASS_PENDING_INDEPENDENT_VISUAL_QA','source_sheets':16,'actual_pose_count':104,'distinct_rgba_frames':len(set(raw)),'distinct_visible_frames':len(set(visible)),'roles':coverage,'sheet_diagnostics':audit,'raw_rgba_hashes':raw,'visible_hashes':visible,'proposed_canvases_strict_pass':True,'final_scale_approved':False,'source_anchor_approved':False,'main_verified':False,'production_imported':False,'complete_count_added':0,'known_independent_review_flags':review_notes}
(p/'strict-audit-104.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
status={'target':proof['key'],'status':c['status'],'candidate':str(p/'candidate.json'),'audit':str(p/'strict-audit-104.json'),'actual_pose_count':104,'all_five_roles_eight_directions':True,'strict_geometry':'PASS','complete_visible_regions':'PASS','unique_rgba_and_visible':True,'independent_visual_qa':'PENDING','final_scale_and_anchors':'PROPOSED_NOT_APPROVED','main':'NOT_RUN','repo_mutations':False,'production_imported':False,'complete_count_added':0,'latest_replacements':{'E':'idle-walk-E-attempt7.png','W':'idle-walk-W-attempt2.png','NE':'walk-NE-attempt5.png'},'raw_failures_preserved':True,'next':'Root independent QA; correct any identified sourceanatomy/scale/camera issue before import/Main, nevercountbeforeverified.'}
(p/'status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(status,ensure_ascii=False,indent=2))
