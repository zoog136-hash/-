from pathlib import Path
import json,sys,copy
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
b=Path('/workspace/scratch/pr100-continuation/hell-cougar-authoring');orig=json.load(open(b/'candidate-root-reviewed.json'));pro=copy.deepcopy(orig);outputs={};exceptions=[]
for s in pro['sheets']:
 name=Path(s['output_path']).name
 if s['directions']==['N'] and s['roles']=={'walk':[0,1,2]}:
  s['output_path']=str(b/'walk-N-charcoal-root-v2.png');s['canvas_size']=2048;s['source_anchors']=[[285,883],[770,883],[1280,885]]
 elif s['directions']==['NE'] and s['roles']=={'walk':[0,1,2]}:
  s['output_path']=str(b/'walk-NE-charcoal-root-v3.png');s['canvas_size']=1440;s['source_anchors']=[[628,546],[632,1012],[628,1488]]
 else:s['canvas_size']=round(s['canvas_size']*.9)
for label,c in [('before',orig),('proposed',pro)]:
 frames=[]
 for i,s in enumerate(c['sheets']):
  try:
   g=m.analyze(Path(s['output_path']),s['rows'],s.get('reference_rows'),directions_axis=s.get('directions_axis','columns'),canvas_size=s['canvas_size'],source_anchors=s.get('source_anchors'),directions=s.get('directions',m.DIRECTIONS));m.require_complete_pose_regions(Path(s['output_path']),g)
   for f in g['frames']:
    roles=[r for r,rows in s['roles'].items() if f['row'] in rows]
    assert len(roles)==1
    frames.append({'sheet':i,'source':Path(s['output_path']).name,'row':f['row'],'direction':f['direction'],'role':roles[0],'canvas':s['canvas_size'],'region':f['region'],'anchor':f['source_anchor']})
  except Exception as e:exceptions.append({'label':label,'source':s['output_path'],'error':str(e)})
 living=[f for f in frames if f['role']!='death'];D=max(f['region'][3]*256/f['canvas'] for f in living);dom=[f for f in living if f['region'][3]*256/f['canvas']==D]
 for f in frames:
  f['world_pixel_factor']=128*256/f['canvas']/D;f['world_region_size']=[q*f['world_pixel_factor'] for q in f['region'][2:]]
 outputs[label]={'reference_height':D,'dominant':dom,'frames':frames}
old=outputs['before'];new=outputs['proposed'];deltas=[]
for a,c in zip(old['frames'],new['frames']):
 if a['source']==c['source']:deltas.append({'source':a['source'],'row':a['row'],'direction':a['direction'],'world_scale_ratio':c['world_pixel_factor']/a['world_pixel_factor']})
r={'kind':'Independent scratch read-only math/bounds check; no production application or Main','max_ref_before':old['reference_height'],'max_ref_proposed':new['reference_height'],'dominant_proposed':new['dominant'],'unchanged_raw_poses_compared':len(deltas),'max_world_scale_relative_error_unchanged':max(abs(d['world_scale_ratio']-1) for d in deltas),'unchanged_source_ratios':deltas,'strict_exceptions':exceptions,'proposed_N_anchors':[[285,883],[770,883],[1280,885]],'proposed_NE_anchors':[[628,546],[632,1012],[628,1488]],'warning':'Independent root/canvas proposals are diagnostic; source physical model dimensions and actual Main still gate completion. Same-source worldscale excludes replaced six N/NE poses, whose art/canvas truly changed. Whole104 must pass without exceptions.'}
(b/'independent/coordinate-rebase-readonly-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['unchanged_source_ratios','dominant_proposed']},indent=2))
