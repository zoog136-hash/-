from pathlib import Path
import json,sys,hashlib
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path(__file__).resolve().parent;o=b/'independent';o.mkdir(exist_ok=True);rawposes={};registered={};records=[];raw=[];vis=[];c=json.load(open(b/'candidate.json'))
for i,s in enumerate(c['sheets']):
 p=Path(s['output_path']);g=m.analyze(p,rows_count=s['rows'],reference_rows=s['reference_rows'],directions_axis=s['directions_axis'],canvas_size=s['canvas_size'],source_anchors=s['source_anchors'],directions=s['directions']);m.require_complete_pose_regions(p,g);im=Image.open(p).convert('RGBA');a=np.asarray(im);cover=np.zeros(a.shape[:2],bool)
 for f in g['frames']:
  x,y,w,h=f['region'];cover[y:y+h,x:x+w]=True;raw.append(f['rgba_sha256']);vis.append(m._visible_pose_fingerprint(a[y:y+h,x:x+w]));crop=im.crop((x,y,x+w,y+h));mx,my,_,_=f['margin'];reg=Image.new('RGBA',tuple(g['canvas_size']));reg.paste(crop,(mx,my));reg=reg.resize((400,400),Image.Resampling.LANCZOS)
  for role,rows in s['roles'].items():
   if f['row'] in rows:
    key=(role,f['direction'],rows.index(f['row']));assert key not in rawposes;rawposes[key]={'crop':crop,'frame':f,'sheet':i,'path':str(p),'source_anchor':f['source_anchor']};registered[key]=reg
 outside=a[:,:,3][~cover];records.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'candidate_SHA_matches':hashlib.sha256(p.read_bytes()).hexdigest()==s.get('sha256'),'poses':len(g['frames']),'canvas':s['canvas_size'],'outside_alpha_max':int(outside.max()),'outside_alpha_gt25':int(np.sum(outside>25))})
assert len(rawposes)==len(raw)==len(set(raw))==len(set(vis))==104
for di in m.DIRECTIONS:
 canvas=Image.new('RGB',(1600,1600),'#28323a');d=ImageDraw.Draw(canvas);k=0
 for role,n in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)]:
  for ph in range(n):
   rec=rawposes[role,di,ph];crop=rec['crop'];w,h=crop.size;scale=min(360/w,345/h);sc=crop.resize((round(w*scale),round(h*scale)),Image.Resampling.LANCZOS);tile=Image.new('RGBA',(400,365),'#28323a');tile.alpha_composite(sc,((400-sc.width)//2,360-sc.height));x=k%4*400;y=k//4*400;canvas.paste(tile.convert('RGB'),(x,y+25));d.text((x+8,y+5),f'{di} {role}{ph} raw x{scale:.2f}',fill='white');k+=1
 canvas.save(o/(di+'-all13-large-raw-diagnostic.png'))
for role,n in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)]:
 canvas=Image.new('RGB',(3200,n*424),'#28323a');d=ImageDraw.Draw(canvas)
 for ph in range(n):
  for k,di in enumerate(m.DIRECTIONS):
   tile=Image.new('RGBA',(400,400),'#28323a');tile.alpha_composite(registered[role,di,ph]);canvas.paste(tile.convert('RGB'),(k*400,ph*424+24));d.text((k*400+8,ph*424+4),di+' '+role+str(ph),fill='white');d.line((k*400,ph*424+274,k*400+399,ph*424+274),fill='#9f9b65')
 canvas.save(o/(role+'-registered-all8.png'))
(o/'strict-audit-independent.json').write_text(json.dumps({'poses':104,'raw_unique':len(set(raw)),'visible_unique':len(set(vis)),'allselectedPNGframes_used':True,'sheets':records,'candidate_sha256':hashlib.sha256((b/'candidate.json').read_bytes()).hexdigest(),'production_modified':False,'Main':'notrun','countadd':0},indent=2)+'\n');(o/'pose-regions.json').write_text(json.dumps({('|'.join(map(str,k))):{kk:vv for kk,vv in v.items() if kk!='crop'} for k,v in rawposes.items()},indent=2)+'\n');print(json.dumps({'poses':104,'sheets':len(records),'allselectedSHA_match':all(r['candidate_SHA_matches'] for r in records),'output':str(o)}))
