from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json
b=Path(__file__).resolve().parent.parent;o=b/'independent';a=Image.new('RGB',(1800,900),'white');d=ImageDraw.Draw(a);ft=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',24);sm=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17);L='#aa237f';R='#008bb5'
for ph in range(3):
 ox=ph*600;d.text((ox+20,20),'N / BACK — '+['CONTACT A','PASSING','CONTACT B'][ph],font=ft,fill='black');d.text((ox+25,60),'LEFT = magenta / RIGHT = cyan',font=sm,fill='black');d.ellipse((ox+255,110,ox+345,205),outline='#777777',width=6);d.polygon([(ox+240,215),(ox+360,215),(ox+385,460),(ox+215,460)],outline='#777777',width=6);d.line((ox+300,205,ox+300,460),fill='#aaaaaa',width=5)
 if ph==0:
  chains=[([(ox+245,230),(ox+188,330),(ox+150,420)],L,'FORE LEFT PLANTED'), ([(ox+355,230),(ox+415,340),(ox+440,470)],R,'FORE RIGHT LIFTED'), ([(ox+255,455),(ox+230,555),(ox+205,720)],L,'HIND LEFT LIFTED'), ([(ox+345,455),(ox+375,550),(ox+390,650)],R,'HIND RIGHT PLANTED')]
 elif ph==1:
  chains=[([(ox+245,230),(ox+190,340),(ox+165,460)],L,'FORE LEFT SUPPORT'), ([(ox+355,230),(ox+417,310),(ox+430,400)],R,'FORE RIGHT PASSING'), ([(ox+255,455),(ox+230,550),(ox+215,655)],L,'HIND LEFT SUPPORT'), ([(ox+345,455),(ox+367,555),(ox+385,690)],R,'HIND RIGHT PASSING')]
 else:
  chains=[([(ox+245,230),(ox+185,340),(ox+160,470)],L,'FORE LEFT LIFTED'), ([(ox+355,230),(ox+412,330),(ox+450,420)],R,'FORE RIGHT PLANTED'), ([(ox+255,455),(ox+225,550),(ox+210,650)],L,'HIND LEFT PLANTED'), ([(ox+345,455),(ox+370,555),(ox+395,720)],R,'HIND RIGHT LIFTED')]
 for pts,col,label in chains:
  d.line(pts,fill=col,width=20,joint='curve')
  for x,y in pts:d.ellipse((x-11,y-11,x+11,y+11),fill=col,outline='white',width=3)
  x,y=pts[-1];d.ellipse((x-25,y-18,x+25,y+18),fill=col,outline='black',width=2)
  tx=ox+15 if 'LEFT' in label else ox+367;ty=y+28;d.text((tx,ty),label,font=sm,fill=col)
 d.text((ox+20,820),'FOUR CONTINUOUS LIMB CHAINS.',font=sm,fill='black');d.text((ox+20,850),'Kinematics only; no colors/labels/design to copy.',font=sm,fill='#555555')
a.save(o/'N-threephase-fourlimb-topology-guide.png')
p='''Correct a specific gait defect in this unfinished BLACK PANTHER / HELL COUGAR animation. Reference1 is its current three-pose N walk sheet: hind legs already exchange support correctly, but the same visible right FOREPAW remains lifted in both endpoints while the opposite foreleg is hidden. Reference2 is an abstract colored joint-topology guide for all FOUR limbs, not a donor character. Reference3 is the exact original neutral source identity.

Output a new transparent RGBA game sheet: exactly THREE complete full-body cats, THREE equal PHASE COLUMNS × ONE ROW, on1536x1024 landscape canvas. All THREE figures face exactly N, straight AWAY/UP, true rear head/nape/spine/shoulderblades/rump, no frontal eyes/chest/face. Preserve the exact existing black-charcoal muscular panther, pointed ears, broad shoulders and pelvis, FOUR connected feline legs with natural elbows and digitigrade hocks, broad clawed paws, long attached curled tail. Match current source head, torso, hip and limb proportions uniformly across all3; no head growth, human arms or extra limbs. Do not introduce a higher/different camera angle. New authored motion, not recovered original animation.

Make both attached FORE WRIST CHAINS visible just outside the torso/hip occlusion by a small natural lateral foreleg placement and slight shoulder sway. No detached paws floating beside the body. Each visible front paw must be traceable through wrist→elbow→its own FRONT SHOULDER, separate from the hind paws. Do not hide the entire opposite forelimb. Keep the already-correct rear-body identity and hind-leg support swap from reference1. Use the diagram only for anatomical LEFT/RIGHT joint states; do not copy magenta/cyan, simplified shapes, labels or markings.

COLUMN1 CONTACT A: anatomical LEFT foreleg reaches forward/away UP, its paw planted, showing dorsal top/claws with toes pointing UP. Anatomical RIGHT foreleg bends back toward body and lifts, a bent wrist/underside paw visibly unweighted. LEFT hindleg trails back towardviewer with lifted pad-visible paw; RIGHT hindleg supports nearer under pelvis. Left fore + right hind are the grounded support pair. Reveal actual left shoulder-to-wrist continuity at screen-left edge. Exactly4 legs.

COLUMN2 PASSING: real distinct joint transition, pelvis/shoulders sway slightly, supporting paws beneath body while the opposite fore knee/elbow and hind hock swing. Keep one or more loaded paws visibly grounded; no levitation or an idle duplicate.

COLUMN3 CONTACT B: TRUE OPPOSITE of column1 in BOTH pairs. Anatomical RIGHT foreleg now reaches forward/away UP with paw planted, dorsal top/claws visible; LEFT foreleg is bent/lifted with underside visible. LEFT hindleg now supports nearer under pelvis while RIGHT hindleg trails lifted towardviewer. Right fore + left hind support. The pair of fore shoulder/elbow/wrist positions and planted/lifted paw surfaces MUST REVERSE from column1, just as the already-real hind legs reverse. Do not repeat the right lifted forepaw at both endpoints. Reveal both forewrist chains enough for independent joint tracing, not a merely moved paw.

Three genuine articulated source-preserving poses, no mirrored stills or duplicated endpoints, no translated/scaled stills. Stable skull/core size and body root; limb length changes must come from joints and projection. Each complete body must fit a compact320pixel width×550pixel height box in its cell with huge clear gutters and safe outer margins. Entire tail, ears, claws and paws visible. No clipping or overlapping crop rectangles. One connected whole body per cell, no fragments. All empty pixels fully alpha0, no opaque colored matte, background, floor/shadow, text, labels, diagram colors, borders or particles.'''
(b/'walk-N-attempt3.prompt.txt').write_text(p+'\n');(o/'N3-authoring-checkpoint.json').write_text(json.dumps({'stage':'exactprompt_and_abstractfourlimbguide_saved_before_generation','sourceN2candidate_preserved':True,'candidate_selectedN2_unchanged':True,'newPNG_expected':str(b/'walk-N-attempt3.png'),'independentrootQArequired':True,'productionmodified':False},indent=2)+'\n');print('N3 exactprompt/guide saved')
