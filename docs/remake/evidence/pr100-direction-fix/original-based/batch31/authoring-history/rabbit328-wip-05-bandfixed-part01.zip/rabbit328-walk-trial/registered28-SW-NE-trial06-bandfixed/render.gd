extends SceneTree
const OUT="/workspace/scratch/pr100-continuation/rabbit328-single-pose/registered28-SW-NE-trial06-bandfixed"
const INPUT="/workspace/scratch/pr100-continuation/rabbit328-single-pose/remaining-roles/union112-registration-trial06-bandfixed.json"
const DIRS: Array[String]=["E","SE","S","SW","W","NW","N","NE"]
const ROLES: Array[String]=["idle","walk","attack","hit","death"]
var input: Dictionary
var textures: Dictionary={}
var actors: Array[AnimatedSprite2D]=[]
var labels: Array[Label]=[]
var snapshot: Array=[]
var pre_ticks: int=0
var role_active: String=""
class Ground extends Node2D:
 var dimensions: Vector2
 var floors: Array[int]=[]
 func _draw() -> void:
  draw_rect(Rect2(Vector2.ZERO,dimensions),Color("343c49"))
  for floor_y: int in floors:draw_line(Vector2(0,floor_y),Vector2(dimensions.x,floor_y),Color("f4c564"),2)
func _initialize() -> void:
 Engine.max_fps=30
 call_deferred("run")
func label_at(parent: Node,value: String,where: Vector2,size: int=17) -> Label:
 var result:=Label.new()
 result.text=value
 result.position=where
 result.add_theme_font_size_override("font_size",size)
 parent.add_child(result)
 return result
func record(role: String,direction: String,phase: int) -> Dictionary:
 for f: Dictionary in input.frames:
  if f.role==role and f.direction==direction and f.phase==phase:return f
 assert(false,"Missing genuine pose slot")
 return {}
func atlas(entry: Dictionary) -> AtlasTexture:
 if not textures.has(entry.path):
  var image:=Image.new()
  assert(image.load(entry.path)==OK)
  textures[entry.path]=ImageTexture.create_from_image(image)
 var result:=AtlasTexture.new()
 result.atlas=textures[entry.path]
 result.region=Rect2(entry.region[0],entry.region[1],entry.region[2],entry.region[3])
 result.margin=Rect2(entry.margin[0],entry.margin[1],entry.margin[2],entry.margin[3])
 result.filter_clip=true
 return result
func viewport(size: Vector2i,floors: Array[int]) -> SubViewport:
 var result:=SubViewport.new()
 result.size=size
 result.render_target_update_mode=SubViewport.UPDATE_ALWAYS
 root.add_child(result)
 var background:=Ground.new()
 background.dimensions=Vector2(size)
 background.floors=floors
 result.add_child(background)
 return result
func capture(view: SubViewport,path: String) -> void:
 await process_frame
 await RenderingServer.frame_post_draw
 assert(view.get_texture().get_image().save_png(path)==OK)
func sync(index: int) -> void:
 var entry: Dictionary=record(role_active,DIRS[index],actors[index].frame)
 actors[index].scale=Vector2.ONE*600.0/float(entry.canvas)
 labels[index].text="%s / %s phase%d"%[DIRS[index],role_active,actors[index].frame]
func pre_draw() -> void:
 if actors.size()!=8:return
 snapshot=[]
 pre_ticks=Time.get_ticks_msec()
 for i: int in range(8):snapshot.append({"direction":DIRS[i],"phase":actors[i].frame,"label":labels[i].text,"frame_progress":actors[i].frame_progress})
func run() -> void:
 input=JSON.parse_string(FileAccess.get_file_as_string(INPUT))
 assert(input.frames.size()==112)
 var matrices: Array=[]
 for direction: String in ["SW","NE"]:
  var view:=viewport(Vector2i(2000,1650),[390,790,1190,1590])
  label_at(view,"112 RAW POSE DIAGNOSTIC | "+direction+" | TRIAL06 RIGHT LEG BAND IDENTITY PENDING ROOT / NOT MAIN / COMPLETED+0",Vector2(10,7),20)
  for column: int in range(5):
   var role: String=ROLES[column]
   for phase: int in range(4):
    var x: float=200+column*400
    var floor_y: float=390+phase*400
    if phase>=int(input.counts[role]):
     label_at(view,role+" / no additional phase",Vector2(column*400+12,42+phase*400),17)
     continue
    var entry:=record(role,direction,phase)
    var sprite:=Sprite2D.new()
    sprite.texture=atlas(entry)
    sprite.scale=Vector2.ONE*520.0/float(entry.canvas)
    sprite.position=Vector2(x,floor_y-65)
    view.add_child(sprite)
    label_at(view,"%s phase%d | source canvas%d"%[role,phase,entry.canvas],Vector2(column*400+12,42+phase*400),17)
  var path: String=OUT+"/matrix-"+direction+"-14poses.png"
  await capture(view,path)
  matrices.append({"direction":direction,"capture":path,"genuine_pose_count":14})
  view.queue_free()
 RenderingServer.frame_pre_draw.connect(pre_draw)
 var roles: Array=[]
 for role: String in []:
  var view:=viewport(Vector2i(1600,1000),[440,940])
  role_active=role
  label_at(view,"RAW80 ROLE BASELINE / "+role+" / TRIAL06 RIGHT LEG BAND IDENTITY PENDING ROOT / NOT MAIN / NO COUNT",Vector2(10,8),20)
  actors=[]
  labels=[]
  var count: int=int(input.counts[role])
  var seconds: float=float(input.seconds[role])
  for i: int in range(8):
   var frames:=SpriteFrames.new()
   frames.remove_animation("default")
   frames.add_animation(role)
   frames.set_animation_speed(role,float(count)/seconds)
   frames.set_animation_loop(role,role in ["idle","walk"])
   for phase: int in range(count):frames.add_frame(role,atlas(record(role,DIRS[i],phase)))
   var actor:=AnimatedSprite2D.new()
   actor.sprite_frames=frames
   actor.animation=role
   actor.position=Vector2(200+(i%4)*400,440+(i/4)*500)-Vector2(0,75)
   actors.append(actor)
   labels.append(label_at(view,"",Vector2((i%4)*400+12,42+(i/4)*500),18))
   actor.frame_changed.connect(sync.bind(i))
   view.add_child(actor)
   sync(i)
  var statics: Array=[]
  for phase: int in range(count):
   for i: int in range(8):
    actors[i].frame=phase
    sync(i)
   var path: String=OUT+"/role-"+role+"-phase%d.png"%phase
   await capture(view,path)
   statics.append({"phase":phase,"capture":path})
  DirAccess.make_dir_recursive_absolute(OUT+"/"+role+"-loop-frames")
  for i: int in range(8):
   actors[i].frame=0
   sync(i)
   actors[i].play(role)
  var playback: Array=[]
  for capture_index: int in range(32):
   await process_frame
   await RenderingServer.frame_post_draw
   assert(snapshot.size()==8)
   for i: int in range(8):
    assert(snapshot[i].phase==actors[i].frame)
    assert(snapshot[i].label==labels[i].text)
   var path: String=OUT+"/"+role+"-loop-frames/%03d.png"%capture_index
   assert(view.get_texture().get_image().save_png(path)==OK)
   playback.append({"capture":capture_index,"ticks_msec":Time.get_ticks_msec(),"pre_draw_ticks_msec":pre_ticks,"actors":snapshot.duplicate(true),"label_capture_atomic":true})
  roles.append({"role":role,"seconds_per_track":seconds,"pose_count_per_direction":count,"speed":float(count)/seconds,"loop":role in ["idle","walk"],"static_captures":statics,"playback":playback,"not_actual_combat_or_Main":true})
  actors=[]
  labels=[]
  view.queue_free()
 var report: Dictionary={"status":"RENDERED28_SW_NE_TRIAL06_BAND_IDENTITY_PENDING_ROOT","engine":Engine.get_version_info(),"renderer":RenderingServer.get_video_adapter_name(),"source_input":INPUT,"direction_matrices":matrices,"role_previews":roles,"source_pixels_modified":false,"all_sources_shown":28,"production_asset_created":false,"head_core_foot_registration_approved":false,"actual_Main":false,"combat_hit_death_drop_pickup_verified":false,"completed_added":0}
 var file:=FileAccess.open(OUT+"/godot-preview.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(report,"\t")+"\n")
 file.close()
 print("TRIAL06_BANDFIX_2MATRICES28POSES Mainfalse completed0")
 quit(0)
