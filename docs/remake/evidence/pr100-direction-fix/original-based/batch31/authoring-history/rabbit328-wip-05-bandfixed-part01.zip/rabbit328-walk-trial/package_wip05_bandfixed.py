from pathlib import Path
import json,zipfile,hashlib,datetime
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');out=Path('/workspace/scratch/pr100-continuation/rabbit328-portable');gitprior=Path('/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resumed-wip/rabbit328-current');prefix='rabbit328-walk-trial/';sha=lambda data:hashlib.sha256(data).hexdigest();known={};required=[]
parts=sorted(gitprior.glob('rabbit328-wip-0[23]-compact-part*.zip'))+sorted(out.glob('rabbit328-wip-04-preband-compact-part*.zip'))
for p in parts:
 required.append({'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
 with zipfile.ZipFile(p) as z:
  for name in z.namelist():
   if 'INCLUDED-FILES-SHA256' in name:
    for f in json.loads(z.read(name)):known[f.get('package_path',f.get('path'))]=f['sha256']
paths=set(p for p in (b/'remaining-roles/band-identity-fix').rglob('*') if p.is_file());paths.update(p for p in (b/'registered28-SW-NE-trial06-bandfixed').rglob('*') if p.is_file() and '.godot' not in p.parts and not any(x.startswith('xdg-') for x in p.parts));paths.update([b/'remaining-roles/union112-registration-trial06-bandfixed.json',b/'remaining-roles/candidate-mixed112-trial06-bandfixed-HOLD.json',b/'remaining-roles/build_registration_trial06_bandfixed.py',b/'LATEST-WIP05-TRIAL06-BANDFIX-CHECKPOINT.json',Path(__file__)]);items=[]
for p in sorted(paths):
 rel=str(p.relative_to(b));arc=prefix+rel;data=p.read_bytes()
 if known.get(arc)==sha(data):continue
 items.append((arc,data));known[arc]=sha(data)
candidate=json.loads((b/'remaining-roles/candidate-mixed112-trial06-bandfixed-HOLD.json').read_text());sources=[]
for spec in candidate['sheets']+candidate['pose_files']:
 p=Path(spec['output_path']);arc=prefix+str(p.relative_to(b));digest=sha(p.read_bytes());assert digest==spec['source_sha256'] and known.get(arc)==digest,('unrecoverable source',p);sources.append({'original_absolute_path':str(p),'package_path':arc,'sha256':digest,'recoverable_from_required_prior_plus_this_delta':True})
assert len(sources)==48
checkpoint=json.loads((b/'LATEST-WIP05-TRIAL06-BANDFIX-CHECKPOINT.json').read_text());meta={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':'wip-05-delta-trial06-bandfixed','checkpoint':checkpoint,'restore':'Extract WIP02, WIP03, WIP04prebandCOMPACT, then this WIP05 delta into same folder. Trees merge under rabbit328-walk-trial/. Rebase historical absolute /workspace/scratch/.../rabbit328-single-pose source paths to that restored tree. Every selected48 sourceSHA is explicitly recoverable from required parts plus this delta. Original game catalog remains inGit repository.','required_prior_parts':required,'selected48_source_recovery_proof':sources,'imagegen_failure_notes':'One initial attack promise returned no retained rejection detail or raw image; explicit JSON recordsunknowncause. No raw preservation claim for that call. All persisted failed rawimages and exact prompts preserved inWIP04/05.','actual_Main':False,'production_imported':False,'completed_added':0};items.append((prefix+'PORTABLE-INDEX-WIP05-BANDFIX.json',(json.dumps(meta,indent=2)+'\n').encode()));items.append((prefix+'README-WIP05-BANDFIX.txt',('WIP transform328 only, not completed. Restore all requiredWIP02+03+04COMPACT beforeWIP05. ReadLATEST-WIP05-TRIAL06-BANDFIX-CHECKPOINT.json andremaining-roles/band-identity-fix/author-review-trial06.json. Immutablecandidatebad1a2db... flagsfalse; expectedreadonlypreflightreject proof included. All4newPNG/20poses plus2Godotmatrices authorreviewed; rootindependentsource/Main gate pending. No production/profile/map/code mutation bythisagent.\n').encode()));manifest=[{'package_path':arc,'bytes':len(data),'sha256':sha(data)} for arc,data in items];items.append((prefix+'INCLUDED-FILES-SHA256-WIP05-BANDFIX.json',(json.dumps(manifest,indent=2)+'\n').encode()));grouped=[];cur=[];size=0
for item in items:
 if cur and size+len(item[1])>44_000_000:grouped.append(cur);cur=[];size=0
 cur.append(item);size+=len(item[1])
if cur:grouped.append(cur)
outputs=[]
for n,group in enumerate(grouped,1):
 p=out/f'rabbit328-wip-05-bandfixed-part{n:02d}.zip'
 with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
  for arc,data in group:z.writestr(arc,data)
 assert p.stat().st_size<90_000_000
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  for arc,data in group:assert sha(z.read(arc))==sha(data)
 outputs.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'entries':len(group)})
index={'label':meta['label'],'status':checkpoint['status'],'candidate_sha256':checkpoint['candidate_sha256'],'parts':outputs,'required_prior_parts':required,'all48_selected_sources_recoverable':True,'selected48_source_recovery_proof':sources,'actual_Main':False,'production_imported':False,'completed_added':0};(out/'rabbit328-wip-05-bandfixed-archive-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'parts':outputs,'all48_selected_sources_recoverable':True,'candidate_sha256':checkpoint['candidate_sha256']},indent=2))
