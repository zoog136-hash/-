from pathlib import Path
from PIL import Image
import json,hashlib,sys,numpy as np
from scipy import ndimage
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');j=json.loads((b/'remaining-roles/union112-registration-trial05.json').read_text());cand=json.loads((b/'remaining-roles/candidate-mixed112-trial05-HOLD.json').read_text());newnames={'idle':'idle-attempt2-guided.png','attack':'attack-attempt2.png','hit':'hit-attempt1.png','death':'death-attempt1.png'};replaced={};records=[]
for s in j['sheets']:
 if s['direction']!='SW-NE':continue
 role=s['role'];p=b/'remaining-roles/band-identity-fix'/newnames[role];a=np.array(Image.open(p));pre=m.analyze(p,rows_count=s['rows_count'],reference_rows=s['reference_rows'],directions_axis=s['directions_axis'],directions=s['direction_pair'],canvas_size=s['canvas_size']);m.require_complete_pose_regions(p,pre);anchors=[];contact=[]
 for f,oldf in zip(pre['frames'],s['geometry']['frames']):
  x,y,w,h=f['region'];ay=f['source_anchor'][1]
  if role=='death':anchor=[oldf['source_anchor'][0],ay]
  else:
   top=max(y,ay-100);mask=a[top:ay+1,x:x+w,3]>100;labs,n=ndimage.label(mask);areas=np.bincount(labs.ravel());good=sorted(range(1,n+1),key=lambda k:areas[k],reverse=True)[:2];assert len(good)==2 and all(areas[k]>=200 for k in good);soles=[]
   for lab in good:
    yy,xx=np.where(labs==lab);bottom=yy.max();near=(labs==lab)&(np.indices(mask.shape)[0]>bottom-10);yy,xx=np.where(near);soles.append({'left':int(xx.min()+x),'right':int(xx.max()+x+1),'bottom':int(bottom+top),'center':float((xx.min()+xx.max()+1)/2+x)})
   ax=round(sum(t['center'] for t in soles)/2);anchor=[ax,ay];assert abs(ax-oldf['source_anchor'][0])<30
   contact.append({'direction':f['direction'],'phase':f['row'],'soles':soles,'source_anchor':anchor,'old_source_anchor':oldf['source_anchor']})
  anchors.append(anchor)
 geom=m.analyze(p,rows_count=s['rows_count'],reference_rows=s['reference_rows'],directions_axis=s['directions_axis'],directions=s['direction_pair'],canvas_size=s['canvas_size'],source_anchors=anchors);m.require_complete_pose_regions(p,geom);oldpath=s['output_path'];digest=hashlib.sha256(p.read_bytes()).hexdigest();s.update(output_path=str(p),output_copy=str(p),source_sha256=digest,source_anchors=anchors,geometry=geom,independent_registration_approved=False,band_identity_correction='Fresh image_gen whole-sheet edit, all original bodies fully used. Actual anatomical RIGHT upper-leg costume band restored. All ankle straps/bows preserved. Old raw remains immutable.');replaced[oldpath]=(s,geom)
 records.append({'role':role,'path':str(p),'sha256':digest,'whole_source_guard':'PASS','complete_pose_count':len(geom['frames']),'contact_roots':contact})
 for cs in cand['sheets']:
  if cs['id']==role+'-SW-NE':cs.update(output_path=str(p),source_sha256=digest,source_anchors=anchors)
for f in j['frames']:
 if f['path'] in replaced:
  s,g=replaced[f['path']];nf=next(x for x in g['frames'] if x['direction']==f['direction'] and x['row']==f['phase']);f.update(**{k:nf[k] for k in ['region','margin','source_anchor']},path=s['output_path'],source_sha256=s['source_sha256'],registration_approved=False)
cache={};rawset=set();visset=set();slots=set()
for f in j['frames']:
 if f['path'] not in cache:cache[f['path']]=np.array(Image.open(f['path']))
 x,y,w,h=f['region'];a=cache[f['path']][y:y+h,x:x+w];rh=hashlib.sha256(a.tobytes()).hexdigest();vh=m._visible_pose_fingerprint(a);assert rh not in rawset and vh not in visset;rawset.add(rh);visset.add(vh);slot=(f['role'],f['direction'],f['phase']);assert slot not in slots;slots.add(slot)
assert len(slots)==112 and len(cache)==48
j.update(status='TRIAL06_RIGHT_LEG_BAND_IDENTITY_FIXED_PENDING_ROOT_MAIN_TRIAL',changes='Only4 whole nonwalk SW/NE sources replaced by new image_gen costume-band continuity edits; every PNG fully used and all20 affected poses reanalyzed. Living actual sole contact midpoints recalculated and directly reviewed; fixed death column roots retained. All other112 slots from accepted trial05 unchanged. Old sources/candidate/gens/failures preserved.',actual_Main=False,production_imported=False,completed_added=0)
(b/'remaining-roles/union112-registration-trial06-bandfixed.json').write_text(json.dumps(j,indent=2)+'\n');cand.update(status='HOLD_INDEPENDENT_BAND_IDENTITY_REVIEW_AND_ACTUAL_MAIN_PENDING');cand['review']['notes']='Trial06: whole4 source sheets20poses have fresh image_gen anatomical RIGHT-leg costume band corrections. Root accepted previous trial05 static dimensions/roles, but must independently review affected20 and actual Main. Flags remain false; do not count actor from structural preflight.';cpath=b/'remaining-roles/candidate-mixed112-trial06-bandfixed-HOLD.json';cpath.write_text(json.dumps(cand,indent=2)+'\n');proof={'candidate_sha256':hashlib.sha256(cpath.read_bytes()).hexdigest(),'selected_sources':48,'fully_used_distinct_visible_poses':112,'affected_new_poses':20,'whole4_new_source_guards':'PASS','global112_raw_and_visible_unique':'PASS','records':records,'actual_Main':False,'completed_added':0};(b/'remaining-roles/band-identity-fix/trial06-source-geometry-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
s=b/'registered112-registration-trial05';d=b/'registered28-SW-NE-trial06-bandfixed';d.mkdir(exist_ok=True);(d/'project.godot').write_text((s/'project.godot').read_text());c=(s/'render.gd').read_text().replace(str(s),str(d)).replace(str(b/'remaining-roles/union112-registration-trial05.json'),str(b/'remaining-roles/union112-registration-trial06-bandfixed.json')).replace('for direction: String in DIRS:','for direction: String in ["SW","NE"]:').replace('for role: String in ["idle","walk","attack","hit","death"]:','for role: String in []:').replace('"all_sources_shown":112','"all_sources_shown":28').replace('RENDERED112_MANUAL_REGISTRATION_TRIAL04_PENDING_REVIEW','RENDERED28_SW_NE_TRIAL06_BAND_IDENTITY_PENDING_ROOT').replace('TRIAL05 SOURCE RESOLUTION/GROUNDROOT PENDING ROOT REVIEW','TRIAL06 RIGHT LEG BAND IDENTITY PENDING ROOT').replace('RAW112_ROLE_BASELINE_DIAGNOSTIC_OK 8matrices112poses 14role-statics 160atomiccaptureframes Mainfalse completed0','TRIAL06_BANDFIX_2MATRICES28POSES Mainfalse completed0');(d/'render.gd').write_text(c);print(json.dumps(proof,indent=2)[:1000])
