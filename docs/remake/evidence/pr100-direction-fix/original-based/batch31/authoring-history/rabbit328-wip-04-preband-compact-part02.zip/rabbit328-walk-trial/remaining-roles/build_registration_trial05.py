from pathlib import Path
import json,sys,hashlib,math
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');old=json.loads((b/'remaining-roles/union112-manual-registration-trial04.json').read_text());j=json.loads(json.dumps(old));j['status']='TRIAL05_ALL112_SOURCE_RESOLUTION_AND_ACTUAL_BOOT_ROOT_DIAGNOSTIC_PENDING_ROOT_REVIEW';frames=[]
newraw={('W',1):('walk-trial05/W/passing1-leg-proportion.png',2048,[702,1188]),('N',1):('walk-trial05/N/passing1-whole-figure-resolution.png',1888,[647,1157]),('N',3):('walk-trial05/N/passing2-whole-figure-resolution.png',1888,[598,1213])}
nw={0:1848,1:1832,2:1848,3:1880}
for f in j['frames']:
 if f['role']!='walk':continue
 if (f['direction'],f['phase']) in newraw:
  path,canvas,anchor=newraw[(f['direction'],f['phase'])];p=b/path;geom=m.analyze(p,rows_count=1,reference_rows=[0],directions=[f['direction']],canvas_size=canvas,source_anchors=[anchor]);m.require_complete_pose_regions(p,geom);f.update(path=str(p),canvas=canvas,source_anchor=anchor,region=geom['frames'][0]['region'],margin=geom['frames'][0]['margin'],source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_revision='Fresh new art. W passing1 anatomical leg proportion; N passing poses uniform entire-figure resolution redraw preserving original head/core anatomy. Head-only trial05 raw versions rejected for over-shrinking and retained.')
 elif f['direction']=='NW':
  f['canvas']=nw[f['phase']];geom=m.analyze(Path(f['path']),rows_count=1,reference_rows=[0],directions=['NW'],canvas_size=f['canvas'],source_anchors=[f['source_anchor']]);m.require_complete_pose_regions(Path(f['path']),geom);f['region']=geom['frames'][0]['region'];f['margin']=geom['frames'][0]['margin'];f['registration_note']='Whole-source resolution diagnostic from homologous skull/core plus idle/NE comparison. No raw pixel edit; root review pending.'
 f['registration_approved']=False;frames.append(f)
manual={(x['role'],x['direction'],x['phase']):x for x in json.loads((b/'ground-root-manual-review/pending12-boot-component-candidates.json').read_text())};sheets=[]
canvases={('idle','SE-NW'):1104,('attack','SE-NW'):944,('hit','E-W'):1232,('hit','S-N'):1104,('hit','SE-NW'):1104,('hit','SW-NE'):1120,('death','E-W'):1232,('death','S-N'):1200,('death','SE-NW'):1168,('death','SW-NE'):1280}
for s in j['sheets']:
 canvas=canvases.get((s['role'],s['direction']),s['canvas_size']);anchors=[]
 for f in s['geometry']['frames']:
  anchor=f['source_anchor'].copy();manualroot=manual.get((s['role'],f['direction'],f['row']))
  if manualroot:anchor[0]=manualroot['rootX']
  anchors.append(anchor)
 geom=m.analyze(Path(s['output_path']),rows_count=s['rows_count'],reference_rows=s['reference_rows'],directions_axis=s['directions_axis'],directions=s['direction_pair'],canvas_size=canvas,source_anchors=anchors);m.require_complete_pose_regions(Path(s['output_path']),geom)
 s.update(canvas_size=canvas,source_anchors=anchors,geometry=geom,scale_review_note='Author-reviewed trial05 whole-source resolution proposal from same-direction homologous skull/core/limb comparisons; full body height alone was not used as scale basis. Actual boot contact midpoint ground roots; death uses fixed source-column projected roots and actual final ground-body Y. Raw PNG bytes unchanged. Independent root registration/Main gate pending.',independent_registration_approved=False);sheets.append(s)
 for f in geom['frames']:frames.append({**f,'role':s['role'],'phase':f['row'],'path':s['output_path'],'canvas':canvas,'source_sha256':s['source_sha256'],'registration_approved':False})
assert len(frames)==112
rawhash=set();visible=set();slots=set()
from PIL import Image
import numpy as np
for f in frames:
 slot=(f['role'],f['direction'],f['phase']);assert slot not in slots;slots.add(slot)
 x,y,w,h=f['region'];a=np.array(Image.open(f['path']))[y:y+h,x:x+w];rh=hashlib.sha256(a.tobytes()).hexdigest();vh=m._visible_pose_fingerprint(a);assert rh not in rawhash and vh not in visible;rawhash.add(rh);visible.add(vh)
j.update(frames=frames,sheets=sheets,pending_anchor_HOLDs=[],source_contact_review='All12 formerly ambiguous contact pairs directly inspected in source-coordinate boot closeups; selected separated boots have real different-depth soles. Forty-four earlier two-contact roots retained. This is author review, not independent root review.',changes='Trial05 new W passing1 leg length, new two N uniform source-resolution redraws, diagnostic NW walk/idleSE-NW and role-sheet canvas corrections; all old raw sources and rejected head-only N edits retained. No source crop/resample/assembly/mirroring.',quality_flags_false_until_all112_stable=True,actual_Main=False,production_imported=False,completed_added=0,distinct_raw_pose_crops=112,distinct_visible_poses=112,selected_source_pngs=48)
(b/'remaining-roles/union112-registration-trial05.json').write_text(json.dumps(j,indent=2)+'\n')
# Concrete but deliberately non-importable until independent visual gate.
candidate={'input_mode':'mixed_sources_v1','texture_binding':'unchanged_png_metadata','key':'transform:328','prompt':'Fresh 2D authored animation, not original extraction. Exact retained generation prompts and history are under rabbit328-single-pose and remaining-roles. This trial05 source metadata remains pending independent full112 visual registration review and actual Main.','prompt_record_kind':'exact_prompt_files_retained_in_authoring_history','review':{'identity_preserved':False,'eight_views':False,'motion_roles':False,'no_clipping':False,'notes':'WIP trial05. Author visually inspected all112 and physical gait pilots previously accepted, but root independent scale/root review and actual Main have not passed. Do not import by changing flags without actual review.'},'phase_counts':j['counts'],'expected_distinct_poses':112,'sheets':[],'pose_files':[],'source_claim':'new_authored_2d_not_original_extraction','status':'HOLD_INDEPENDENT_VISUAL_AND_MAIN_PENDING','actual_Main':False,'completed_added':0}
for s in sheets:
 candidate['sheets'].append({'id':s['role']+'-'+s['direction'],'output_path':s['output_path'],'source_sha256':s['source_sha256'],'rows':s['rows_count'],'directions':s['direction_pair'],'roles':s['roles'],'canvas_size':s['canvas_size'],'source_anchors':s['source_anchors'],'scale_review_note':s['scale_review_note'],'directions_axis':s['directions_axis'],'reference_rows':s['reference_rows']})
for f in frames:
 if f['role']!='walk':continue
 candidate['pose_files'].append({'id':'walk-'+f['direction']+'-'+str(f['phase']),'output_path':f['path'],'source_sha256':f['source_sha256'],'role':'walk','direction':f['direction'],'phase':f['phase'],'canvas_size':f['canvas'],'source_anchor':f['source_anchor'],'scale_review_note':'Author trial05 source resolution/actual sole anchor proposal; original whole PNG bytes retained, actual opposite physical leg support poses, independent registration review pending.'})
(b/'remaining-roles/candidate-mixed112-trial05-HOLD.json').write_text(json.dumps(candidate,indent=2)+'\n')
s=b/'registered112-manual-trial04';d=b/'registered112-registration-trial05';d.mkdir(exist_ok=True);(d/'project.godot').write_text((s/'project.godot').read_text());code=(s/'render.gd').read_text().replace(str(s),str(d)).replace(str(b/'remaining-roles/union112-manual-registration-trial04.json'),str(b/'remaining-roles/union112-registration-trial05.json')).replace('MANUAL HEAD/GROUNDROOT METADATA UNAPPROVED','TRIAL05 SOURCE RESOLUTION/GROUNDROOT PENDING ROOT REVIEW').replace('for role: String in ["idle","attack","hit","death"]:','for role: String in ["idle","walk","attack","hit","death"]:').replace('role=="idle"','role in ["idle","walk"]').replace('112poses 10role-statics 128atomiccaptureframes','112poses 14role-statics 160atomiccaptureframes');(d/'render.gd').write_text(code)
print('TRIAL05 STRICT WHOLE SOURCE GUARDS AND GLOBAL UNIQUE112 PASS; WIP flags false; no import/Main/count. Diagnostic renderer ready.')
