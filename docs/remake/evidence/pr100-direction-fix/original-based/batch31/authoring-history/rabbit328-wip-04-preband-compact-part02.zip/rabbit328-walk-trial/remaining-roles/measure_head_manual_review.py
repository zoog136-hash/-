from pathlib import Path
import json, numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose'); j=json.loads((b/'remaining-roles/union112-manual-registration-trial04.json').read_text());out=b/'head-measurements-trial05';out.mkdir(exist_ok=True); measurements=[]
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
for d in j['directions']:
 rows=[f for f in j['frames'] if f['direction']==d];rows.sort(key=lambda f:(['idle','walk','attack','hit','death'].index(f['role']),f['phase']))
 contact=Image.new('RGB',(1800,1200),'#343c49');draw=ImageDraw.Draw(contact)
 for k,f in enumerate(rows):
  src=Image.open(f['path']).convert('RGBA');x,y,w,h=f['region'];a=np.array(src)[y:y+h,x:x+w];rgb=a[:,:,:3].astype(int)
  mask=(a[:,:,3]>100)&(rgb[:,:,0]>105)&(rgb[:,:,0]-rgb[:,:,1]>2)&(rgb[:,:,2]-rgb[:,:,1]>4)&(abs(rgb[:,:,0]-rgb[:,:,2])<35)
  yy,xx=np.indices(mask.shape)
  if not(f['role']=='death' and f['phase']==2):mask &= (yy>h*.12)&(yy<h*.48)
  close=ndimage.binary_dilation(mask,iterations=max(2,int(h*.009)))
  labels,n=ndimage.label(close);areas=np.bincount(labels.ravel());areas[0]=0
  if n:
   chosen=int(areas.argmax());hm=mask&(labels==chosen);ys,xs=np.where(hm)
   if len(ys):bb=[int(xs.min()+x),int(ys.min()+y),int(xs.max()+1+x),int(ys.max()+1+y)]
   else:bb=None
  else:bb=None
  m={'direction':d,'role':f['role'],'phase':f['phase'],'path':f['path'],'hair_bbox_proposal':bb,'canvas':f['canvas'],'status':'DIAGNOSTIC_MASK_HOLD_UNTIL_MANUAL_BOUNDARY_REVIEW'}
  if bb:m['normalized_hair_width']= (bb[2]-bb[0])/f['canvas']
  measurements.append(m)
  crop=src.crop((x,y,x+w,y+h)); scale=min(260/w,330/h); crop=crop.resize((round(w*scale),round(h*scale)),Image.Resampling.LANCZOS);px=(k%6)*300+(300-crop.width)//2;py=(k//6)*400+44;contact.paste(crop,(px,py),crop)
  draw.text(((k%6)*300+8,(k//6)*400+5),f"{f['role']} {f['phase']} C{f['canvas']}",fill='white',font=font)
  if bb:
   rect=[px+(bb[0]-x)*scale,py+(bb[1]-y)*scale,px+(bb[2]-x)*scale,py+(bb[3]-y)*scale];draw.rectangle(rect,outline='#55ff55',width=2);draw.text(((k%6)*300+8,(k//6)*400+25),f"hair {bb[2]-bb[0]} / C={m['normalized_hair_width']:.3f}",fill='#55ff55',font=font)
 contact.save(out/f'{d}-hair-proposals-diagnostic.png')
(out/'measurements-raw-proposals.json').write_text(json.dumps({'scope':'Readonly diagnostic; source pixels untouched; no pass or registration approval','measurements':measurements},indent=2)+'\n')
