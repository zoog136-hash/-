from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');j=json.loads((b/'remaining-roles/union112-manual-registration-trial04.json').read_text());fs={(f['role'],f['direction'],f['phase']):f for f in j['frames']};out=b/'ground-root-manual-review';out.mkdir(exist_ok=True);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
for item in j['pending_anchor_HOLDs']:
 f=fs[(item['role'],item['direction'],item['phase'])];x,y,w,h=f['region'];ay=f['source_anchor'][1];top=ay-125;bottom=min(y+h+8,ay+10);crop=Image.open(f['path']).convert('RGBA').crop((x,top,x+w,bottom));z=2;im=Image.new('RGB',(w*z+20,(bottom-top)*z+72),'#343c49');im.paste(crop.resize((w*z,(bottom-top)*z)),(10,48),crop.resize((w*z,(bottom-top)*z)));dr=ImageDraw.Draw(im);dr.text((10,8),f"{f['role']} {f['direction']} {f['phase']} source x{x}..{x+w} y{top}..{bottom}",font=font,fill='white')
 for gx in range((x//50+1)*50,x+w,50):
  px=10+(gx-x)*z;dr.line((px,45,px,im.height),fill='#60916a');dr.text((px,30),str(gx),font=font,fill='#8bff99')
 py=48+(ay-top)*z;dr.line((0,py,im.width,py),fill='#ffcc55',width=2);im.save(out/f"{f['role']}-{f['direction']}-{f['phase']}-feet.png")
