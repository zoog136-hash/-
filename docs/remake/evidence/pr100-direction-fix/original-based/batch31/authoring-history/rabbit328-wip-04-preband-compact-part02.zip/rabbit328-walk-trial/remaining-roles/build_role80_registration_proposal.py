from pathlib import Path
import json, math, sys, statistics
import numpy as np
from scipy import ndimage
from PIL import Image
sys.path.insert(0, '/workspace/twilight/tools')
import import_original_based_motion as motion
b = Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose')
role = json.loads((b/'remaining-roles/selected80-raw-eligible.json').read_text())
walk = json.loads((b/'walk-trial03/selected32-whole-raw-trial03.json').read_text())
target = {d: statistics.median(r['hair_landmark']['width']/r['canvas'] for r in walk['frames'] if r['direction'] == d) for d in walk['directions']}
sheets, frames = [], []
for i, s in enumerate(role['sheets']):
    p = Path(s['output_path'])
    a = np.asarray(Image.open(p))
    measurements, requests = [], []
    required = 64
    for f in s['geometry']['frames']:
        x, y, w, h = f['region']
        ax, ay = f['source_anchor']
        required = max(required, 2*(ax-x), 2*(x+w-ax), (ay-y)/.625, (y+h-ay)/.375)
        if s['role'] == 'death' and f['row'] == 2:
            continue
        top = y+int(h*(.18 if s['role'] == 'death' else .2))
        bottom = y+int(h*(.55 if s['role'] == 'death' else .4))
        section = a[top:bottom, x:x+w]
        c = section[:, :, :3].astype(int)
        mask = ((section[:, :, 3] > 100) & (c[:, :, 0] > 100) & (c[:, :, 2] > c[:, :, 0]) & (c[:, :, 0] > c[:, :, 1]+2) & (c[:, :, 1] > 80) & ((c.max(2)-c.min(2)) < 100))
        closed = ndimage.binary_closing(mask, structure=np.ones((3,3)), iterations=5)
        labels, count = ndimage.label(closed)
        if count:
            areas = np.bincount(labels.ravel())
            areas[0] = 0
            mask = labels == int(areas.argmax())
        if mask.sum() < 100:
            measurements.append({'direction': f['direction'], 'phase': f['row'], 'status': 'INSUFFICIENT_HEAD_COLOR_PIXELS'})
            continue
        ys, xs = np.where(mask)
        width = int(xs.max()+1-xs.min())
        requested = width/target[f['direction']]
        requests.append(requested)
        measurements.append({'direction': f['direction'], 'phase': f['row'], 'status': 'INITIAL_LARGEST_CLOSED_LAVENDER_HEAD_REGION_DIAGNOSTIC', 'head_horizontal_extent': width, 'head_bbox': [int(xs.min()+x), int(ys.min()+top), int(xs.max()+1+x), int(ys.max()+1+top)], 'requested_sheet_canvas_from_walk_head': requested})
    consensus = math.ceil(statistics.median(requests)/8)*8 if requests else 1024
    canvas = min(2048, max(consensus, math.ceil(required/8)*8))
    anchors = [f['source_anchor'] for f in s['geometry']['frames']]
    geometry = motion.analyze(p, rows_count=s['rows_count'], reference_rows=s['reference_rows'], directions_axis=s['directions_axis'], directions=s['direction_pair'], canvas_size=canvas, source_anchors=anchors)
    motion.require_complete_pose_regions(p, geometry)
    new = {k: v for k, v in s.items() if k != 'geometry'}
    new.update(canvas_size=canvas, source_anchors=anchors, geometry=geometry, head_measurements=measurements, head_consensus_canvas=consensus, mandatory_complete_foot_fit_canvas=math.ceil(required/8)*8, metadata_approved=False)
    sheets.append(new)
    for f in geometry['frames']:
        frames.append({**f, 'role': s['role'], 'phase': f['row'], 'path': str(p), 'canvas': canvas, 'sheet_index': i, 'source_sha256': s['source_sha256'], 'metadata_approved': False})
out = {'key': 'transform:328', 'status': 'ROLE80_V2_HEAD_COMPONENT_RESOLUTION_PROPOSAL_PENDING_VISUAL_REVIEW', 'target_normalized_walk_head_width': target, 'method': 'Readonly lavender B>R,R>G+2 headcolour, binaryclose5pixels thenlargestheadcomponent inheadband; noRGB/artedits. This avoids whitecuff/raisedarm unioncontamination; original broadmaskv1held andpreserved. Medianper-sheetresolutionproposal only. Death uses rows0/1 only, final corpse excluded from scale basis. Every wholebody footfit/complete guard unchanged. Existing anchors kept, not head-follow for attack/hit recoil. No anatomy PASS from measurements.', 'scale_limits': 'Colour mask is approximate and may include occluded hair/collar; independent head/torso/leg/floor review mandatory. Uniform sheet canvas does not correct actual proportions. No production apply or Main claim.', 'sheets': sheets, 'frames': frames, 'all80_visible_unique_unchanged': True, 'actual_Main': False, 'production_imported': False, 'completed_added': 0}
(b/'remaining-roles/role80-head-registration-proposal.json').write_text(json.dumps(out, indent=2)+'\n')
for s in sheets:
    print(s['role'], s['direction'], 'canvas', s['canvas_size'], 'from', s['head_consensus_canvas'], 'footmin', s['mandatory_complete_foot_fit_canvas'])
