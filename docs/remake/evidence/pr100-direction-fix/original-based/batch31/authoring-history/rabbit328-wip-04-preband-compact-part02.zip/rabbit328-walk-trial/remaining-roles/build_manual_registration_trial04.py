from pathlib import Path
import json,sys
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as motion
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');w=json.loads((b/'walk-trial03/selected32-whole-raw-trial03.json').read_text());r=json.loads((b/'remaining-roles/selected80-raw-eligible.json').read_text());contacts=json.loads((b/'remaining-roles/living-ground-contact-root-proposals.json').read_text());lookup={(x['role'],x['direction'],x['phase']):x for x in contacts['frames']};frames=[];notes=[]
for entry in w['frames']:
 f=entry.copy();f['role']='walk';f['phase']=['A','passing1','B','passing2'].index(entry['phase'])
 if f['direction']=='N' and f['phase'] in [0,2]:
  f['canvas']=2048;x,y,width,height=f['region'];ax,ay=f['source_anchor'];f['margin']=[1024-(ax-x),1280-(ay-y),2048-width,2048-height];f['registration_note']='Manualrootdiagnostic: near2048canvasfromNidle/actualskull+core comparison, notsilhouetteheightfit; sourcePNGunchanged, parentfinalreviewpending.'
 motion.require_complete_pose_regions(Path(f['path']),motion.analyze(Path(f['path']),rows_count=1,reference_rows=[0],directions=[f['direction']],canvas_size=f['canvas'],source_anchors=[f['source_anchor']]))
 frames.append(f)
sheets=[]
for s in r['sheets']:
 canvas=1232 if s['role']=='hit' and s['direction']=='E-W' else s['canvas_size'];anchors=[]
 for f in s['geometry']['frames']:
  anchor=f['source_anchor'].copy();contact=lookup.get((s['role'],f['direction'],f['row']))
  if contact and contact['proposed_groundroot_X_two_soles_only'] is not None:anchor[0]=contact['proposed_groundroot_X_two_soles_only']
  elif contact:notes.append({'role':s['role'],'direction':f['direction'],'phase':f['row'],'status':'ANCHOR_X_HOLD_MANUAL_REVIEW_NEEDED','retained_source_anchor':anchor})
  anchors.append(anchor)
 geometry=motion.analyze(Path(s['output_path']),rows_count=s['rows_count'],reference_rows=s['reference_rows'],directions_axis=s['directions_axis'],directions=s['direction_pair'],canvas_size=canvas,source_anchors=anchors);motion.require_complete_pose_regions(Path(s['output_path']),geometry)
 sheet={**s,'canvas_size':canvas,'source_anchors':anchors,'geometry':geometry,'independent_registration_approved':False};sheets.append(sheet)
 for f in geometry['frames']:frames.append({**f,'role':s['role'],'phase':f['row'],'path':s['output_path'],'canvas':canvas,'source_sha256':s['source_sha256'],'registration_approved':False})
assert len(frames)==112
out={'key':'transform:328','status':'TRIAL04_MANUAL_HEAD_AND_TWO_BOOT_GROUNDROOT_METADATA_DIAGNOSTIC_ONLY','directions':w['directions'],'counts':{'idle':2,'walk':4,'attack':3,'hit':2,'death':3},'seconds':{'idle':1.2,'walk':.48,'attack':.42,'hit':.22,'death':.65},'frames':frames,'sheets':sheets,'pending_anchor_HOLDs':notes,'changes':'E/W hit1232canvas fromindependentheadsizecomparison(~20%oversizebaseline), NwalkA/B2048canvas fromactualhead/corecomparedNidle. 44livinggroundroots usebothsolecontactmidpoint, lowestsoleYretained. Other12livingrootsHOLD, deathfixedcolumnrootsseparatereview. No sourcepixelartchanges or guardrelaxation.','quality_flags_false_until_all112_stable':True,'actual_Main':False,'production_imported':False,'completed_added':0}
(b/'remaining-roles/union112-manual-registration-trial04.json').write_text(json.dumps(out,indent=2)+'\n');print('validated112, livingrootHOLD',len(notes))
s=b/'registered112-role-baseline';d=b/'registered112-manual-trial04';d.mkdir(exist_ok=True);(d/'project.godot').write_text((s/'project.godot').read_text());code=(s/'render.gd').read_text().replace(str(s),str(d)).replace(str(b/'remaining-roles/union112-default-role-canvas-diagnostic.json'),str(b/'remaining-roles/union112-manual-registration-trial04.json')).replace('ROLE80 DEFAULT1024 CANVAS UNREGISTERED','MANUAL HEAD/GROUNDROOT METADATA UNAPPROVED').replace('UNREGISTERED DEFAULT1024 CANVAS','MANUAL HEAD/GROUNDROOT METADATA UNAPPROVED').replace('RENDERED112_RAW_ROLE_BASELINE_ONLY_UNREGISTERED80','RENDERED112_MANUAL_REGISTRATION_TRIAL04_PENDING_REVIEW');(d/'render.gd').write_text(code)
