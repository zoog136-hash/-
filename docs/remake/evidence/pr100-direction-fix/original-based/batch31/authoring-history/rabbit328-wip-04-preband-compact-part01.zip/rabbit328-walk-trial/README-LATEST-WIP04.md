# transform328 WIP04 resume

Restore WIP02 parts, WIP03 parts, then WIP04 parts into the same rabbit328-walk-trial folder. Read LATEST-WIP04-CHECKPOINT.json first. All112 rawpose candidates exist; this is not completed328 and no actualMain verification.

Three post03 fresh anatomy candidates are in walk-trial02/W,SW,SE, with exact prompts/rawPNG/SHA. Currenttrial03selection points to these candidates but they are independentlyunapproved. Wpassing1 mayhaveovershortened. Allotherrawsources/acceptedEpilotunchanged. Read all8 physicalpilotacceptance separatelyfrom unresolvedproportion/registration.

ActualGodot112rolebaseline shows all14posesperdirection,10rolephase8dirscreens,128atomicactualreplaycaptures andreal-timestampVFRMP4s. This uses unchangeddefault1024canvasesfor80roles; head/core/floor registration notapproved. Failedautomaticcolourmask scale proposals v1/v2 areHOLD and neverapplied. Need manualhomologousskull+torso/jointreview, notsilhouettefit.

Older raw history is retained inWIP02/03 archives withSHA. Allnewpersistedart/prompts/failures/code/reports/representativesincluded. RedundantloopPNGbodyexcludedwithSHA; sourcePNGbytesunchanged. Productionimport/Main/attack-hit/drop/pickup/CI/commits belongtoparent; this scratch author made no repo/map/profile/guardchanges.
