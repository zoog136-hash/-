from pathlib import Path
import json,subprocess,hashlib
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');results=[]
for dirname in ['registered112-registration-trial05','registered16-hit-temporal-trial05']:
 d=b/dirname;j=json.loads((d/'godot-preview.json').read_text())
 for r in j['role_previews']:
  role=r['role'];entries=r['playback'];lines=[];frames=[]
  for i,e in enumerate(entries):
   p=d/(role+'-loop-frames')/(str(e['capture']).zfill(3)+'.png');duration=(entries[i+1]['pre_draw_ticks_msec']-e['pre_draw_ticks_msec'])/1000 if i+1<len(entries) else (e['pre_draw_ticks_msec']-entries[i-1]['pre_draw_ticks_msec'])/1000;duration=max(.001,duration);lines.extend(["file '"+str(p)+"'",f'duration {duration:.6f}']);frames.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pre_draw_ticks_msec':e['pre_draw_ticks_msec'],'duration_sec':duration,'actors':e['actors']})
  lines.append("file '"+str(p)+"'");playlist=d/(role+'-actual-timing.concat.txt');playlist.write_text('\n'.join(lines)+'\n');out=d/(role+'-actual-timing.mp4');cmd=['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(playlist),'-c:v','libx264','-threads','1','-crf','18','-preset','veryfast','-pix_fmt','yuv420p','-fps_mode','vfr','-video_track_timescale','1000',str(out)];subprocess.run(cmd,check=True);results.append({'directory':dirname,'role':role,'video':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'not_a_fixed30fps_reconstruction':True,'actual_Main':False,'capture_throughput_not_game_fps':True,'frames':frames})
(b/'trial05-actual-timing-videos.json').write_text(json.dumps(results,indent=2)+'\n');print([(x['directory'],x['role'],x['bytes']) for x in results])
