extends SceneTree
const OUT="/workspace/scratch/pr100-continuation/rabbit328-single-pose/homologous-landmark-diagnostic"
const BASE="/workspace/scratch/pr100-continuation/rabbit328-single-pose"
class Marks extends Node2D:
 var hair: Rect2
 var collar: Vector2
 var waist: Vector2
 var floor_y: float
 func _draw() -> void:
  draw_rect(hair,Color("70ccff"),false,2)
  draw_line(collar,waist,Color("ffaa55"),3)
  draw_circle(collar,4,Color("ffaa55"))
  draw_circle(waist,4,Color("ffaa55"))
func label_at(text: String,point: Vector2,size: int=17) -> void:
 var label:=Label.new()
 label.text=text
 label.position=point
 label.add_theme_font_size_override("font_size",size)
 root.add_child(label)
func _initialize() -> void:call_deferred("run")
func run() -> void:
 var background:=ColorRect.new()
 background.color=Color("343c49")
 background.size=Vector2(1200,1100)
 root.add_child(background)
 var report: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(BASE+"/walk-trial02/homologous-skull-core-landmark-diagnostic.json"))
 var selection: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(BASE+"/walk-trial02/selected32-whole-raw-trial02.json"))
 var names: Array[String]=["NW_A","NW_B","SW_A","SW_B"]
 label_at("MANUAL PROJECTED LANDMARK DIAGNOSTIC | +/-15 source px | NOT ANATOMICAL PASS / NOT MAIN",Vector2(12,8),19)
 for i: int in range(4):
  var rec: Dictionary=report.records[names[i]]
  var entry: Dictionary={}
  for f: Dictionary in selection.frames:
   if f.path==rec.path:entry=f
  assert(not entry.is_empty())
  var image:=Image.new()
  assert(image.load(rec.path)==OK)
  var atlas:=AtlasTexture.new()
  atlas.atlas=ImageTexture.create_from_image(image)
  atlas.region=Rect2(entry.region[0],entry.region[1],entry.region[2],entry.region[3])
  atlas.margin=Rect2(entry.margin[0],entry.margin[1],entry.margin[2],entry.margin[3])
  var scale: float=760.0/float(entry.canvas)
  var world:=Vector2(300+(i%2)*600,500+(i/2)*520)
  var source_anchor:=Vector2(entry.source_anchor[0],entry.source_anchor[1])
  var sprite:=Sprite2D.new()
  sprite.texture=atlas
  sprite.scale=Vector2.ONE*scale
  sprite.position=world-Vector2(0,95)
  root.add_child(sprite)
  var mark:=Marks.new()
  var h: Array=rec.skull_hair_envelope_approx
  var top:=world+(Vector2(h[0],h[1])-source_anchor)*scale
  mark.hair=Rect2(top,Vector2(h[2]-h[0],h[3]-h[1])*scale)
  mark.collar=world+(Vector2(rec.collar_base[0],rec.collar_base[1])-source_anchor)*scale
  mark.waist=world+(Vector2(rec.waist_back_bow_root[0],rec.waist_back_bow_root[1])-source_anchor)*scale
  root.add_child(mark)
  label_at(names[i]+" | hairW "+str(rec.hair_width_px)+" | core "+str(snappedf(rec.collar_to_waist_projected_length_px,0.1)),Vector2((i%2)*600+15,38+(i/2)*520),18)
  label_at("Blue: silver-hair/skull envelope, cap/ears excluded",Vector2((i%2)*600+15,460+(i/2)*520),15)
  label_at("Orange: homologous collar-to-waist estimate; inferred",Vector2((i%2)*600+15,480+(i/2)*520),15)
 await process_frame
 await RenderingServer.frame_post_draw
 assert(root.get_texture().get_image().save_png(OUT+"/landmark-comparison.png")==OK)
 print("HOMOLOGOUS_LANDMARK_DIAGNOSTIC_ONLY_OK")
 quit(0)
