from pathlib import Path
import json,zipfile,hashlib,datetime
b=Path('/workspace/scratch/pr100-continuation/rabbit328-single-pose');prior=Path('/workspace/twilight/docs/remake/evidence/pr100-direction-fix/original-based/resumed-wip/rabbit328-current');out=Path('/workspace/scratch/pr100-continuation/rabbit328-portable');out.mkdir(exist_ok=True);prefix='rabbit328-walk-trial/';known={};parts_prior=[]
for zpath in sorted(prior.glob('rabbit328-wip-0[23]-compact-part*.zip')):
 parts_prior.append({'name':zpath.name,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'bytes':zpath.stat().st_size})
 with zipfile.ZipFile(zpath) as z:
  for name in z.namelist():
   if 'INCLUDED-FILES-SHA256' in name:
    for f in json.loads(z.read(name)):known[f.get('package_path',f.get('path'))]=f['sha256']
checkpoint={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'key':'transform:328','status':'WIP04_PRE_BAND_IDENTITY_FIX_TRIAL05_STATIC_READY_MAIN_NOT_RUN','latest_candidate':'remaining-roles/candidate-mixed112-trial05-HOLD.json','candidate_sha256':hashlib.sha256((b/'remaining-roles/candidate-mixed112-trial05-HOLD.json').read_bytes()).hexdigest(),'latest_source_matrix':'remaining-roles/union112-registration-trial05.json','root_review':'Root directly viewed all112 and accepted static proportions/wholebody/headings/roles for Main trial, pending actual anatomical RIGHT upper-leg band correction in SW/NE nonwalk source sheets. No Main/completion approval.','source_count':48,'distinct_visible_poses':112,'new_selected_art_since_WIP03':['walk-trial02/W/passing1-anatomical-proportion-fix.png','walk-trial02/SW/B-homologous-head-core-fix.png','walk-trial02/SE/B-anatomical-core-leg-fix.png','walk-trial05/W/passing1-leg-proportion.png','walk-trial05/N/passing1-whole-figure-resolution.png','walk-trial05/N/passing2-whole-figure-resolution.png'],'rejected_new_head_only_raws_preserved':['walk-trial05/N/passing1-head-proportion.png','walk-trial05/N/passing2-head-proportion.png'],'active_next':'image_gen corrections of costume right-leg band, preserving exact whole-sheet layouts/poses/anatomy. idle4 and attack6 allSW/NE, hit4 topSW only, death6 NE initialslump only. Exact prompts inremaining-roles/band-identity-fix. Outputs not part of this pre-band frozen checkpoint; future version must reference new hashes.','diagnostic':'All8 trial05 matrices112, actual8dir autorun idle2/walk4/attack3/death3 phases observed. Full-size hit capture gap preserved; focused unchanged0.22s800x500 hit16 captured both phases, atomic label/pose checks PASS. These are scratch diagnostic scenes, not actual Main or performance claims.','expected_false_flags_preflight':'remaining-roles/trial05-readonly-preflight-expected-rejection.json; actual CLI rejects false flags and leaves profile/folder unchanged.','actual_Main':False,'production_imported':False,'completed_added':0,'restore':'Restore prior WIP02 and WIP03 archives first, then extract all WIP04 delta parts into the same folder. Their rabbit328-walk-trial/ trees merge. Historical /workspace paths should resolve to the restored folder; preserve own raw files; no source assembly or software art edits. Required prior part SHA listed.'};(b/'LATEST-WIP04-TRIAL05-PREBAND-CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2)+'\n');items=[];allsha=[];excluded=[]
for p in sorted(b.rglob('*')):
 if not p.is_file() or '.godot' in p.parts or any(x.startswith('xdg-') for x in p.parts):continue
 data=p.read_bytes();rel=str(p.relative_to(b));arc=prefix+rel;sha=hashlib.sha256(data).hexdigest();record={'path':rel,'bytes':len(data),'sha256':sha};allsha.append(record)
 if known.get(arc)==sha:continue
 if (p.suffix=='.png' and any('loop-frames' in x for x in p.parts)) or (p.suffix=='.png' and p.stem.isdigit()) or p.suffix=='.gif':excluded.append({**record,'reason':'Redundant raw diagnostic capture body; actual-timestamp MP4, static representatives and exact complete SHA/timing logs included.'});continue
 items.append((arc,data))
extras={'PORTABLE-INDEX-WIP04-PREBAND.json':{'checkpoint':checkpoint,'required_prior_parts':parts_prior,'prior_identical_entries_omitted':True,'raw_source_revisions_and_failures_kept':True},'ALL-SOURCE-EVIDENCE-SHA256-WIP04.json':allsha,'EXCLUDED-CAPTURE-BODIES-SHA256-WIP04.json':excluded,'README-WIP04-PREBAND.txt':'WIP ONLY, transform328 not complete; no actual Main or production import. Merge WIP02 + WIP03 before this delta. Read LATEST-WIP04-TRIAL05-PREBAND-CHECKPOINT.json and focused-trial05-calibration/author-review-trial05.json. The immutable trial05 candidate flags are false and expected-reject CLI proof is included. Pending band-identity fixes will create separately versioned raw outputs; do not overwrite selected source PNGs or old candidate evidence. Godot diagnostic MP4 timing uses actual capture timestamps, not fabricated30fps smoothness; throughput is not game performance.\n'}
for name,value in extras.items():items.append((prefix+name,(value if isinstance(value,str) else json.dumps(value,indent=2)+'\n').encode()))
manifest=[{'package_path':p,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for p,data in items];items.append((prefix+'INCLUDED-FILES-SHA256-WIP04-PREBAND.json',(json.dumps(manifest,indent=2)+'\n').encode()));parts=[];cur=[];size=0
for item in items:
 if cur and size+len(item[1])>44_000_000:parts.append(cur);cur=[];size=0
 cur.append(item);size+=len(item[1])
if cur:parts.append(cur)
outputs=[]
for n,part in enumerate(parts,1):
 zpath=out/f'rabbit328-wip-04-preband-compact-part{n:02d}.zip'
 with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
  for arc,data in part:z.writestr(arc,data)
 assert zpath.stat().st_size<90_000_000
 with zipfile.ZipFile(zpath) as z:
  assert z.testzip() is None
  for arc,data in part:assert hashlib.sha256(z.read(arc)).hexdigest()==hashlib.sha256(data).hexdigest()
 outputs.append({'path':str(zpath),'bytes':zpath.stat().st_size,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'entries':len(part)})
index={'label':'wip-04-preband-delta-trial05','status':checkpoint['status'],'candidate_sha256':checkpoint['candidate_sha256'],'required_prior_parts':parts_prior,'parts':outputs,'included_entries':sum(len(x) for x in parts),'excluded_capture_bodies':len(excluded),'Main':False,'completed_added':0};(out/'rabbit328-wip-04-preband-compact-archive-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps(index,indent=2))
