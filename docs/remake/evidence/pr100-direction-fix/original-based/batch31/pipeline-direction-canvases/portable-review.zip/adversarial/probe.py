from pathlib import Path
import json,sys,copy,hashlib,re
sys.path.insert(0,'/workspace/twilight/tests');import test_original_based_direction_canvases as t
b=Path('/workspace/scratch/pr100-continuation/per-direction-canvas-adversarial-review');root=b/'fixture';root.mkdir();candidate,keys,folder=t.DirectionCanvasTest().fixture(root);t.importer.import_sheet(root,candidate,'fixture',keys,True);proofpath=folder/'provenance.json';resourcepath=folder/'SpriteFrames.tres';proofbytes=proofpath.read_bytes();resource=resourcepath.read_text();orig=json.loads(proofbytes);tracked={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()};asset='res://'+str(resourcepath.relative_to(root));baseline=t.audit.audit_resource(root,asset,tracked);assert baseline['errors']==[]
results=[]
def check(name,change_proof=None,change_resource=None,meaning=''):
 p=copy.deepcopy(orig);r=resource
 if change_proof:change_proof(p)
 if change_resource:r=change_resource(r)
 proofpath.write_text(json.dumps(p));resourcepath.write_text(r);out=t.audit.audit_resource(root,asset,tracked);results.append({'case':name,'audit_errors':out['errors'],'auditor_pixel_integrity':out['pixel_integrity'],'meaning':meaning})
check('runtime_normalization_metadata_doubled',change_resource=lambda r:r.replace('metadata/twilight_canvas_size = Vector2(256, 256)','metadata/twilight_canvas_size = Vector2(512, 512)'),meaning='ActorMotion.apply lines297-302 multiplies actual sprite scale by metadata/pose size. This tamper doubles all world size/foot offset geometry while audit still may pass.')
check('runtime_normalization_metadata_removed',change_resource=lambda r:r.replace('metadata/twilight_canvas_size = Vector2(256, 256)\n',''),meaning='No normalization: actual variable canvas96..208 retains different world scales and foot roots bydirection; no native image was changed.')
def strip(p):
 for s in p['source_files']:
  for k in ['canvas_sizes_by_direction','feet_by_direction','canvas_size_basis']:s.pop(k,None)
 for tr in p['tracks'].values():
  for a in tr['atlas_files']:
   for k in ['canvas_sizes_by_direction','feet_by_direction','canvas_size_basis']:a.pop(k,None)
 for f in p['frames']:
  f.pop('canvas_size',None);f.pop('foot',None)
 for record in p['source_poses']:
  source=next(s for s in p['source_files'] if s['source_id']==record['source_id']);record['canvas_size']=source['canvas_size'][0]
check('direction_map_and_frame_tags_stripped_but_actual_canvases_still_variable',change_proof=strip,meaning='Stripping optional map tags makes new auditor return early; proof now claims uniform source maximum while real AtlasTexture canvases remain variable. Perdirection footprint no longer independently verified.')
check('actual_fractional_margin_hidden_by_reader_truncation',change_resource=lambda r:re.sub(r'(margin = Rect2\()(-?\d+)',lambda m:m[1]+str(float(m[2])+.75),r,count=1),meaning='read_spriteframes converts float toint before actual comparison; noninteger real Godot foot shift ignored.')
check('phase_bool_in_frame',change_proof=lambda p:p['frames'][0].update(phase=False),meaning='Should reject bool phase, not confuse with0.')
check('source_pose_frame_wrong',change_proof=lambda p:p['source_poses'][0].update(source_frame=99),meaning='Should reject local source frame/order inconsistency.')
proofpath.write_bytes(proofbytes);resourcepath.write_text(resource);assert t.audit.audit_resource(root,asset,tracked)['errors']==[]
report={'scope':'Read-only code review and synthetic scratch probes only; no production/test/tool edits','code_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('/workspace/twilight/tools/import_original_based_motion.py'),Path('/workspace/twilight/tools/audit_eight_direction_coverage.py'),Path('/workspace/twilight/tests/test_original_based_direction_canvases.py')]},'baseline_errors':baseline['errors'],'results':results,'fixture_restored':True,'production_Main_or_art':False};(b/'review-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(results,indent=2))
