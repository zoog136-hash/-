from pathlib import Path
import sys,json,hashlib
import numpy as np
from PIL import Image
from scipy import ndimage
sys.path.insert(0,"/workspace/twilight/tools")
import import_original_based_motion as m
p=Path(sys.argv[1]); out=p.with_suffix(".geometry.json")
a=np.asarray(Image.open(p)); alpha=a[:,:,3]
result={"path":str(p),"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"image_size":[a.shape[1],a.shape[0]],"mode":Image.open(p).mode,"directions_axis":"columns","rows":3,"reference_rows":[2],"source_pixels_modified":False,"scale_limit":"Fit canvas only. Cross-role size and anchor approval requires final idle reference and independent review; no production import."}
try:
    geometry=None
    for canvas in range(64,2049,8):
        try:
            geometry=m.analyze(p,rows_count=3,reference_rows=[2],directions_axis="columns",canvas_size=canvas)
            m.require_complete_pose_regions(p,geometry)
            break
        except ValueError as e:
            if str(e)!="Pose cannot fit the foot-anchored canvas":
                raise
    if geometry is None:raise ValueError("No reviewed fit canvas within supported range")
    result.update(pass_geometry=True,geometry=geometry,fit_canvas=geometry["canvas_size"],distinct=geometry["distinct_pixel_frames"])
except Exception as e:
    result.update(pass_geometry=False,error=str(e))
visible=alpha>100
labels,n=ndimage.label(visible); counts=np.bincount(labels.ravel()); boxes=ndimage.find_objects(labels)
bodies=[(i+1,int(c),boxes[i])for i,c in enumerate(counts[1:])if c>=200]
result["opaque_body_count_ge_200"]=len(bodies)
result["visible_boundary_pixels"]=int(sum(np.count_nonzero(x>100)for x in (alpha[0],alpha[-1],alpha[:,0],alpha[:,-1])))
result["transparent_alpha0_pixels"]=int(np.count_nonzero(alpha==0))
dist=ndimage.distance_transform_edt(~visible)
far=(alpha>25)&(dist>3)
result["alpha_gt25_pixels_farther_than_3px_from_opaque_body"]=int(np.count_nonzero(far))
result["max_alpha_distance_gt25"]=float(dist[alpha>25].max()) if np.any(alpha>25) else 0
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({k:result[k]for k in ("path","bytes","sha256","pass_geometry","opaque_body_count_ge_200","visible_boundary_pixels","alpha_gt25_pixels_farther_than_3px_from_opaque_body")},ensure_ascii=False))
if "error"in result:print(result["error"])
