from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).parent;O=D/'portable-checkpoint-v01';O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((D/'candidate-scale-trial02-HOLD.json').read_text()); selected={Path(s['output_path']).resolve() for s in c['sheets']}
files=[p for p in D.rglob('*') if p.is_file() and O not in p.parents and '-on-black.png' not in p.name and '-on-white.png' not in p.name and '__pycache__' not in p.parts]
# Selected full source PNGs are first. All failed raw outputs/prompts/request metadata remain in later entries.
files=sorted(files,key=lambda p:(0 if p.resolve() in selected else 1,str(p.relative_to(D))))
manifest=[];parts=[];groups=[];group=[];total=0
for p in files:
 size=p.stat().st_size
 if group and total+size>86_000_000:groups.append(group);group=[];total=0
 group.append(p);total+=size
if group:groups.append(group)
for i,group in enumerate(groups,1):
 path=O/f'nungma-raw104-history-v01-part{i:02d}.zip'
 assert not path.exists(),path
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
  for p in group:
   rel=Path('nungma-authoring')/p.relative_to(D);z.write(p,str(rel),compress_type=zipfile.ZIP_STORED if p.suffix=='.png' else zipfile.ZIP_DEFLATED)
   manifest.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p),'selected_whole_source':p.resolve() in selected,'part':path.name})
 assert path.stat().st_size<90_000_000
 with zipfile.ZipFile(path) as z:
  for r in manifest:
   if r['part']==path.name:assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
 parts.append({'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path),'entry_count':len(group)})
index={'key':'monster:넝마','status':'104_STATIC_SOURCE_PREPARED_ROOT_ACTUAL_MAIN_PENDING','completion_added':0,'production_imported_by_author':False,'frozen_candidate':'nungma-authoring/candidate-scale-trial02-HOLD.json','frozen_candidate_sha256':sha(D/'candidate-scale-trial02-HOLD.json'),'source_proof':'nungma-authoring/source-proof.json','author_review':'nungma-authoring/AUTHOR_STATIC_REVIEW_TRIAL02.json','restore_root':'/workspace/scratch/pr100-continuation','restore_rule':'Verify ZIP SHA, extract under restore_root with no existing differing-path overwrite, then verify every entry SHA. Preserve all raw attempts. Candidate contains absolute historical scratch paths; source-proof explains relocated exact original context. Root owns any flag approval/import/Main.','selected_whole_pngs':28,'selected_poses':104,'source_png_bytes':sum(p.stat().st_size for p in selected),'uncompressed_rgba8_MiB':168,'omitted_files':'Only redundant black/white composited diagnostics and pycache; all generated raw PNGs, exact prompts, request JSON, generation/audit metadata, source proofs, selected/failure history and matrix diagnostics included.','parts':parts,'files':manifest}
(O/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'index':str(O/'index.json'),'parts':parts,'selected_whole_sources':len(selected),'entry_count':len(manifest),'candidate_sha256':index['frozen_candidate_sha256']}))
