from pathlib import Path
import json,re,shutil,sys
import numpy as np
from PIL import Image
from scipy import ndimage
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as imp
D=Path(__file__).parent;plans=json.loads((D/'planned-role-batches.json').read_text()); all_reports=[]
for meta_path in sorted(D.glob('*-generation.json')):
 meta=json.loads(meta_path.read_text());meta.pop('image_url',None);stem=meta_path.name.removesuffix('-generation.json');match=re.search(r'/workspace/generated_images/[^\s]+\.png',meta['output_hint']);source=Path(match.group(0));target=D/(stem+'.png')
 if not target.exists():shutil.copyfile(source,target)
 assert imp.sha(source)==imp.sha(target)
 meta['raw_png']=str(target);meta['raw_png_sha256']=imp.sha(target);meta_path.write_text(json.dumps(meta,indent=2)+'\n')
 spec=next(x for x in plans if x['stem']==stem);r={**spec,'source':str(source),'output_path':str(target),'source_sha256':imp.sha(target),'selected':False,'visual_review':'pending'}
 with Image.open(target) as im:
  r['image_size']=list(im.size);r['alpha_extrema']=im.getchannel('A').getextrema();pixels=np.asarray(im)
  labels,n=ndimage.label(pixels[:,:,3]>100);areas=np.bincount(labels.ravel()); boxes=ndimage.find_objects(labels)
  r['body_components']=[{'area':int(a),'box':[b[1].start,b[0].start,b[1].stop,b[0].stop]} for a,b in zip(areas[1:],boxes) if a>=200]
  for bg in ['black','white']:
   out_path=D/(stem+'-on-'+bg+'.png')
   if not out_path.exists():
    out=Image.new('RGBA',im.size,bg);out.alpha_composite(im);out.convert('RGB').save(out_path)
 try:
  g=imp.analyze(target,rows_count=spec['rows'],reference_rows=[0],directions=spec['directions'],canvas_size=spec.get('canvas_size',1024),directions_axis=spec.get('directions_axis','columns'));imp.require_complete_pose_regions(target,g);r['geometry_status']='PASS';r['geometry']=g
 except Exception as e:r['geometry_status']='FAIL';r['error']=str(e)
 audit_path=D/(stem+'-audit.json')
 if audit_path.exists():
  old=json.loads(audit_path.read_text());r['visual_review']=old.get('visual_review','pending');r['selected']=old.get('selected',False)
 audit_path.write_text(json.dumps(r,indent=2)+'\n');all_reports.append(r)
 print(stem,r['geometry_status'],r.get('error',''),len(r['body_components']))
(D/'all-role-batches-numeric-audit.json').write_text(json.dumps(all_reports,indent=2)+'\n')
