from pathlib import Path
import json,hashlib,sys
import numpy as np
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as imp
D=Path(__file__).parent
stems=['idle-E-SE-S-SW-role-attempt1','idle-W-NW-N-NE-role-attempt1','hit-E-SE-S-SW-role-attempt1','hit-W-NW-N-NE-role-attempt1','walk-E-vertical-attempt2','walk-SE-guided-attempt3','walk-S-SW-role-attempt1','walk-W-spacing-attempt4','walk-NW-spacing-attempt4','walk-N-vertical-attempt2','walk-NE-guided-attempt3','attack-E-guided-attempt1','attack-SE-spacing-attempt2','attack-S-guided-attempt1','attack-SW-spacing-attempt2','attack-W-spacing-attempt2','attack-NW-spacing-attempt2','attack-N-guided-attempt1','attack-NE-guided-attempt1']+['death-'+x+'-guided-attempt1' for x in ['E','SE','S','SW','W','NW','N','NE']]
result=[];raw=set();visible=set();all_poses=[]
for stem in stems:
 audit=json.loads((D/(stem+'-audit.json')).read_text());path=D/(stem+'.png')
 # This large canvas proves complete-source geometry only. It is not a reviewed shipping scale.
 g=imp.analyze(path,rows_count=audit['rows'],reference_rows=[0],directions=audit['directions'],canvas_size=2048,directions_axis=audit.get('directions_axis','columns'))
 imp.require_complete_pose_regions(path,g)
 arr=np.asarray(Image.open(path))
 for f in g['frames']:
  x,y,w,h=f['region'];a=arr[y:y+h,x:x+w];rh=hashlib.sha256(a.tobytes()).hexdigest();vh=imp._visible_pose_fingerprint(a)
  assert rh not in raw and vh not in visible,stem
  raw.add(rh);visible.add(vh)
  all_poses.append({'role':audit['role'],'direction':f['direction'],'phase':f['row'],'source':str(path),'region':f['region'],'raw_sha256':rh,'visible_sha256':vh})
 result.append({'stem':stem,'role':audit['role'],'directions':audit['directions'],'rows':audit['rows'],'directions_axis':audit.get('directions_axis','columns'),'source':str(path),'sha256':imp.sha(path),'strict_complete_geometry_diagnostic':g,'shipping_scale_review':'HOLD - 2048 canvas is geometry-only, not a proposed runtime scale'})
assert len(all_poses)==104
for role,n in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)]:
 for direction in imp.DIRECTIONS:assert sorted(x['phase'] for x in all_poses if x['role']==role and x['direction']==direction)==list(range(n))
out={'key':'monster:넝마','status':'RAW_104_COMPLETE_GLOBAL_UNIQUE_SCALE_ANCHORS_ROOT_MAIN_PENDING','completed_added':0,'source_proof':json.loads((D/'source-audit.json').read_text()),'newly_authored_not_original_extraction':True,'whole_sources':result,'poses':all_poses,'strict_complete_geometry':True,'raw_unique':len(raw),'visible_unique':len(visible),'review':{'identity_preserved':False,'eight_views':False,'motion_roles':False,'no_clipping':False},'actual_Main':'not_run','production_imported':False}
(D/'selected104-source-geometry-HOLD.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'poses':len(all_poses),'whole_raw_pngs':len(result),'global_visible_unique':len(visible),'status':out['status']}))
