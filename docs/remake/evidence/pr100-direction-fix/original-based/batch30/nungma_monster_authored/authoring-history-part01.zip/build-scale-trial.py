from pathlib import Path
import sys,json,hashlib
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as imp
D=Path(__file__).parent
# canvas and fixed neutral torso projection, not moving fingertips or tail midpoint.
specs=[
('idle-E-SE-S-SW-role-attempt1','idle',['E','SE','S','SW'],2,1024,[270,650,994,1330]),
('idle-W-NW-N-NE-role-attempt1','idle',['W','NW','N','NE'],2,1024,[160,554,951,1350]),
('hit-E-SE-S-SW-role-attempt1','hit',['E','SE','S','SW'],2,1024,[270,650,994,1330]),
('hit-W-NW-N-NE-role-attempt1','hit',['W','NW','N','NE'],2,1024,[160,554,951,1350]),
('walk-E-vertical-attempt2','walk',['E'],3,1248,[635]),
('walk-SE-guided-attempt3','walk',['SE'],3,1368,[578]),
('walk-S-strip-attempt1','walk',['S'],3,1512,[372,781,1202]),
('walk-SW-guided-attempt3','walk',['SW'],3,1456,[436]),
('walk-W-spacing-attempt4','walk',['W'],3,1072,[430]),
('walk-NW-spacing-attempt4','walk',['NW'],3,1368,[455]),
('walk-N-vertical-attempt2','walk',['N'],3,1344,[520]),
('walk-NE-guided-attempt3','walk',['NE'],3,1464,[565]),
('attack-E-guided-attempt1','attack',['E'],3,1280,[580]),
('attack-SE-spacing-attempt2','attack',['SE'],3,808,[542]),
('attack-S-guided-attempt1','attack',['S'],3,1192,[510]),
('attack-SW-spacing-attempt2','attack',['SW'],3,976,[445]),
('attack-W-spacing-attempt2','attack',['W'],3,952,[445]),
('attack-NW-spacing-attempt2','attack',['NW'],3,1240,[458]),
('attack-N-away-axis-spacing-attempt3','attack',['N'],3,1168,[515]),
('attack-NE-guided-attempt1','attack',['NE'],3,1408,[560]),
('death-E-guided-attempt1','death',['E'],3,1536,[660]),
('death-SE-guided-attempt1','death',['SE'],3,1536,[630]),
('death-S-guided-attempt1','death',['S'],3,1536,[550]),
('death-SW-guided-attempt1','death',['SW'],3,1536,[400]),
('death-W-guided-attempt1','death',['W'],3,1536,[300]),
('death-NW-guided-attempt1','death',['NW'],3,1792,[425]),
('death-N-guided-attempt1','death',['N'],3,2048,[420]),
('death-NE-guided-attempt1','death',['NE'],3,1792,[580]),
]
entries=[];samples=[];raw=set();visible=set();fail=[]
for stem,role,dirs,rows,canvas,xs in specs:
 path=D/(stem+'.png');axis='rows' if stem=='walk-S-strip-attempt1' else 'columns'
 try:
  g=imp.analyze(path,rows_count=rows,reference_rows=[0],directions=dirs,canvas_size=2048,directions_axis=axis)
  anchors=[[xs[f['row']] if axis=='rows' else xs[dirs.index(f['direction'])],f['source_anchor'][1]] for f in g['frames']]
  g=imp.analyze(path,rows_count=rows,reference_rows=[0],directions=dirs,canvas_size=canvas,directions_axis=axis,source_anchors=anchors);imp.require_complete_pose_regions(path,g)
 except Exception as e:fail.append({'stem':stem,'error':str(e)});continue
 e={'output_path':str(path),'sha256':imp.sha(path),'rows':rows,'reference_rows':[0],'directions':dirs,'directions_axis':axis,'canvas_size':canvas,'source_anchors':anchors,'roles':{role:list(range(rows))},'scale_review_note':'TRIAL ONLY: manual homologous hood/crown-to-chin or rear hood-cap comparison against same-heading idle. This provisional canvas is not approved; body-height fitting was not used. Need independent whole13-phase visual review and Main.','anchor_review_note':'TRIAL ONLY: fixed neutral torso projection X per source direction, actual lowest connected cloth support Y per phase. No pixels modified. Need fixed-root playback/death ground review.'}
 entries.append(e)
 arr=np.asarray(Image.open(path))
 for f in g['frames']:
  x,y,w,h=f['region'];crop=arr[y:y+h,x:x+w];rh=hashlib.sha256(crop.tobytes()).hexdigest();vh=imp._visible_pose_fingerprint(crop)
  assert rh not in raw and vh not in visible,stem
  raw.add(rh);visible.add(vh);samples.append({'role':role,'phase':f['row'],'canvas_size':canvas,'source':str(path),**f})
source=json.loads((D/'source-audit.json').read_text())
c={'key':'monster:넝마','display_height_basis':'median_idle','prompt':'All exact issued prompts are retained alongside immutable generated originals. New authored artwork from this actor own existing project ghost source, not extracted original animation.','prompt_record_kind':'Exact per-call prompt and request JSON retained, failed outputs not selected.','sheets':entries,'review':{'identity_preserved':False,'eight_views':False,'motion_roles':False,'no_clipping':False,'notes':'All booleans intentionally false until independent root review. Trial normalized fixed-root matrix pending. N old attack contact wrongly RIGHT and old mixed S/SW walk wrong SW heading are excluded in full. New complete N attack3 and own S/SW whole3 sources substituted. No cloned/partially used PNGs.'},'presentation_to_preserve':source['presentation_to_preserve'],'reference':source['reference'],'source_proof_path':str(D/'source-audit.json'),'status':'HOLD_SCALE_REGISTRATION_ROOT_INDEPENDENT_MAIN_PENDING','independent_qa_approved':False,'actual_Main':'not_run','completed_added':0,'png_sha256':{e['output_path']:e['sha256'] for e in entries}}
(D/'candidate-scale-trial01-HOLD.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
(D/'scale-trial01-geometry.json').write_text(json.dumps({'poses':len(samples),'whole_pngs':len(entries),'raw_unique':len(raw),'visible_unique':len(visible),'failures':fail,'samples':samples},indent=2)+'\n')
out=D/'scale-trial01-diagnostics';out.mkdir(exist_ok=True)
roleorder={'idle':0,'walk':1,'attack':2,'hit':3,'death':4}
for direction in imp.DIRECTIONS:
 poses=sorted([f for f in samples if f['direction']==direction],key=lambda f:(roleorder[f['role']],f['row']))
 panel=Image.new('RGB',(5*300,3*310),(239,239,239));draw=ImageDraw.Draw(panel)
 for i,f in enumerate(poses):
  xx,yy=i%5*300,i//5*310;x,y,w,h=f['region'];im=Image.open(f['source']).crop((x,y,x+w,y+h));ratio=512/f['canvas_size'];im=im.resize((round(w*ratio),round(h*ratio)),Image.Resampling.LANCZOS);anchor=f['source_anchor'];dx=150+round((x-anchor[0])*ratio);dy=235+round((y-anchor[1])*ratio)
  draw.line((xx,yy+235,xx+299,yy+235),fill=(175,180,183));draw.line((xx+150,yy+229,xx+150,yy+241),fill='red');panel.paste(im,(xx+dx,yy+dy),im);draw.text((xx+5,yy+5),f'{direction} {f["role"]}{f["row"]} canvas{f["canvas_size"]}',fill='black')
 panel.save(out/(direction+'-13poses-fixed-root.png'))
print(json.dumps({'pose_count':len(samples),'whole_pngs':len(entries),'visible_unique':len(visible),'failures':fail}))
