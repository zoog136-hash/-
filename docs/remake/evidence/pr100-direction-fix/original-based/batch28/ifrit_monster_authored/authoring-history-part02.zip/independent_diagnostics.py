from pathlib import Path
import json,sys,hashlib
from PIL import Image,ImageDraw
import numpy as np
from scipy import ndimage
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path(__file__).parent;c=json.loads((b/'candidate.json').read_text());out=b/'independent-contacts';poses={};checks=[];used=[];raw=[];vis=[];manifest=[]
for si,s in enumerate(c['sheets']):
 p=Path(s['output_path']);g=m.analyze(p,rows_count=s['rows'],reference_rows=s['reference_rows'],directions_axis=s['directions_axis'],canvas_size=s['canvas_size'],source_anchors=s['source_anchors'],directions=s['directions']);m.require_complete_pose_regions(p,g);im=Image.open(p).convert('RGBA');arr=np.asarray(im);coverage=np.zeros(arr.shape[:2],bool)
 for j,f in enumerate(g['frames']):
  x,y,w,h=f['region'];crop=im.crop((x,y,x+w,y+h));raw.append(f['rgba_sha256']);vis.append(m._visible_pose_fingerprint(np.asarray(crop)));coverage[y:y+h,x:x+w]=True
  mask=np.asarray(crop)[:,:,3]>100;labels,n=ndimage.label(mask);sizes=np.bincount(labels.ravel())[1:];large=sorted([int(a) for a in sizes if a>=16],reverse=True)
  roles=[(r,rr.index(f['row'])) for r,rr in s['roles'].items() if f['row'] in rr];assert len(roles)==1
  role,phase=roles[0];key=(role,f['direction'],phase);assert key not in poses;used.append((si,j));can=s['canvas_size'];tile=Image.new('RGBA',(can,can));mx,my,_,_=f['margin'];tile.paste(crop,(mx,my));norm=tile.resize((400,400),Image.Resampling.LANCZOS);poses[key]=norm
  crop.save(out/f"sourcecrop-{role}-{f['direction']}-{phase}.png")
  norm.save(out/f"normalized-{role}-{f['direction']}-{phase}.png")
  manifest.append({'sheet':si,'source':str(p),'frame':j,'role':role,'direction':f['direction'],'phase':phase,'region':f['region'],'anchor':f['source_anchor'],'canvas':can,'source_components_ge16':large,'source_pixels_alpha_gt100':int(mask.sum()),'normalized_bbox':norm.getbbox()})
 outside=arr[:,:,3][~coverage];checks.append({'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frames':len(g['frames']),'strict_api_analyze':'PASS','complete_visible_regions':'PASS','outside_alpha_max':int(outside.max()),'outside_alpha_gt25':int((outside>25).sum())})
for role,n in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)]:
 for bgcolor,bgname,fg in [('black','black','white'),('white','white','black')]:
  sheet=Image.new('RGB',(400*8,n*430),bgcolor);d=ImageDraw.Draw(sheet)
  for phase in range(n):
   for col,di in enumerate(m.DIRECTIONS):
    p=poses[(role,di,phase)];tile=Image.new('RGBA',p.size,bgcolor);tile.alpha_composite(p);sheet.paste(tile.convert('RGB'),(400*col,430*phase+30));d.text((400*col+6,430*phase+5),f'{di} {role} {phase}',fill=fg);d.line((400*col,430*phase+280,400*col+399,430*phase+280),fill='#80a080')
  sheet.save(out/f'{role}-all8-{bgname}.png')
# same runtime 400px normalization laid out by direction and all13 phases
for di in m.DIRECTIONS:
 sheet=Image.new('RGB',(400*5,430*3),'#202020');d=ImageDraw.Draw(sheet)
 for ci,(role,n) in enumerate([('idle',2),('walk',3),('attack',3),('hit',2),('death',3)]):
  for phase in range(n):
   p=poses[(role,di,phase)];tile=Image.new('RGBA',p.size,'#202020');tile.alpha_composite(p);sheet.paste(tile.convert('RGB'),(400*ci,430*phase+30));d.text((400*ci+6,430*phase+5),f'{di} {role} {phase}',fill='white');d.line((400*ci,430*phase+280,400*ci+399,430*phase+280),fill='#80a080')
 sheet.save(out/f'{di}-roles.png')
r={'total':len(manifest),'unique_raw':len(set(raw)),'unique_visible':len(set(vis)),'unique_assignment':len(set(used)),'checks':checks,'poses':manifest,'guard_thresholds_changed':False,'source_pngs_edited':False,'production_modified':False};(b/'independent-numeric-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['total','unique_raw','unique_visible','unique_assignment']}))
