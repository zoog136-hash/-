from pathlib import Path
from PIL import Image,ImageDraw
import json,sys,numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path(__file__).parent;c=json.loads((b/'candidate-scale-reviewed.json').read_text());out=b/'independent-contacts'
for s in c['sheets']:
 if 'hit-death-W-NW' in s['output_path']:
  s['output_path']=str(b/'hit-death-W-NW-independent-leftrepair.png');s['canvas_size']=648;s.pop('source_anchors');
  g=m.analyze(Path(s['output_path']),rows_count=5,reference_rows=[1],canvas_size=648,directions=['W','NW']);s['source_anchors']=[f['source_anchor'] for f in g['frames']]
for di in ['E','SE','S','SW','W','NW','N','NE']:
 chosen={}
 for s in c['sheets']:
  if di not in s['directions']:continue
  g=m.analyze(Path(s['output_path']),rows_count=s['rows'],reference_rows=s['reference_rows'],canvas_size=s['canvas_size'],source_anchors=s['source_anchors'],directions=s['directions']);im=Image.open(s['output_path']).convert('RGBA')
  for role,rows in s['roles'].items():
   selected=0 if role in ['idle','death'] else len(rows)-1
   row=rows[selected];f=next(f for f in g['frames'] if f['row']==row and f['direction']==di);x,y,w,h=f['region'];tile=Image.new('RGBA',(s['canvas_size'],s['canvas_size']));mx,my,_,_=f['margin'];tile.paste(im.crop((x,y,x+w,y+h)),(mx,my));chosen[role]=tile.resize((400,400),Image.Resampling.LANCZOS)
 sheet=Image.new('RGB',(2000,450),'#303030');d=ImageDraw.Draw(sheet)
 for col,role in enumerate(['idle','walk','attack','hit','death']):
  tile=Image.new('RGBA',(400,400),'#303030');tile.alpha_composite(chosen[role]);sheet.paste(tile.convert('RGB'),(col*400,50));d.text((col*400+5,5),f'{di} {role} scalegrid',fill='white')
  for q in range(0,401,20):
   d.line((col*400+q,50,col*400+q,450),fill='#555555');d.line((col*400,50+q,col*400+399,50+q),fill='#555555')
   if q%40==0:d.text((col*400+q+2,35),str(q),fill='white');d.text((col*400+2,50+q),str(q),fill='white')
 sheet.save(out/f'{di}-anatomical-scale-grid.png')
(b/'candidate-scale-grid-work.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
