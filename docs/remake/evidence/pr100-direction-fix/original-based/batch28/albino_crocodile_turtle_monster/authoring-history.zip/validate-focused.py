from pathlib import Path
import shutil,sys,json,numpy as np
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path(__file__).parent;items=[('walk-E-W6','exec-3c8574b7-f4f8-48b6-9deb-b4d176eeb082.png',3,'rows',['E','W']),('walk-S-N6','exec-dbc3c43e-890e-4e1a-9bc6-6915a2f3fae3.png',3,'rows',['S','N']),('walk-SE-SW6','exec-c71851f5-30d5-4372-8972-d233c22bdb89.png',3,'rows',['SE','SW']),('walk-NW-NE6','exec-e0418e96-ab21-4192-9625-fef5b14db0bf.png',3,'rows',['NW','NE']),('idle-front8','exec-4fb7338c-3b56-4f00-86a0-c6b8b4d3bc6b.png',2,'rows',['E','SE','S','SW']),('idle-rear8','exec-ed6a0cd9-f9d8-487e-b90f-e1b3ebab59e7.png',2,'rows',['W','NW','N','NE']),('hd-S-SW10-heading','exec-a8feb84b-8413-442f-925a-a9b5a6dbad62.png',5,'columns',['S','SW'])];r=[]
for n,s,rows,axis,ds in items:
 p=b/(n+'.png');shutil.copyfile('/workspace/generated_images/'+s,p);d={'name':n,'sha256':m.sha(p)}
 try:
  g=m.analyze(p,rows_count=rows,reference_rows=[0,1] if rows!=3 else [0],directions_axis=axis,canvas_size=1536,directions=ds);m.require_complete_pose_regions(p,g);(b/('geometry-'+n+'.json')).write_text(json.dumps(g,indent=2)+'\n');a=np.asarray(Image.open(p))[:,:,3];cv=np.zeros(a.shape,bool)
  for f in g['frames']:
   x,y,w,h=f['region'];cv[y:y+h,x:x+w]=True
  d.update(strict='PASS',frames=len(g['frames']),outside_max=int(a[~cv].max()),outside_gt25=int(sum(a[~cv]>25)))
 except Exception as e:d.update(strict='FAIL',error=str(e))
 r.append(d)
(b/'focused-strict-report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
