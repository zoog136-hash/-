from pathlib import Path
import shutil,sys,json,numpy as np
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path(__file__).parent;dsf=['E','SE','S','SW'];dsr=['W','NW','N','NE'];items=[('idle-walk-front20','exec-2166268e-8792-40d5-a8b5-eafe0f03088f.png',5,'columns',dsf),('idle-walk-rear20','exec-858c6d23-a410-4e25-bb15-aae18b0b1069.png',5,'columns',dsr),('hit-death-front20','exec-7404a624-f5f3-4010-bdf6-0fda88dfaa27.png',5,'columns',dsf),('hit-death-rear20','exec-cf700769-33ad-4489-88c9-81a596eba128.png',5,'columns',dsr),('attack-front12','exec-dfb056a5-471d-4fb4-acd2-63481acbd4ad.png',3,'rows',dsf),('attack-rear12','exec-06a92599-0f4a-4ff8-9cb4-fbc9ddbcafe5.png',3,'rows',dsr)];report=[]
for n,s,rows,axis,ds in items:
 p=b/(n+'.png');shutil.copyfile('/workspace/generated_images/'+s,p);d={'name':n,'sha256':m.sha(p)}
 try:
  g=m.analyze(p,rows_count=rows,reference_rows=[0,1] if rows==5 else [0],directions_axis=axis,canvas_size=1024,directions=ds);m.require_complete_pose_regions(p,g);(b/('geometry-'+n+'.json')).write_text(json.dumps(g,indent=2)+'\n');a=np.asarray(Image.open(p))[:,:,3];mask=np.zeros(a.shape,bool)
  for f in g['frames']:
   x,y,w,h=f['region'];mask[y:y+h,x:x+w]=True
  d.update(strict='PASS',count=len(g['frames']),outside_max=int(a[~mask].max()),outside_gt25=int(sum(a[~mask]>25)))
 except Exception as e:d.update(strict='FAIL',error=str(e))
 report.append(d)
(b/'subset-strict-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
