from pathlib import Path
import hashlib,json,sys,math
import numpy as np
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as motion
b=Path(__file__).parent
source_selection=json.load(open('/workspace/scratch/pr100-continuation/candidate-selection.json'))
source=next(r for r in source_selection['candidates'] if r['key']=='monster:풍룡의 둥지 태풍수호자')
specs=[('idle-walk-attempt1',5,512,{'idle':[0,1],'walk':[2,3,4]}),('attack-attempt1',3,752,{'attack':[0,1,2]}),('hit-attempt2',2,752,{'hit':[0,1]}),('death-attempt2',3,752,{'death':[0,1,2]})]
sheets=[];metrics=[];fingerprints=[];geometries=[]
for stem,rows,canvas,roles in specs:
 p=b/(stem+'.png');old=json.load(open(b/(stem+'.diagnostic.json')))['geometry']
 a=np.asarray(Image.open(p).getchannel('A'))
 anchors=[]
 for f in old['frames']:
  x,y,w,h=f['region']; yy,xx=np.where(a[y:y+h,x:x+w]>100);bottom=int(yy.max()+y)
  band=a[max(y,bottom-3):bottom+1,x:x+w]>100
  by,bx=np.where(band);anchor_x=int(round((int(bx.min())+int(bx.max()))/2+x))
  anchors.append([anchor_x,bottom])
 g=motion.analyze(p,rows_count=rows,reference_rows=[0,1] if rows>1 else [0],directions_axis='columns',canvas_size=canvas,source_anchors=anchors)
 motion.require_complete_pose_regions(p,g);geometries.append(g)
 rgba=np.asarray(Image.open(p));covered=np.zeros(a.shape,bool)
 for f in g['frames']:
  x,y,w,h=f['region'];covered[y:y+h,x:x+w]=True
  fingerprints.append(motion._visible_pose_fingerprint(rgba[y:y+h,x:x+w]))
 outside=a[~covered]
 item={'stem':stem,'png_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'image_size':g['image_size'],'actual_source_frames':len(g['frames']),'runtime_used_frames':len(g['frames']),'geometry_pass':True,'complete_pose_regions_pass':True,'visible_frames_unique_within_sheet':True,'alpha_outside_regions_max':int(outside.max()) if len(outside) else 0,'alpha_gt25_outside_regions':int(np.sum(outside>25)),'canvas':canvas,'neutral_height_diagnostic_pixels':g['neutral_height'],'source_anchors':anchors,'geometry_path':str(b/(stem+'.geometry.json'))}
 metrics.append(item)
 (b/(stem+'.geometry.json')).write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n')
 sheets.append({'output_path':str(p),'rows':rows,'reference_rows':[0,1] if rows>1 else [0],'directions_axis':'columns','canvas_size':canvas,'source_anchors':anchors,'roles':roles,'scale_review_note':('Primary idle sheet canvas512; all secondary sheets use752 chosen from S-face interpupil landmarks (approximately13px idle,19px secondary; +/-2px manual uncertainty). This preserves anatomical facial scale independently of folded/dead body height. No pixels rescaled or edited. Per-pose grounded-base anchors are midpoint of alpha>100 bottom four source rows; height basis max_living_frame. Actual Main comparison remains required.')})
assert len(fingerprints)==104 and len(set(fingerprints))==104
prompt_files=sorted(b.glob('*.prompt.txt'))
candidate={'key':source['key'],'prompt':'\n\n'.join(p.name+' EXACT ISSUED PROMPT:\n'+p.read_text() for p in prompt_files),'prompt_record_kind':'exact prompts saved before each generation; one rejected 32-pose output preserved separately and not counted','display_height_basis':'max_living_frame','action_aliases':{'cast':'attack'},'sheets':sheets,'review':{'identity_preserved':True,'eight_views':True,'motion_roles':True,'no_clipping':True,'cast_uses_authored_attack':True,'notes':'Author reviewed complete source-reference wind anatomy, pale mint-green/white palette, angular face, clawed long arms and continuously attached torso/vortex without human legs. E/W are opposing side profiles, S frontal face and N rear crest/body without frontal face; NW/NE show rear three-quarter anatomy. Idle elbow/wrist lift and chest flow, alternating travel arm/torsal/vortex bends, gathered-hands→facing-forward two-hand magic strike→retraction, defensive recoil→lowered forward recovery and three-stage slumped/flattened coherent dead body are newly authored distinct poses. All104 source frames mapped exactly once to five mandatory roles, no threshold/count relaxation. Separate hit-death32-pose output rejected because 40 requested, no use or counted poses. Strict geometry/complete-source-region and cross-sheet visible uniqueness PASS. Anchors from actual alpha>100 base bottoms; secondary canvas752 selected from frontal eye-pair anatomical scale (~13px idle versus~19px attack/hit/death first phases, manual±2px). It is not based on collapsed body height. Original project atlas retained unchanged; supplemental whole-body context used only for authoring the missing head tip. Original record magic/floatingtrue/height86/attack_hit_ratio0.52 must remain. Spell gesture may serve cast action without extra claimed pixels. Independent visual QA, Main eight-direction five-role playback/combat/death/drop/pickup, uniform display scale and ground-contact review remain pending. No runtime/profile/maps changed; no completion claim.'},'authoring_status':'104-pose candidate; independent QA and actual Main pending','independent_qa_approved':False,'Main_validated':False,'complete':False,'preservation_reference':source['presentation_to_preserve'],'source_reference':source['reference'],'supplemental_context':source['source_wholebody_check'],'png_sha256':{m['stem']:m['png_sha256'] for m in metrics},'exact_prompt_files':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in prompt_files],'rejected_outputs':[{'path':str(b/'hit-death-attempt1.png'),'sha256':hashlib.sha256((b/'hit-death-attempt1.png').read_bytes()).hexdigest(),'reason':'Expected40 actual32; strict rejected. No source pose from this sheet used in candidate or counted.'}]}
(b/'candidate.json').write_text(json.dumps(candidate,ensure_ascii=False,indent=2)+'\n')
report={'key':source['key'],'source_frame_count':104,'runtime_mandatory_frame_count':104,'source_unused_frame_count':0,'cross_sheet_visible_unique_count':104,'strict_checks_all_pass':True,'sheets':metrics,'scale_review':{'method':'manually reviewed S-facing paired eye anatomical landmarks, independently of body height','uncertainty_source_px':2,'idle_source_region_eye_centers_approx':[[86,47],[99,47]],'attack_source_region_eye_centers_approx':[[88,57],[107,57]],'hit_source_region_eye_centers_approx':[[122,44],[140,39]],'death_source_region_eye_centers_approx':[[94,73],[113,72]],'primary_canvas':512,'secondary_canvas':752,'reason':'19/13*512=748 rounded752; shared anatomical scale for attack/hit/death, no flatten-height normalization','caveat':'Face positions approximate due articulation and foreshortening; actual Main independent scale review required'},'rejected_source':'hit-death-attempt1.png','Main':'not_run','complete':False}
(b/'author-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidate':str(b/'candidate.json'),'104_actual_frames':len(fingerprints),'104_unique':len(set(fingerprints)),'sheet_counts':[m['actual_source_frames'] for m in metrics],'alpha_outside':[[m['alpha_outside_regions_max'],m['alpha_gt25_outside_regions']] for m in metrics]},ensure_ascii=False,indent=2))
