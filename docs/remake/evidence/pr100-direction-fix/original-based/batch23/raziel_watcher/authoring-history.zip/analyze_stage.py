import argparse, hashlib, json, sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, '/workspace/twilight/tools')
import import_original_based_motion as motion
p=argparse.ArgumentParser()
p.add_argument('image',type=Path)
p.add_argument('--rows',type=int,required=True)
p.add_argument('--directions',default='E,SE,S,SW,W,NW,N,NE')
p.add_argument('--axis',default='columns')
p.add_argument('--canvas',type=int,default=512)
args=p.parse_args()
result={'image_path':str(args.image),'sha256':hashlib.sha256(args.image.read_bytes()).hexdigest(),'diagnostic_only':True,'rows_count':args.rows,'directions_axis':args.axis,'directions':args.directions.split(','),'canvas_size':args.canvas,'production_imported':False,'complete_count_added':0}
with Image.open(args.image) as im:
 result['mode']=im.mode;result['image_size']=list(im.size)
try:
 geometry=motion.analyze(args.image,rows_count=args.rows,directions_axis=args.axis,directions=result['directions'],canvas_size=args.canvas,reference_rows=[0,1] if args.rows>=2 else [0])
 result['analyze_status']='PASS';result['geometry']=geometry
 try:
  motion.require_complete_pose_regions(args.image,geometry)
  result['complete_pose_regions_status']='PASS'
 except Exception as e:
  result['complete_pose_regions_status']='FAIL';result['complete_pose_regions_error']=str(e)
except Exception as e:
 result['analyze_status']='FAIL';result['analyze_error']=str(e)
 result['complete_pose_regions_status']='NOT_RUN_ANALYZE_FAILED'
path=args.image.with_suffix('.diagnostic.json')
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='geometry'},ensure_ascii=False,indent=2))
