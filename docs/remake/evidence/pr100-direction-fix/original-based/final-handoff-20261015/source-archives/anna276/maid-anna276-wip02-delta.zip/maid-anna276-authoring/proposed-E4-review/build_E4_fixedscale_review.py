from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from scipy import ndimage
import numpy as np,json,hashlib,sys
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
B=Path('/workspace/scratch/pr100-continuation/maid-anna276-authoring');D=B/'proposed-E4-review';font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
entries=[('OWN ORIGINAL CATALOG',Path('/workspace/twilight/assets/catalog/f111979ea61b2aea33dae32f.png'),256,None,'catalog'),('PROPOSED E idle0',B/'idle16-attempt1.png',640,[78,24,134,366],'idle')]
for name,role in [('E-contactA-RIGHTlead','contactA'),('E-passing1-RIGHTsupport','passing1'),('E-contactB-LEFTlead','contactB'),('E-passing2-LEFTsupport','passing2')]:entries.append((name,B/(name+'-attempt1.png'),2048,None,role))
output=Image.new('RGB',(1536,1180),'#202c37');draw=ImageDraw.Draw(output);draw.text((12,9),'ANNA276 OWN SOURCE / E4 PHYSICAL PILOT PROPOSAL — HOLD; no production import/completion',font=font,fill='white');draw.text((12,34),'Fixed virtual256 display enlarged2x. Idlecanvas640; everyE4single2048. No perphase heightfit; skull/core compared directly.',font=small,fill='#d0dbe5');records=[]
for index,(name,path,canvas,region,role) in enumerate(entries):
 before=hashlib.sha256(path.read_bytes()).hexdigest();raw=Image.open(path).convert('RGBA');arr=np.asarray(raw);alpha=arr[:,:,3]
 if region is None:
  yy,xx=np.nonzero(alpha>100);x0,x1=max(0,int(xx.min())-3),min(raw.width,int(xx.max())+4);y0,y1=max(0,int(yy.min())-3),min(raw.height,int(yy.max())+4);region=[x0,y0,x1-x0,y1-y0]
 x0,y0,w,h=region;floor=int(np.nonzero(alpha[y0:y0+h,x0:x0+w]>100)[0].max())+y0
 band=max(20,round(h*.24));start=max(y0,floor-band);mask=alpha[start:floor+1,x0:x0+w]>100;labels,n=ndimage.label(mask);areas=np.bincount(labels.ravel());parts=[]
 for lab in range(1,n+1):
  if areas[lab]<max(12,h*.15):continue
  yy,xx=np.nonzero(labels==lab);bottom=int(yy.max())+start;bottomxs=xx[yy>=yy.max()-2]+x0;parts.append({'x':round(float(np.median(bottomxs))),'y':bottom,'lower_chain_pixels':int(areas[lab])})
 parts=sorted(parts,key=lambda v:v['x']);insist=len(parts)==2
 # The body root is grounded at both-contact midpoint for idle/contact, at
 # the actual planted sole for passing. Source samples remain fully visible.
 if role in ['passing1','passing2']:
  planted=max(parts,key=lambda v:v['y']) if parts else {'x':x0+w//2,'y':floor};anchor=[planted['x'],planted['y']];method='actual lowest planted sole; raised foot separately marked'
 else:
  anchor=[round(float(np.mean([p['x'] for p in parts]))),round(float(np.mean([p['y'] for p in parts])))] if parts else [x0+w//2,floor];method='midpoint of two actual visible sole contacts; depth projection preserved'
 foot=[canvas//2,canvas*5//8];margin=[foot[0]-(anchor[0]-x0),foot[1]-(anchor[1]-y0)];fits=min(margin)>=0 and margin[0]+w<=canvas and margin[1]+h<=canvas
 scale=512/canvas;canvasim=Image.new('RGBA',(512,512));crop=raw.crop((x0,y0,x0+w,y0+h));resized=crop.resize((max(1,round(w*scale)),max(1,round(h*scale))),Image.Resampling.NEAREST);canvasim.alpha_composite(resized,(round(margin[0]*scale),round(margin[1]*scale)))
 px=(index%3)*512;py=70+(index//3)*550;output.paste(canvasim.convert('RGB'),(px,py+22),canvasim.getchannel('A'));draw.text((px+8,py+1),name,font=small,fill='white');ground=py+22+320;draw.line((px+12,ground,px+500,ground),fill='#637982',width=1)
 for p in parts:
  sx=px+(foot[0]+p['x']-anchor[0])*scale;sy=py+22+(foot[1]+p['y']-anchor[1])*scale;draw.ellipse((sx-4,sy-4,sx+4,sy+4),outline='#ffcf5a',width=2)
 draw.line((px+250,ground,px+262,ground),fill='#ff6c75',width=2);draw.line((px+256,ground-6,px+256,ground+6),fill='#ff6c75',width=2)
 draw.text((px+8,py+460),f'canvas{canvas}; sourceanchor{anchor}; fit={fits}',font=small,fill='white');draw.text((px+8,py+482),f'Wholecrop{w}x{h}; normalizedbody{w*256/canvas:.1f}x{h*256/canvas:.1f}',font=small,fill='#c8d3df');draw.text((px+8,py+504),'Gold=measured soles; red=proposed groundroot. HOLD.',font=small,fill='#ffcf5a')
 record={'label':name,'role':role,'source':str(path),'sha256':before,'source_region':region,'proposed_canvas_size':canvas,'source_to_virtual256_scale':256/canvas,'source_anchor':anchor,'source_anchor_basis':method,'measured_actual_lower_chain_sole_points':parts,'two_separate_lower_chains_measured':insist,'proposed_canvas_fit':fits,'margin_position':margin,'raw_source_pixels_changed':False,'status':'PROPOSED_HOLD_ROOT_REVIEW_REQUIRED','scale_basis':'Uniform E4canvas2048 and idle640 proposal; skull/core must be reviewed directly, not fullheight/weapon tip fit'}
 if role!='catalog':
  try:
   g=m.analyze(path,rows_count=2 if role=='idle' else 1,reference_rows=[0] if role!='idle' else [0,1],canvas_size=canvas,directions=['E'],source_anchors=[anchor]) if role!='idle' else None
   if g:m.require_complete_pose_regions(path,g);record['single_pose_actual_anchor_strict_guard']='PASS'
  except Exception as e:record['single_pose_actual_anchor_strict_guard']='FAIL';record['guard_error']=str(e)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==before;records.append(record)
output.save(D/'Anna276-ownoriginal-idle-E4-fixedscale-PROPOSED-HOLD.png');(D/'proposed-registration-and-sole-measurements.json').write_text(json.dumps({'status':'PROPOSED_HOLD_NOT_APPROVED','scale_comparison':'Eachvirtual256renders512 atsame2x; E4all2048, idle640; owncatalog256. No phase/maxbodyheight fit. Groundcontacts are alpha-measured actual shoes, not proof anatomical leg ownership.','skull_core_review':'Direct side-by-side preserved original and proposed E idle/4phases; fixed scale highlights any head/core variance. Manual skull/ear/eye/collar/waist homologous landmark approval remains root gate.','records':records,'source_pixels_changed':False,'production_imported':False,'completed_added':0},indent=2)+'\n');print(json.dumps([{'label':r['label'],'anchor':r['source_anchor'],'two_lowerchains':r['two_separate_lower_chains_measured'],'fit':r['proposed_canvas_fit'],'guard':r.get('single_pose_actual_anchor_strict_guard')} for r in records],indent=2))
