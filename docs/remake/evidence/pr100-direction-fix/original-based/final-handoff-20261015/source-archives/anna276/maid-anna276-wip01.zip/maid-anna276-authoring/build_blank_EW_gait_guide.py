from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json
b=Path('/workspace/scratch/pr100-continuation/maid-anna276-authoring');im=Image.new('RGB',(2048,1280),'#26313d');d=ImageDraw.Draw(im);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18);records=[]
phases=[('A RIGHT leads',{'R':[(8,300),(65,425),(130,550)],'L':[(-8,300),(-45,430),(-95,515)]},'R'),('passing1 RIGHT supports',{'R':[(8,290),(10,425),(-5,550)],'L':[(-8,290),(95,380),(115,465)]},'R'),('B LEFT leads',{'R':[(8,300),(-70,420),(-115,510)],'L':[(-8,300),(60,425),(125,550)]},'L'),('passing2 LEFT supports',{'R':[(8,290),(105,380),(120,455)],'L':[(-8,290),(-5,425),(-10,550)]},'L')]
for row,direction in enumerate(['E','W']):
 sign=1 if direction=='E' else -1
 for col,(label,chains,planted) in enumerate(phases):
  x=col*512+256;y=row*640;ground=y+562;d.text((col*512+12,y+12),direction+' / '+label,font=font,fill='white');d.text((col*512+12,y+42),'RIGHT=blue   LEFT=orange',font=small,fill='#c9d4e0');d.line((col*512+12,ground,(col+1)*512-12,ground),fill='#ebc56c',width=3);d.ellipse((x-38,y+102,x+38,y+178),outline='#bac4d1',width=5);d.line((x,y+180,x,y+chains['R'][0][1]-10),fill='#bac4d1',width=8);d.line((x-38,y+230,x+38,y+230),fill='#bac4d1',width=6);d.line((x-20,y+chains['R'][0][1],x+20,y+chains['L'][0][1]),fill='#d8e1ee',width=8)
  order=['L','R'] if direction=='E' else ['R','L']
  for leg in order:
   color='#4ab4ff' if leg=='R' else '#ff9f50';pts=[(x+sign*px,y+py) for px,py in chains[leg]];d.line(pts,fill=color,width=8)
   for px,py in pts:d.ellipse((px-7,py-7,px+7,py+7),fill=color)
   ax,ay=pts[-1];d.line((ax-sign*15,ay+12,ax+sign*28,ay+12),fill=color,width=7)
  d.text((col*512+12,y+590),f'Planted {planted}; '+('near RIGHT / far LEFT' if direction=='E' else 'near LEFT / far RIGHT'),font=small,fill='white');records.append({'direction':direction,'phase':col,'support_leg':planted,'chains_relative_root':{k:[(sign*x,y) for x,y in v] for k,v in chains.items()},'world_ground_y':562,'diagram_only_not_character_pixels':True})
im.save(b/'TECHNICAL-blank-joints-EW-fourphase.png');(b/'blank-joints-EW-fourphase.json').write_text(json.dumps(records,indent=2)+'\n')
