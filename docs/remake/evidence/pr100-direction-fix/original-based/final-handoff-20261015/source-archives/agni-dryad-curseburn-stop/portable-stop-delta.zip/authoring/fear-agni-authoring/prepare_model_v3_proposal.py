from pathlib import Path
import json,copy,sys,hashlib
from PIL import Image,ImageDraw
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path(__file__).resolve().parent;old=json.load(open(b/'central-vortex-registration/candidate-central-vortex-seed.json'));c=copy.deepcopy(old);out=b/'central-vortex-model-v3';out.mkdir(exist_ok=True)
s=next(s for s in c['sheets'] if Path(s['output_path']).name=='hit-W-NW-v2.png');s['output_path']=str(b/'hit-W-NW-model-v3.png');s['canvas_size']=1200
im=Image.open(s['output_path']).convert('RGBA');a=np.asarray(im);g=m.analyze(Path(s['output_path']),2,[1],canvas_size=1200,directions=s['directions']);anchors=[]
for f in g['frames']:
 x,y,w,h=f['region'];p=a[y:y+h,x:x+w];lo=int(.72*h);hi=int(.96*h);weight=(p[lo:hi,:,3]>100)*(.25+p[lo:hi,:,:3].mean(axis=2)/255);cx=float((weight.sum(axis=0)*np.arange(w)).sum()/weight.sum());ax=x+round(cx);radius=max(4,round(w*.1));bottom=[]
 for col in range(max(0,round(cx)-radius),min(w,round(cx)+radius+1)):
  yy=np.flatnonzero(p[:,col,3]>100)
  if len(yy):bottom.append(int(yy[-1]))
 ay=y+round(float(np.quantile(bottom,.85)));anchors.append([ax,ay])
s['source_anchors']=anchors;s['scale_review_note']='PROPOSED1200 from sameheading head/core/compactvortex review ofnew4 ownsourcehitposes, not oldsilhouette1424. Perposecentralvortexroot seeds visuallyplausible butactualMain andindependentlandmark reviewpending; nofinalscaleapproval. Onecanvasall4, noPNGpixelassembly orresample.'
c['prompt']+='\nNEW EXACT PROPORTIONREPAIR PROMPT:\n'+(b/'hit-W-NW-model-v3-exact-prompt.txt').read_text();c['review']['notes']+=' NewW/NW4hitmodel repairselected onlyinthisPROPOSEDcandidate, restoreslargercoherentface/uppercoreandcompactlowerwhorl; originalcandidate/rawunchanged. All8 centralvortexanchor seeds replace hand/tailbboxcenters. Onecanvas1200fornew4, pendingindependenthead/coreandactualMain.'
raw=[];vis=[];used=[];slots=set();tiles={d:[] for d in m.DIRECTIONS};checks=[]
for i,s in enumerate(c['sheets']):
 p=Path(s['output_path']);g=m.analyze(p,s['rows'],s.get('reference_rows'),directions_axis=s.get('directions_axis','columns'),canvas_size=s['canvas_size'],source_anchors=s['source_anchors'],directions=s['directions']);m.require_complete_pose_regions(p,g);im=Image.open(p).convert('RGBA');a=np.asarray(im)
 for f in g['frames']:
  role=next(role for role,rows in s['roles'].items() if f['row'] in rows);phase=s['roles'][role].index(f['row']);key=(role,f['direction'],phase);assert key not in slots;slots.add(key);raw.append(f['rgba_sha256']);x,y,w,h=f['region'];vis.append(m._visible_pose_fingerprint(a[y:y+h,x:x+w]));can=s['canvas_size'];t=Image.new('RGBA',(can,can));t.paste(im.crop((x,y,x+w,y+h)),tuple(f['margin'][:2]));tiles[f['direction']].append((role,phase,t.resize((480,480),Image.Resampling.LANCZOS)))
 checks.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'poses':len(g['frames']),'canvas':s['canvas_size'],'strict_analyze':'PASS','complete_visible_pixels':'PASS'})
assert len(slots)==len(raw)==len(set(raw))==len(set(vis))==104
for direction,frames in tiles.items():
 frames.sort(key=lambda x:({'idle':0,'walk':1,'attack':2,'hit':3,'death':4}[x[0]],x[1]));o=Image.new('RGB',(1920,2080),'#24313a');d=ImageDraw.Draw(o)
 for i,(role,phase,tile) in enumerate(frames):
  x=i%4*480;y=i//4*520;o.paste(tile,(x,y+32),tile);d.text((x+5,y+7),f'{direction} {role}{phase} | proposed root/model v3 (NOT Main)',fill='white');d.line((x,y+332,x+479,y+332),fill='#78966c')
 o.save(out/(direction+'-all13-registered-model-v3.png'))
(out/'candidate-proposed-model-v3.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');report={'status':'PASS104_STRICT_GEOMETRY_PENDING_INDEPENDENT_HEAD_CORE_ROOT_MAIN','raw_unique':104,'visible_unique':104,'all_mandatory_slots':104,'all_selected_source_poses_used_once':True,'newWNW4':checks[9],'newWNWanchors':anchors,'source_pixels_modified':False,'Main':'not_run','completed_added':0,'sheets':checks};(out/'full104-guard-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'candidate':str(out/'candidate-proposed-model-v3.json'),'status':report['status'],'newanchors':anchors,'canvases':[s['canvas_size'] for s in c['sheets']]},ensure_ascii=False))
