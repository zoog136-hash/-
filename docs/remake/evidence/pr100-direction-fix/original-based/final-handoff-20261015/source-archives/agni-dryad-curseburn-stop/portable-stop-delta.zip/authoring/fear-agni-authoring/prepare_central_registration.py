from pathlib import Path
import json,copy,sys
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
b=Path(__file__).resolve().parent;c=json.load(open(b/'candidate.json'));pro=copy.deepcopy(c);records=[];tiles={d:[] for d in m.DIRECTIONS};out=b/'central-vortex-registration';out.mkdir(exist_ok=True)
for si,s in enumerate(pro['sheets']):
 p=Path(s['output_path']);old=json.load(open(b/(p.stem+'-assembled-geometry.json')));im=Image.open(p).convert('RGBA');a=np.asarray(im);anchors=[]
 for f in old['frames']:
  x,y,w,h=f['region'];role=next(r for r,rows in s['roles'].items() if f['row'] in rows);phase=s['roles'][role].index(f['row']);pix=a[y:y+h,x:x+w];alpha=pix[:,:,3];frac=.60 if role=='death' and phase==2 else .72
  lo=int(h*frac);hi=max(lo+1,int(h*.96));mask=(alpha[lo:hi]>100);weights=mask*(.25+pix[lo:hi,:,:3].mean(axis=2)/255)
  xs=np.arange(w);tot=weights.sum();cx=float((weights.sum(axis=0)*xs).sum()/tot) if tot else w/2;ax=round(x+cx)
  radius=max(4,round(w*.10));left=max(0,round(cx)-radius);right=min(w,round(cx)+radius+1);bottom=[]
  for column in range(left,right):
   yy=np.flatnonzero(alpha[:,column]>100)
   if len(yy):bottom.append(int(yy[-1]))
  ay=y+round(float(np.quantile(bottom,.85))) if bottom else f['source_anchor'][1]
  ax=max(x,min(x+w-1,ax));ay=max(y,min(y+h-1,ay));anchors.append([ax,ay]);records.append({'sheet':si,'source':p.name,'row':f['row'],'direction':f['direction'],'role':role,'phase':phase,'old_anchor':f['source_anchor'],'proposed_central_vortex_anchor':[ax,ay],'delta':[ax-f['source_anchor'][0],ay-f['source_anchor'][1]],'basis':'ALGORITHMIC SEED ONLY: lower connected central vortex luminous mass centroid and central-column85percent base; manual physical root inspection required, not tail/bbox.'})
 s['source_anchors']=anchors;s['scale_review_note']+=' New central-vortex anchor seeds are diagnostic only, every final contact/root must be manually approved.'
 g=m.analyze(p,s['rows'],s.get('reference_rows'),directions_axis=s.get('directions_axis','columns'),canvas_size=s['canvas_size'],source_anchors=anchors,directions=s['directions']);m.require_complete_pose_regions(p,g)
 for f in g['frames']:
  x,y,w,h=f['region'];role=next(r for r,rows in s['roles'].items() if f['row'] in rows);phase=s['roles'][role].index(f['row']);can=s['canvas_size'];tile=Image.new('RGBA',(can,can));tile.paste(im.crop((x,y,x+w,y+h)),tuple(f['margin'][:2]));tile=tile.resize((480,480),Image.Resampling.LANCZOS);tiles[f['direction']].append((role,phase,tile))
for direction,frames in tiles.items():
 frames.sort(key=lambda x:({'idle':0,'walk':1,'attack':2,'hit':3,'death':4}[x[0]],x[1]));sheet=Image.new('RGB',(1920,4*520),'#24313a');d=ImageDraw.Draw(sheet)
 for i,(role,phase,tile) in enumerate(frames):
  x=i%4*480;y=i//4*520;sheet.paste(tile,(x,y+32),tile);d.text((x+8,y+7),f'{direction} {role}{phase} | fixed canvas ratio / central-vortex SEED',fill='white');d.line((x,y+332,x+479,y+332),fill='#78966c')
 sheet.save(out/(direction+'-all13-central-vortex-seed.png'))
(out/'anchor-seeds.json').write_text(json.dumps({'status':'104STRICT_BOUNDS_PASS_DIAGNOSTIC_ROOT_SEEDS_NOT_MANUAL_APPROVAL','records':records,'source_pixels_unchanged':True,'Main':'not_run','completed_added':0},indent=2)+'\n');(out/'candidate-central-vortex-seed.json').write_text(json.dumps(pro,ensure_ascii=False,indent=2)+'\n');print(out)
# Literal source anatomy crops with coordinate grid; diagnostic reference only.
items=[('N idle','idle-walk-N-NE-v2.png',(150,20,425,285)),('N attack recover','attack-hit-N-v4.png',(390,675,640,890)),('N hit recover','attack-hit-N-v4.png',(380,1205,635,1455)),('W idle','idle-walk-W-NW-v2.png',(170,35,415,285)),('W hit recover','hit-W-NW-v2.png',(35,810,540,1415)),('NW hit recover','hit-W-NW-v2.png',(550,810,1020,1420))]
sheet=Image.new('RGB',(2100,1500),'#ddd');d=ImageDraw.Draw(sheet)
for i,(title,name,box) in enumerate(items):
 im=Image.open(b/name).crop(box);scale=min(650/im.width,680/im.height);im=im.resize((round(im.width*scale),round(im.height*scale)));x=i%3*700;y=i//3*750;sheet.paste(im,(x+30,y+35),im);d.text((x+25,y+8),title+' SOURCE '+str(box[:2]),fill='black',font_size=20)
 for xx in range((box[0]+19)//20*20,box[2],20):
  sx=x+30+round((xx-box[0])*scale);d.line((sx,y+35,sx,y+35+im.height),fill='#777');d.text((sx,y+35+im.height+2),str(xx),fill='black')
 for yy in range((box[1]+19)//20*20,box[3],20):
  sy=y+35+round((yy-box[1])*scale);d.line((x+30,sy,x+30+im.width,sy),fill='#777');d.text((x,sy),str(yy),fill='black')
sheet.save(out/'source-head-core-grid.png')
