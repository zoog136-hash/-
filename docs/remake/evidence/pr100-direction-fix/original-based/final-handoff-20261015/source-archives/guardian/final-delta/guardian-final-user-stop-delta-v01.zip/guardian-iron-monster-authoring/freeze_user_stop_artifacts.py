from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).resolve().parent;baseidx=p/'portable-guardian-pilot-v01/index.json';base=json.loads(baseidx.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();assert base['zip']['sha256']==sha(Path(base['zip']['path']))
sourcepins={}
approved={'walk-E-A-single-pilot1','walk-E-PASS1-single-pilot1','walk-E-B-single-pilot1','walk-E-PASS2-single-pilot1'}
for gen in sorted(p.glob('*-generation.json')):
 stem=gen.name[:-len('-generation.json')];png=p/(stem+'.png');assert png.exists();meta=json.loads(gen.read_text());digest=sha(png)
 if meta.get('sha256'):assert meta['sha256']==digest
 elif png.name in base['entries']:assert base['entries'][png.name]['sha256']==digest
 else:raise ValueError('Missing original integrity pin: '+png.name)
 for suffix in ['-prompt.txt','-request.json']:assert (p/(stem+suffix)).exists()
 sourcepins[png.name]={'bytes':png.stat().st_size,'sha256':digest,'generation_record':gen.name,'prompt_record':stem+'-prompt.txt','request_record':stem+'-request.json','state':'SOURCE_PHYSICAL_PILOT_PARENT_APPROVED__NO_MAIN__NOT_COMPLETE' if stem in approved else 'HOLD__SOURCE_REFERENCE_OR_UNREVIEWED_OR_FAILED__NO_MAIN__NOT_COMPLETE'}
 if stem in approved:assert base['entries'][png.name]['sha256']==digest
manifest={'schema':'guardian-final-user-stop-source-pins-v1','target':'monster:가디언','user_stop':True,'running_generation':False,'running_engine_or_test':False,'production_imported_by_author':False,'completed_added_by_author':0,'actual_Main':'NOT RUN for Guardian','source_claim':'Original atlas2 iron Guardian identity preserved; newly source-based authored2D, not extracted original animation. Every raw PNG byte-exact, all failures retained. Diagnostic images never ship.','original_proof':'source-proof.json','all_raw_generated_pngs':sourcepins,'physical_pilot_approval':'E4 only, E-ROOT-PILOT-REVIEW.json and frozen E-fourphase-physical-pilot-v1.json. Not Main/game completion.','N4_status':'HOLD parent physical/crossheading size review and actualMain pending. Author geometry/opposition trace in N-fourphase-physical-pilot-v1.json is not completion.','idle_E_and_N_status':'HOLD sameheading metadata/crossheading visual/Main pending; geometry alone is not success.','all_other_status':'HOLD or reference only; never production selected. Every failed whole4 excluded entirely, no halfselected bodies.','never_issued_request':'walk-E-fourphase-pilot4-request.json prepared but NOT invoked; no raw PNG exists, per parent preserving good singles.'}
(p/'FINAL_USER_STOP_SOURCE_PINS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
restart='''GUARDIAN USER STOP: all new production frozen. No generation/import/engine/test running. Do not resume production until renewed user authorization.

Restore portable-v01 ZIP then final-stop delta under /workspace/scratch/pr100-continuation. Verify both ZIP SHA and every indexed member SHA. v01 is immutable first82-file history. Delta contains every later new/changed top-level file plus sourcepins/restart. For changed checkpoints, only overlay if current SHA matches delta expected_previous_sha256; old checkpoint bytes remain in base ZIP. Do not overwrite unrelated/differing files.

Target monster:가디언, original res://assets/monsters/original/atlas_2.png region[305,9,306,312], native86 grounded melee. Actual source has two massive CLOSED gauntlet fists and no held axe. Exact atlas/crop SHA proof is source-proof.json; new animations are newly authored, not extracted original frames.

E walk physical source pilot parent APPROVED ONLY: immutable whole-single PNGs walk-E-A-single-pilot1.png, walk-E-PASS1-single-pilot1.png, walk-E-B-single-pilot1.png, walk-E-PASS2-single-pilot1.png. Real opposite near/far hip-knee-boot support and stable ownhelmet/core/gauntlets directly reviewed. Frozen E-fourphase-physical-pilot-v1.json SHA74d6fb8c84bd33eb38fd80929c04e5f148e695781ef24d68285efecf8b3b064d. Own source2048/pelvisX/loadedsoleY metadata included. Intended mixed_sources_v1, no imageassembly or halfselected source. Not Main/completed.

N walk four whole-single PNGs A/PASS1/B/PASS2 are all HOLD, parent physical/crossheading and Main pending. N-fourphase-physical-pilot-v1.json SHA3b3084a09ea96c95ab4f61727bd5191bd2804aa19785a91d6da2a8899436ff40 records author opposite support trace and source2048 spine/sole anchors, not a success/completion verdict. Clean/joint fixedroot strips accompany it. E/N idle whole2s also HOLD: proportional metadata/crossheading review/Main still pending.

Whole E4 pilots1/2/3 and whole N4 pilot1 excluded ENTIRELY and preserved with exact prompts. E1 wrongyaw/clipped; E2/E3 same near-leg leading/support; N4 clipped outer fists and repeated support. Do not select good subposes from these failed whole PNGs. E true-side model is reference only; old N idle1 unqualified proportion reference only. E whole4 pilot4 request was NOT invoked.

Exact next work only after renewed authorization: independently review N4 and E/N idle2 source/model metadata; then remaining six headings W/S/SE/SW/NW/NE and remaining roles. Intended112 minimum distinct poses:4walk+2idle+3attack+2hit+3death times8. Preserve E4 exact PNGs; actual failed sources only get new separately retained art. No axes/newweapons. Mixed whole sources only, strict fullusage and globalvisible uniqueness, physical sameactor geometry, direct full8heading actualMain/combat/hit/death/drop/pickup/AI/regression, APK and CI still required. All Guardian production/Main completion flags remain false. Author changed no production profiles, maps, counts or Git; root owns import/Main/Git/count work.
'''
(p/'FINAL_USER_STOP_RESTART.txt').write_text(restart)
state=json.loads((p/'LATEST_GUARDIAN_CHECKPOINT.json').read_text());state.update({'stage':'USER_STOP_ALL_NEW_PRODUCTION_FROZEN','user_stop':True,'running_generation':False,'running_engine_or_tests':False,'E4_status':'Source physical pilot parent approved only; noMain/notcomplete;4wholePNG immutable','N4_status':'HOLD parent physical/crossheading/Main pending','idle_status':'HOLD visual/proportional metadata/Main pending','completed_added_by_author':0,'production_imported':False,'sourcepins':'FINAL_USER_STOP_SOURCE_PINS.json','resume':'FINAL_USER_STOP_RESTART.txt; only after renewed user authorization. Parent owns all production/Git/counts.'});(p/'LATEST_GUARDIAN_CHECKPOINT.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
files=[];entries={}
for f in sorted(p.iterdir()):
 if not f.is_file():continue
 digest=sha(f);old=base['entries'].get(f.name)
 if old and old['sha256']==digest:continue
 entries[f.name]={'bytes':f.stat().st_size,'sha256':digest,'change':'new' if old is None else 'updated','expected_previous_sha256':None if old is None else old['sha256']};files.append(f)
archive=p/'portable-guardian-final-stop-delta-v01';archive.mkdir(exist_ok=True);zp=archive/'guardian-final-user-stop-delta-v01.zip'
with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(f,'guardian-iron-monster-authoring/'+f.name)
assert zp.stat().st_size<90_000_000
with zipfile.ZipFile(zp) as z:
 for name,e in entries.items():assert hashlib.sha256(z.read('guardian-iron-monster-authoring/'+name)).hexdigest()==e['sha256']
index={'schema':'guardian-final-user-stop-delta-index-v1','user_stop':True,'new_production_running':False,'restore_base_then_delta':True,'restore_root':'/workspace/scratch/pr100-continuation','base_index':{'path':str(baseidx),'sha256':sha(baseidx)},'base_zip':base['zip'],'delta_zip':{'path':str(zp),'bytes':zp.stat().st_size,'sha256':sha(zp),'verified_entries':len(entries)},'all_raw_png_sourcepins':sourcepins,'entries':entries};(archive/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'base':base['zip'],'delta':index['delta_zip'],'final_sourcepins_sha256':sha(p/'FINAL_USER_STOP_SOURCE_PINS.json'),'final_restart_sha256':sha(p/'FINAL_USER_STOP_RESTART.txt'),'all_raw_generated_pngs':len(sourcepins),'status':'STOPPED; no generation/test/import/Main/count/Git mutation'},ensure_ascii=False))
