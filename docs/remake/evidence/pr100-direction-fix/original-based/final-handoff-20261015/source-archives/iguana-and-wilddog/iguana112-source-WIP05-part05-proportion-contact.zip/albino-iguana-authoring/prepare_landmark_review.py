from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,sys
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
p=Path(__file__).parent;o=p/'landmark-review';o.mkdir(exist_ok=True);c=json.loads((p/'mixed112-trial04/candidate112-trial04-HOLD.json').read_text());wanted={'S','SE','E','NW'};entries=[];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
for s in c['sheets']+c['pose_files']:
 sheet='rows' in s;g=m.analyze(Path(s['output_path']),s['rows'] if sheet else 1,s.get('reference_rows',[0]),None,s.get('directions_axis','columns'),s['canvas_size'],s.get('source_anchors',[s.get('source_anchor')]),s['directions'] if sheet else [s['direction']]);slots={}
 if sheet:
  for role,rows in s['roles'].items():
   for ph,row in enumerate(rows):
    for d,dr in enumerate(s['directions']):slots[row*len(s['directions'])+d]=(dr,role,ph)
 else:slots[0]=(s['direction'],s['role'],s['phase'])
 for i,f in enumerate(g['frames']):
  dr,role,ph=slots[i]
  if dr not in wanted or role not in ['idle','walk','attack','hit']:continue
  if role in ['attack','hit'] and ph>0:continue
  im=Image.open(s['output_path']).convert('RGBA');x,y,w,h=f['region'];cr=im.crop((x,y,x+w,y+h));bg=Image.new('RGBA',cr.size,'white');bg.alpha_composite(cr);cr=bg.convert('RGB');D=ImageDraw.Draw(cr)
  step=10 if w<500 else 50
  for xx in range(0,w,step):D.line((xx,0,xx,h),fill='#bbb',width=1);D.text((xx+1,1),str(xx),fill='black',font=font)
  for yy in range(0,h,step):D.line((0,yy,w,yy),fill='#bbb',width=1);D.text((1,yy+1),str(yy),fill='black',font=font)
  cr.resize((w*2,h*2),Image.Resampling.NEAREST).save(o/f'{dr}-{role}-{ph}-source-grid-QA.png');Image.open(s['output_path']).crop((x,y,x+w,y+h)).save(o/f'{dr}-{role}-{ph}-source-plain-QA.png');entries.append({'direction':dr,'role':role,'phase':ph,'source':s['output_path'],'source_sha256':s['source_sha256'],'frame':f,'canvas':s['canvas_size'],'crop_origin':[x,y],'grid_step_source_pixels':step,'diagnostic_only':'Cropped/nearestupsized QA reference only, never selected production source or countednewpose.'})
(o/'sources.json').write_text(json.dumps(entries,indent=2));print(json.dumps({'entries':len(entries),'root':str(o)}))
