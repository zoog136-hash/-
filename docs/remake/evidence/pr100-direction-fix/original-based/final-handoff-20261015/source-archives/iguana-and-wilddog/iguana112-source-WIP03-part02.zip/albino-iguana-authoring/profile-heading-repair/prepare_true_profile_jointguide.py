from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).parent;f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
for dr in ['E','W']:
 im=Image.new('RGB',(1024,1536),'white');d=ImageDraw.Draw(im)
 for row in range(4):
  y=row*384
  # Skeleton ONLY: narrower torso/head side profile, right/left hips are physical overlap layers.
  d.rectangle((490,y+100,550,y+190),fill='#777');d.ellipse((500,y+55,570,y+110),fill='#777');d.polygon([(560,y+73),(595,y+84),(560,y+95)] if dr=='E' else [(510,y+73),(475,y+84),(510,y+95)],fill='#777')
  sign=1 if dr=='E' else -1
  hip={'R':(530,y+190),'L':(510,y+188)};ch={}
  for k in ['R','L']:
   hx,hy=hip[k]
   if row in [0,2]:
    lead=(k=='R' if row==0 else k=='L');ch[k]=[(hx,hy),(hx+sign*(55 if lead else -55),y+240),(hx+sign*(105 if lead else -105),y+310),(hx+sign*(135 if lead else -75),y+314)]
   else:
    support=(k=='R' if row==1 else k=='L');ch[k]=[(hx,hy),(hx,y+245),(hx,y+310),(hx+sign*30,y+314)] if support else [(hx,hy),(hx+sign*65,y+225),(hx+sign*5,y+260),(hx+sign*35,y+264)]
  for k in (['L','R'] if dr=='E' else ['R','L']):
   color='#e32432' if k=='R' else '#00a5b5';d.line(ch[k],fill=color,width=28,joint='curve')
   for x,z in ch[k][:-1]:d.ellipse((x-15,z-15,x+15,z+15),fill=color,outline='black',width=2)
  d.text((28,y+18),f'{dr} phase{row} RED=RIGHT / CYAN=LEFT; skeleton guide ONLY',fill='black',font=f)
 im.save(p/f'{dr}-true-profile-fourphase-skeleton-QA.png')
 phase='Row1 A: anatomical RIGHT foreground leg LEADS to RIGHT, far LEFT trails LEFT. Row2 RIGHT foreground leg vertical SOLEsupport, LEFT foot lifted. Row3 B: anatomical RIGHT FOREGROUND thigh trails back LEFT, far LEFT thigh leads RIGHT. Row4 LEFT FAR leg vertical SOLEsupport, RIGHT FOREGROUND knee bent and foot HIGH airborne.' if dr=='E' else 'Row1 A: anatomical RIGHT FAR leg LEADS LEFT, LEFT foreground leg trails back RIGHT. Row2 RIGHT FAR leg vertical SOLEsupport, LEFT foreground knee/foot HIGH AIRBORNE. Row3 B: anatomical LEFT FOREGROUND thigh LEADS LEFT, far RIGHT trails back RIGHT. Row4 LEFT foreground leg vertical SOLEsupport, RIGHT FAR foot HIGH airborne.'
 prompt=f'''Create exactly FOUR complete new 2D blue iguana warriors following the FOUR PHYSICAL SKELETONS in reference1. Reference1 is the PRIMARY JOINT POSE instruction only: RED means anatomical RIGHT, CYAN anatomical LEFT. Render real blue scaled legs attached to their own hips through thighs/knees/shins/ankles/talons, following each different skeleton exactly. Do NOT render grey/red/cyan lines/dots/text. Reference2 gives actor's TRUE {dr} SIDE PROFILE appearance/heading/colors/equipment, NOT a fixed leg pose to repeat. This is walking horizontally {'RIGHT' if dr=='E' else 'LEFT'}, NOT front three-quarter. Torso and pelvis narrow profile, overlapping shoulders/hips, only one side eye, pale chest a NARROW stripe at forward edge. No broad frontal pale chest/two frontal shoulders. Same profile as reference2 through all4poses. Distinguish exact side E/W from SE/SW.
{phase}
Most critical: ROW3 thigh chains MUST REVERSE from row1. In {'E row3 the visible NEAR RIGHT thigh slopes BACKLEFT while far LEFT thigh slopes FORWARDRIGHT; source near-right-leading template must NOT remain' if dr=='E' else 'W row1 visible NEAR LEFT thigh slopes BACKRIGHT while far RIGHT thigh slopes FORWARDLEFT; row3 NEAR LEFT then leads LEFT'}. Don't relabel a repeated near-leg-leading pose. In passing rows2/4 actual SOLE SUPPORT side switches; the lifted foot has clear visible air gap. Exact two legs, no extra hidden legs/feet or floating detachedparts. Near side overlap: {'RIGHT spear-side leg IN FRONT of farLEFT at crossing' if dr=='E' else 'LEFT shield-side leg IN FRONT of farRIGHT at crossing'}. Both hips stay with their own anatomical side.
ONECOLUMN FOURROWS portrait1024x1536 with exactly4fullbodyposes, one per384px row. Whole figure including entire long spear/crest/tail/allclaws≤280pxTALL and≤360pxWIDE, centeredx512. Fixed moderate size all4, at least60px actual empty gutters between full bounds; no cropping/touching neighbors. Modest completeactors with lots of transparent space. Exact originalblue/teal scales/pale throat/narrowchest/darkbluecrest/yelloweye/brownleatherwaistcloth/bronzeleather straps/medallion. Calves/knees bare bluescales with only2-3narrowbronze calf bands, no newarmor/greaves/boots. RIGHT hand holds bronze-tipped brown spear, LEFT arm teal-bronzeovalshield. {'Near RIGHT spear arm visible, FAR shield is mostly edge/behindbody' if dr=='E' else 'Near LEFT shield covers foregroundflank, far RIGHT spear arm partially hidden behindbody'}. Tail physically attached from LOWERSPINE and curls {'LEFT' if dr=='E' else 'RIGHT'}, notattachedtofoot. Source original handpainted2Dstyle and mutedteal palette, noelectriccyan/goldknight/redcostume. TruecleanRGBA alpha0background, nofloor/shadow/glow/fog/matte/text/grid. Newly authored source-based 2D, not original extraction. No3D. Four physicalgaitposesandtrueprofile mandatory.'''
 (p/f'prompt-{dr}-fourphase-true-profile2-skeleton.txt').write_text(prompt)
