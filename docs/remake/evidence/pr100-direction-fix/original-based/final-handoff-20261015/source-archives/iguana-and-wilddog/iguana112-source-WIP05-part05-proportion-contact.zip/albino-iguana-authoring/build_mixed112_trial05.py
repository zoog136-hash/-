from pathlib import Path
import json,hashlib,sys,copy,math
from PIL import Image,ImageDraw,ImageFont
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
p=Path(__file__).parent;out=p/'mixed112-trial05';out.mkdir(exist_ok=True)
c=json.loads((p/'mixed112-trial04/candidate112-trial04-HOLD.json').read_text())
c['status']='STATIC_REVIEW_TRIAL05_MAIN_NOT_RUN'
c['review']['notes']='Trial05 differs from frozen04 only in S4 virtualcanvas C704 to C592, supported by homologous lowerjaw width and jawmidpoint to belt-jewel core normalized measurements. All31 rawPNG SHA256 and all112 physicalsole anchors preserved, including NW walk2 Y1126. Root reviewed all112 prior04 static matrices; root trial05 metadata review and actualMain pending. Diagnosticpoint overlays never selected as motion inputs. No completed increment.'
for s in c['sheets']:
 if s['id']=='walk4-S':
  assert s['canvas_size']==704
  s['canvas_size']=592
  s['scale_review_note']+=' Trial05: lowerjaw and jaw-to-belt both measured ~0.839 of ownidle at C704. C592 aligns both (~0.998); physicalsourceanchors and PNG remain exact. All4 minimumwholeposecanvas <=512. No anatomy edits, no resampling.'
slots={};report=[];raw=set();visible=set();bounds=[]
for s in c['sheets']+c['pose_files']:
 sheet='rows' in s
 geom=m.analyze(Path(s['output_path']),s['rows'] if sheet else 1,s.get('reference_rows',[0]),None,s.get('directions_axis','columns'),s['canvas_size'],s.get('source_anchors',[s.get('source_anchor')]),s['directions'] if sheet else [s['direction']]);m.require_complete_pose_regions(Path(s['output_path']),geom)
 im=Image.open(s['output_path']).convert('RGBA');a=np.array(im);cov=np.zeros(a.shape[:2],bool)
 for f in geom['frames']:
  x,y,w,h=f['region'];cov[y:y+h,x:x+w]=True;cr=a[y:y+h,x:x+w];rr=hashlib.sha256(cr.tobytes()).hexdigest();vv=m._visible_pose_fingerprint(cr);assert rr not in raw and vv not in visible;raw.add(rr);visible.add(vv);ax,ay=f['source_anchor'];minC=max(2*(ax-x),2*(x+w-ax),math.ceil((ay-y)*8/5),math.ceil((y+h-ay)*8/3));bounds.append({'source':s['id'],'direction':f['direction'],'row':f['row'],'region':f['region'],'anchor':f['source_anchor'],'canvas':s['canvas_size'],'minimum_canvas':minC,'margin':f['margin']})
 if sheet:
  for role,rows in s['roles'].items():
   for phase,row in enumerate(rows):
    for d,dr in enumerate(s['directions']):slots[dr,role,phase]=(s,geom['frames'][row*len(s['directions'])+d])
 else:slots[s['direction'],s['role'],s['phase']]=(s,geom['frames'][0])
 report.append({'id':s['id'],'sha256':s['source_sha256'],'bodies':len(geom['frames']),'canvas':s['canvas_size'],'max_alpha_outside_regions':int(a[:,:,3][~cov].max()),'status':'STRICT_WHOLE_PNG_PASS'})
(out/'candidate112-trial05-PROPOSED.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(out/'source-geometry112.json').write_text(json.dumps({'status':'GEOMETRY_ONLY_NOT_QUALITY','sources':report,'total':sum(x['bodies'] for x in report),'slots':len(slots),'raw_unique':len(raw),'visible_unique':len(visible),'all_bounds_fit':all(x['minimum_canvas']<=x['canvas'] for x in bounds),'full_pose_bounds':bounds,'quality':'root pending','actual_Main':'not_run','completed_added':0},indent=2))
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
for dr in m.DIRECTIONS:
 matrix=Image.new('RGB',(4*580,4*600+40),(235,235,235));D=ImageDraw.Draw(matrix);D.text((12,5),f'{dr} trial05 full112 WIP / fixed 760px per virtualcanvas / actualfloor proposal / NO Main',fill='black',font=font);ordered=[(r,f) for r,n in c['phase_counts'].items() for f in range(n)]
 for k,(role,phase) in enumerate(ordered):
  s,fr=slots[dr,role,phase];im=Image.open(s['output_path']).convert('RGBA');x,y,w,h=fr['region'];sc=760/s['canvas_size'];res=im.crop((x,y,x+w,y+h)).resize((max(1,round(w*sc)),max(1,round(h*sc))),Image.Resampling.LANCZOS);tile=Image.new('RGBA',(580,600),(245,245,245,255));td=ImageDraw.Draw(tile);ax,ay=fr['source_anchor'];tile.alpha_composite(res,(290-round((ax-x)*sc),515-round((ay-y)*sc)));td.line((10,515,570,515),fill=(145,145,145),width=1);td.line((283,515,297,515),fill='red',width=2);td.line((290,508,290,522),fill='red',width=2);td.text((8,8),f'{dr} {role}[{phase}] C={s["canvas_size"]} anchor{ax,ay}',fill='black',font=small);matrix.paste(tile.convert('RGB'),((k%4)*580,(k//4)*600+40))
 matrix.save(out/f'matrix-{dr}-14poses-WIP.png')
 walk=Image.new('RGB',(4*660,800),'white')
 for phase in range(4):
  s,fr=slots[dr,'walk',phase];im=Image.open(s['output_path']).convert('RGBA');x,y,w,h=fr['region'];sc=1000/s['canvas_size'];res=im.crop((x,y,x+w,y+h)).resize((round(w*sc),round(h*sc)),Image.Resampling.LANCZOS);t=Image.new('RGBA',(660,800),'white');t.alpha_composite(res,(330-round((fr['source_anchor'][0]-x)*sc),700-round((fr['source_anchor'][1]-y)*sc)));ImageDraw.Draw(t).text((8,8),f'{dr} phase {phase} C={s["canvas_size"]} PROPOSED',fill='black',font=font);walk.paste(t.convert('RGB'),(phase*660,0))
 walk.save(out/f'walk-{dr}-fourphase-WIP.png')
print(json.dumps({'sources':len(report),'poses':len(slots),'wholebounds':len(bounds),'raw_unique':len(raw),'visible_unique':len(visible),'output':str(out),'quality':'PENDING_ROOT_METADATA_REVIEW_MAIN_NOT_RUN'}))
