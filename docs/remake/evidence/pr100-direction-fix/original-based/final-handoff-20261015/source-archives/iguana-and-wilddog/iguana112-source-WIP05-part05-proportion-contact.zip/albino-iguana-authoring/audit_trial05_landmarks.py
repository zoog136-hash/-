from pathlib import Path
import copy, hashlib, json, math, statistics
from PIL import Image, ImageDraw, ImageFont
import numpy as np

p = Path(__file__).parent
q = p / 'landmark-review'
out = p / 'mixed112-trial05'
out.mkdir(exist_ok=True)
entries = json.loads((q / 'sources.json').read_text())
lookup = {(e['direction'], e['role'], e['phase']): e for e in entries}
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 16)
small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 13)
# Manually identified homologous visible anatomical points, in unscaled source-region
# coordinates. They are measurements with explicit picking uncertainty, not inferred
# ground-truth bones. No silhouette, crest, spear, tail or raised foot defines scale.
points = {
 ('S','idle',0): [[95,95],[131,95],[114,184]],
 ('S','idle',1): [[97,106],[132,107],[115,193]],
 ('S','walk',0): [[133,72],[164,73],[149,155]],
 ('S','walk',1): [[132,76],[166,76],[145,159]],
 ('S','walk',2): [[130,76],[162,76],[145,155]],
 ('S','walk',3): [[126,78],[160,77],[141,157]],
 ('E','idle',0): [[184,91],[219,96],[159,193]],
 ('E','idle',1): [[190,102],[228,108],[160,197]],
 ('E','walk',0): [[629,246],[738,264],[548,540]],
 ('E','walk',1): [[817,293],[930,310],[734,620]],
 ('E','walk',2): [[818,295],[931,310],[737,620]],
 ('E','walk',3): [[742,262],[856,278],[665,570]],
 ('SE','idle',0): [[190,89],[227,94],[185,174]],
 ('SE','idle',1): [[192,105],[232,110],[186,194]],
 ('SE','walk',0): [[701,301],[801,318],[658,548]],
 ('SE','walk',1): [[785,324],[891,347],[735,595]],
 ('SE','walk',2): [[797,350],[915,372],[751,616]],
 ('SE','walk',3): [[805,335],[918,354],[763,610]],
}
records=[]
for key, pts in points.items():
 dr,role,phase = key
 e = lookup[key]
 old_canvas=e['canvas']; new_canvas=592 if dr=='S' and role=='walk' else old_canvas
 a,b,pelvis=pts
 jaw=math.dist(a,b)
 head=[(a[0]+b[0])/2,(a[1]+b[1])/2] if dr=='S' else a
 core=math.dist(head,pelvis)
 uncertainty=2 if dr=='S' else (3 if role=='idle' else 12)
 rec={
  'direction':dr,'role':role,'phase':phase,'source':e['source'],
  'source_sha256':e['source_sha256'],'region_origin':e['crop_origin'],
  'point_definition':('left lowerjaw corner; right lowerjaw corner; belt blue-jewel center' if dr=='S' else 'posterior lowerjaw hinge; anterior lowerjaw/snout; visible pelvis belt center'),
  'source_region_points':pts,
  'absolute_source_points':[[x+e['crop_origin'][0],y+e['crop_origin'][1]] for x,y in pts],
  'manual_point_pick_uncertainty_source_pixels':uncertainty,
  'jaw_distance_source_pixels':jaw,'jaw_to_pelvis_source_pixels':core,
  'old_canvas':old_canvas,'proposed_canvas':new_canvas,
  'old_jaw_per_virtualcanvas':jaw/old_canvas,'old_core_per_virtualcanvas':core/old_canvas,
  'proposed_jaw_per_virtualcanvas':jaw/new_canvas,'proposed_core_per_virtualcanvas':core/new_canvas,
  'limits':'Manual projected landmarks; jaw hinge partly occluded at quarter headings. Numerical ratios support visual comparison, not automated anatomy acceptance.'}
 records.append(rec)
 im=Image.open(e['source']).convert('RGBA');x,y,w,h=e['frame']['region'];cr=im.crop((x,y,x+w,y+h))
 sc=min(4,960/max(w,h));cr=cr.resize((round(w*sc),round(h*sc)),Image.Resampling.NEAREST)
 tile=Image.new('RGB',(max(560,cr.width+40),cr.height+120),'white');tile.paste(cr,(20,75),cr);d=ImageDraw.Draw(tile)
 d.text((10,6),f'{dr} {role}[{phase}] source-landmark QA ONLY',font=font,fill='black')
 d.text((10,29),f'jaw={jaw:.2f}px core={core:.2f}px C{old_canvas} -> C{new_canvas}',font=small,fill='black')
 d.text((10,48),f'manual pick uncertainty +/-{uncertainty}px; raw PNG unchanged',font=small,fill='black')
 colors=['red','orange','green'];labels=['jaw-L' if dr=='S' else 'hinge','jaw-R' if dr=='S' else 'snout','pelvis']
 for j,((xx,yy),color,label) in enumerate(zip(pts,colors,labels)):
  xx=20+xx*sc;yy=75+yy*sc
  d.ellipse((xx-5,yy-5,xx+5,yy+5),outline=color,width=3)
  d.text((max(0,xx-110 if j==0 else xx+8),yy-18 if j!=2 else yy+8),f'{label} {pts[j]}',fill=color,font=small)
 aa=(20+a[0]*sc,75+a[1]*sc);bb=(20+b[0]*sc,75+b[1]*sc)
 d.line((*aa,*bb),fill='red',width=2)
 d.line((20+head[0]*sc,75+head[1]*sc,20+pelvis[0]*sc,75+pelvis[1]*sc),fill='green',width=2)
 tile.save(q/f'{dr}-{role}-{phase}-manual-landmarks-QA.png')

summary={}
for dr in ['S','SE','E']:
 rr=[r for r in records if r['direction']==dr]
 byrole={role:[r for r in rr if r['role']==role] for role in ['idle','walk']}
 s={}
 for role, rs in byrole.items():
  s[role]={k:statistics.mean(r[k] for r in rs) for k in ['jaw_distance_source_pixels','jaw_to_pelvis_source_pixels','old_jaw_per_virtualcanvas','old_core_per_virtualcanvas','proposed_jaw_per_virtualcanvas','proposed_core_per_virtualcanvas']}
 for stage in ['old','proposed']:
  s[stage+'_walk_to_idle_jaw_ratio']=s['walk'][stage+'_jaw_per_virtualcanvas']/s['idle'][stage+'_jaw_per_virtualcanvas']
  s[stage+'_walk_to_idle_core_ratio']=s['walk'][stage+'_core_per_virtualcanvas']/s['idle'][stage+'_core_per_virtualcanvas']
 s['interpretation']={
  'S':'Both independent normalized anatomical lengths shared the same ~16% shrink. C592 corrects shared registration without changing source anatomy, physical contact anchors, or PNG pixels.',
  'SE':'Core remains near own-idle scale. Projected lowerjaw is moderately shorter; new walk head turns further toward true SE, while idle exposes more lateral snout. Do not uniformly enlarge torso to match a projected jaw alone. Skin highlights are brighter; palette/art visual review remains separate.',
  'E':'Mean core and projected lowerjaw remain close to own idle. Walking physical skull lengths vary little between the four new true-profile poses. Phase1/3 taller whole silhouette corresponds to straight loaded leg and lifted opposite thigh; whole silhouette height is not a scale criterion.'}[dr]
 summary[dr]=s

# Exact NW2 toe plane proof. Alpha>100, half-open bounding boxes, raw 1254px source.
c04=json.loads((p/'mixed112-trial04/candidate112-trial04-HOLD.json').read_text())
nw=next(z for z in c04['pose_files'] if z['direction']=='NW' and z['phase']==2)
arr=np.asarray(Image.open(nw['output_path']).convert('RGBA'))
rois={}
for name,box in [('LEFT_away_leading_foot',[300,900,550,1100]),('RIGHT_trailing_ground_toe',[700,1000,920,1200])]:
 x0,y0,x1,y1=box;ys,xs=np.where(arr[y0:y1,x0:x1,3]>100)
 rois[name]={'source_roi':box,'visible_alpha_gt100_bbox_half_open':[int(xs.min()+x0),int(ys.min()+y0),int(xs.max()+x0+1),int(ys.max()+y0+1)]}
proof={'source':nw['output_path'],'source_sha256':hashlib.sha256(Path(nw['output_path']).read_bytes()).hexdigest(),'source_anchor_preserved':nw['source_anchor'],'feet':rois,'contact_conclusion':'RIGHT trailing foot opaque toes end at Y1126 exclusive and touch the existing source anchor Y1126. LEFT leading foot is away/up the depth plane. Do not shift the root due to a downscaled-preview apparent gap. Root directly confirmed exact 580x600 registered tile.','main':'not run','count_added':0}
(out/'NW-walk2-contact-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
(out/'homologous-landmark-measurements.json').write_text(json.dumps({'method':'Manual source-pixel projected skeletal landmarks, explicit uncertainty, normalized by source virtualcanvas. S lowerjaw-midpoint and belt-center; E/SE jawhinge and visible pelvis. No silhouette-derived scale or software anatomy modification.','summary':summary,'records':records,'diagnostic_only':True,'Main':'not run','completed_added':0},indent=2)+'\n')
print(json.dumps(summary,indent=2))
