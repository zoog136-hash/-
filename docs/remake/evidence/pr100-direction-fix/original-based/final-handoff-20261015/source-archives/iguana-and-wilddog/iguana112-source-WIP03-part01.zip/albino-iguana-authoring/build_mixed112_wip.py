from pathlib import Path
import json,hashlib,sys,copy
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
p=Path(__file__).parent;g=p/'gait-repair';q=g/'individual-walk';out=p/'mixed112-wip';out.mkdir(exist_ok=True)
old=json.loads((p/'candidate-root-reviewed.json').read_text())
c={'input_mode':'mixed_sources_v1','texture_binding':'unchanged_png_metadata','key':old['key'],'prompt':old['prompt']+'\n\nREPAIRS EXACT PROMPTS:\n'+json.dumps({str(x.relative_to(p)):x.read_text() for x in g.rglob('prompt-*.txt')},ensure_ascii=False),'prompt_record_kind':'exact_prompt_history','review':{'identity_preserved':False,'eight_views':False,'motion_roles':False,'no_clipping':False,'notes':'WIP source geometry matrix only. Root independent112 anatomical/heading/head-core/grounding review pending. No Main or completion.'},'phase_counts':{'idle':2,'walk':4,'attack':3,'hit':2,'death':3},'expected_distinct_poses':112,'display_height_basis':'median_idle','sheets':[],'pose_files':[],'source_claim':'New source-based authored 2D, not original extraction','status':'HOLD_ROOT_112_REVIEW','actual_Main':'not_run','completed_added':0}
for i,s in enumerate(old['sheets'][2:]):
 c['sheets'].append({k:copy.deepcopy(s[k]) for k in ['output_path','rows','reference_rows','directions_axis','directions','canvas_size','roles','source_anchors','scale_review_note']})
 c['sheets'][-1].update(id=f'preserved-role-sheet-{i}',source_sha256=hashlib.sha256(Path(s['output_path']).read_bytes()).hexdigest())
# Initially retain diagnostic geometry registration exactly; new head/core measurements will update metadata only.
for name,dirs in [('new-idle-front8',['E','SE','S','SW']),('new-idle-rear8',['W','NW','N','NE'])]:
 z=json.loads((g/(name+'-geometry.json')).read_text());c['sheets'].append({'id':name,'output_path':str(g/(name+'.png')),'source_sha256':hashlib.sha256((g/(name+'.png')).read_bytes()).hexdigest(),'rows':2,'reference_rows':[0,1],'directions_axis':'columns','directions':dirs,'canvas_size':z['canvas_size'][0],'roles':{'idle':[0,1]},'source_anchors':[x['source_anchor'] for x in z['frames']],'scale_review_note':'WIP registration only. Exact original whole PNG unchanged. Independent same-heading skull/torso and actual sole registration pending.'})
for dr,name,rows in [('E','walk4-E-pilot5-small-layout',[2,1,0,3]),('W','walk4-W-pilot2-guide',[0,3,2,1]),('S','walk4-S-pilot2-small-layout',[0,1,2,3]),('SW','walk4-SW-pilot2-left-heading',[0,1,2,3]),('N','walk4-N-pilot7-rear-heel-contact',[0,1,2,3])]:
 z=json.loads((g/(name+'-geometry.json')).read_text());c['sheets'].append({'id':'walk4-'+dr,'output_path':str(g/(name+'.png')),'source_sha256':hashlib.sha256((g/(name+'.png')).read_bytes()).hexdigest(),'rows':4,'reference_rows':[0,2],'directions_axis':'columns','directions':[dr],'canvas_size':z['canvas_size'][0],'roles':{'walk':rows},'source_anchors':[x['source_anchor'] for x in z['frames']],'scale_review_note':'Root static four physical phase pilot accepted. Metadata/head-core/real sole registration still WIP. No source pixels changed.'})
names={
'SE':['SE-walk0-attempt1','SE-walk1-attempt1-body-guide','SE-walk2-attempt1-body-guide','SE-walk3-attempt1-body-guide'],
'NW':['NW-walk0-attempt3-original-calf-straps','NW-walk1-attempt1-body-guide','NW-actual-B-from-requested-A-attempt1','NW-walk3-attempt2-pure-skeleton'],
'NE':['NE-walk0-attempt2-rear-heel','NE-walk1-attempt1-body-guide','NE-walk2-attempt4-trailing-heel','NE-walk3-attempt2-planted-heel']}
for dr,ls in names.items():
 for phase,name in enumerate(ls):
  z=json.loads((q/(name+'-geometry.json')).read_text());c['pose_files'].append({'id':f'whole-walk-{dr}-{phase}','output_path':str(q/(name+'.png')),'source_sha256':hashlib.sha256((q/(name+'.png')).read_bytes()).hexdigest(),'role':'walk','direction':dr,'phase':phase,'canvas_size':2048,'source_anchor':z['frames'][0]['source_anchor'],'scale_review_note':'One entire raw PNG exact bytes, one body. WIP source-only geometry/registration; independent hip chain/sole/head-core scale approval pending.'})
(out/'candidate112-WIP.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
slots={};report=[]
for s in c['sheets']+c['pose_files']:
 sheet='rows' in s
 geom=m.analyze(Path(s['output_path']),s['rows'] if sheet else 1,s.get('reference_rows',[0]),None,s.get('directions_axis','columns'),s['canvas_size'],s.get('source_anchors',[s.get('source_anchor')]),s['directions'] if sheet else [s['direction']]);m.require_complete_pose_regions(Path(s['output_path']),geom)
 if sheet:
  for role,rows in s['roles'].items():
   for phase,row in enumerate(rows):
    for d,dr in enumerate(s['directions']):slots[dr,role,phase]=(s,geom['frames'][row*len(s['directions'])+d])
 else:slots[s['direction'],s['role'],s['phase']]=(s,geom['frames'][0])
 report.append({'id':s['id'],'sha256':s['source_sha256'],'bodies':len(geom['frames']),'canvas':s['canvas_size'],'status':'STRICT_WHOLE_PNG_PASS'})
(out/'source-geometry112.json').write_text(json.dumps({'status':'GEOMETRY_ONLY_NOT_QUALITY','sources':report,'total':sum(x['bodies'] for x in report),'slots':len(slots),'missing':[str((d,r,f)) for d in m.DIRECTIONS for r,n in c['phase_counts'].items() for f in range(n) if (d,r,f) not in slots]},indent=2))
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
# One global conversion 512 screen pixels per virtual256, no per-image body fit.
for dr in m.DIRECTIONS:
 matrix=Image.new('RGB',(4*460,4*490),(235,235,235));D=ImageDraw.Draw(matrix);D.text((12,5),f'{dr} full112 WIP / fixed virtual scale / ground cross=metadata foot / no Main',fill='black',font=font)
 ordered=[(r,f) for r,n in c['phase_counts'].items() for f in range(n)]
 for k,(role,phase) in enumerate(ordered):
  s,frame=slots[dr,role,phase];im=Image.open(s['output_path']).convert('RGBA');x,y,w,h=frame['region'];crop=im.crop((x,y,x+w,y+h));sc=760/s['canvas_size'];res=crop.resize((max(1,round(w*sc)),max(1,round(h*sc))),Image.Resampling.LANCZOS)
  tile=Image.new('RGBA',(460,490),(245,245,245,255));td=ImageDraw.Draw(tile);ax,ay=frame['source_anchor'];px=230-round((ax-x)*sc);py=410-round((ay-y)*sc);tile.alpha_composite(res,(px,py));td.line((10,410,450,410),fill=(145,145,145),width=1);td.line((223,410,237,410),fill='red',width=2);td.line((230,403,230,417),fill='red',width=2);td.text((8,8),f'{dr} {role}[{phase}] C={s["canvas_size"]} anchor{ax,ay}',fill='black',font=small);matrix.paste(tile.convert('RGB'),((k%4)*460,(k//4)*490+30))
 matrix.save(out/f'matrix-{dr}-14poses-WIP.png')
 # Four walk phases, large fixed scale (same global conversion) for independent chain inspection.
 walk=Image.new('RGB',(4*620,740),'white');D=ImageDraw.Draw(walk)
 for phase in range(4):
  s,frame=slots[dr,'walk',phase];im=Image.open(s['output_path']).convert('RGBA');x,y,w,h=frame['region'];sc=1000/s['canvas_size'];crop=im.crop((x,y,x+w,y+h)).resize((round(w*sc),round(h*sc)),Image.Resampling.LANCZOS);t=Image.new('RGBA',(620,740),'white');t.alpha_composite(crop,(310-round((frame['source_anchor'][0]-x)*sc),660-round((frame['source_anchor'][1]-y)*sc)));ImageDraw.Draw(t).text((8,8),f'{dr} phase {phase} C={s["canvas_size"]} UNAPPROVED',fill='black',font=font);walk.paste(t.convert('RGB'),(phase*620,0))
 walk.save(out/f'walk-{dr}-fourphase-WIP.png')
print(json.dumps({'sources':len(report),'poses':len(slots),'output':str(out),'quality':'PENDING_ROOT_112_REVIEW'}))
