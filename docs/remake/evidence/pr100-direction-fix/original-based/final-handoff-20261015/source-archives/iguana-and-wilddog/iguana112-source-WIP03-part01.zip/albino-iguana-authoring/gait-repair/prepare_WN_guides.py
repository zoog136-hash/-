from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).parent
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
W=[
 {'R':[(505,200),(450,251),(405,338),(370,350)],'L':[(495,203),(550,260),(590,341),(560,360)]},
 {'R':[(505,200),(498,272),(496,340),(460,350)],'L':[(495,203),(445,245),(491,294),(460,305)]},
 {'R':[(505,200),(549,257),(589,332),(565,350)],'L':[(495,203),(441,260),(400,348),(364,360)]},
 {'R':[(505,200),(465,244),(508,297),(478,306)],'L':[(495,203),(488,276),(485,350),(449,360)]},
]
N=[
 {'R':[(535,200),(550,246),(550,315),(550,299)],'L':[(485,200),(470,275),(470,355),(470,339)]},
 {'R':[(535,200),(535,275),(535,355),(535,339)],'L':[(485,200),(460,244),(465,288),(465,272)]},
 {'R':[(535,200),(550,275),(550,355),(550,339)],'L':[(485,200),(470,246),(470,315),(470,299)]},
 {'R':[(535,200),(560,244),(555,288),(555,272)],'L':[(485,200),(485,275),(485,355),(485,339)]},
]
for dr,legs in [('W',W),('N',N)]:
 im=Image.new('RGB',(1024,1536),'white');d=ImageDraw.Draw(im)
 labels=['A: anatomical RIGHT lead / LEFT trail','PASS L: RIGHT support / LEFT foot airborne','B: anatomical LEFT lead / RIGHT trail','PASS R: LEFT support / RIGHT foot airborne']
 for i,(ls,label) in enumerate(zip(legs,labels)):
  off=i*384;d.text((30,off+10),label,fill='black',font=font)
  d.text((30,off+38),f'{dr}: RED = anatomical RIGHT; CYAN = anatomical LEFT. Continuous joints.',fill='black',font=small)
  if dr=='W':d.line((500,off+200,500,off+122,475,off+95,438,off+100),fill='#777',width=22)
  else:
   d.line((510,off+200,510,off+112),fill='#777',width=45);d.ellipse((485,off+80,535,off+120),fill='#777')
  d.ellipse((475,off+180,545,off+216),fill='#777')
  order=['R','L'] if dr=='W' else ['R','L']
  for k in order:
   color='#e32432' if k=='R' else '#00a5b5';pts=[(x,y+off) for x,y in ls[k]];d.line(pts,fill=color,width=16,joint='curve')
   for x,y in pts[:-1]:d.ellipse((x-9,y-9,x+9,y+9),fill=color,outline='black',width=1)
  d.text((650,off+175),'HIP / KNEE / ANKLE / TOES',fill='black',font=small)
  d.text((30,off+322),'A/B opposite actual hip-chain lead; passing feet alternate support.',fill='black',font=small)
 im.save(p/f'{dr}-fourphase-anatomical-guide.png')
 common='''Create NEW source-faithful 2D hand-painted art of ONLY attached source BLUE BIPEDAL IGUANA WARRIOR 알비노 이구아나. Reference1 original wholebody gives exact blue palette/style/source physique, yelloweyes, darkblue crest, pale throat, bronze/leatherstraps and layeredwaistcloth, longconnectedtail, RIGHT HAND long bronze pointed spear, LEFT ARM largeoval teal/bronze diamondshield. Ignore unrelatedfire above original. No 3D, new authored motion not original extraction. Reference2 is an anatomical connected joint DIAGRAM ONLY. Its red is anatomicalRIGHT, cyan anatomicalLEFT. Follow actual connected hip→thigh→knee→shin→ankle→talons, not just changed paws. Reference3 is mandatory SMALL FIGURE LAYOUT ONLY. Never render any diagram color/text/line/marker/greybox in final art. Both legs sourceBLUE.
Output portrait1024x1536, exactly ONE COLUMN × FOUR ROWS. Each whole warrior INCLUDING full spear/tail/feet must be TINY max230px high, centered x512; approximately row1 y85..299, row2 y469..683, row3 y853..1067, row4 y1237..1451. Minimum100px truly EMPTY transparent band between entire figures. Full spear/shield/tail/claws must be inside these bounds; no clipping or crossed body rectangles. Same head/torso scale all4, two connectedarms/two connectedlegs only. Genuine alpha0 background/no fog/shadow/ground/halo/glow/text/grid. Samerelativeground baselineall4.
Four actual phases: row1 A anatomicalRIGHTleg leads, LEFTtrails; row2 PASS L RIGHTleg verticalPLANTED support andLEFTfoot AIRBORNE; row3 B anatomicalLEFTleads RIGHTtrails; row4 PASS R LEFTleg verticalPLANTED support andRIGHTfoot AIRBORNE. A/B must swap actual thigh andknee ordering and same hips; near/far never switchidentity. Row2 and4 MUST alternate actualplanted leg, no bent-ankle cosmeticcopies. Cloth/tail movesasidejustenoughtoseeallupperthighchains, preservegear. Airbornefootatleast40pxabove support baselineinrelativebodygeometry. Weight visiblyover plantedleg, no allfeetfloating.
'''
 if dr=='W':specific='''ALL4 true W screenLEFTPROFILE: muzzle LEFT, tail RIGHT, one sideeye, full LEFT-side torso. Anatomical LEFT SHIELD arm andLEFTleg are NEAR foreground; RIGHT SPEAR arm/RIGHTleg FAR behind. Right spear remains onfararm, nevergear-hand swap. Far RIGHT chain is behind nearLEFT where theycross.
ROW1 A: FAR RIGHT thigh projects FORWARD LEFT from farhip, knee/ankle/talon LEFTMOST leadingPLANTED; near LEFT thigh projectsBACK RIGHT ofpelvis, nearLEFTknee andfootRIGHTMOST trailingheelraised. NearLEFT thigh must clearly run DOWN-RIGHT rather thannearlead downleft.
ROW2 PASS L: FAR RIGHTleg nearlyverticalPLANTED underhip. NEAR LEFTknee liftedforwardSCREENLEFT; LEFTshin foldsBACKRIGHT andLEFTfootisAIRBORNE. Nearleftthighbodychainvisibleintheforeground.
ROW3 B: NEAR LEFTthigh projectsFORWARD LEFT, LEFTknee/ankle/foot LEFTMOST leadingPLANTED. FAR RIGHT thigh projectsBACK RIGHT ofhip, RIGHTknee/ankle/footRIGHTMOST trailingheelraised. NearLEFTthigh mustclearlyrunDOWN-LEFT, opposite row1nearLEFTdownright. Neverlabelthesamelead differently.
ROW4 PASS R: NEAR LEFTleg verticalPLANTED underhip. FAR RIGHTknee liftedforwardSCREENLEFT; RIGHTshin foldsbackRIGHT andRIGHTfootAIRBORNE. OPPOSITEsupport to row2. Keepfar rightfootbehind nearleg wherecrossing. Four full unchangedsourcewarriors, no extra legs.'''
 else:specific='''ALL4 true N BACK view looking AWAY UPscreen, full backofskull/dorsalcrest/spine/backstraps. NO frontaleye/muzzle/chest. RIGHT spear arm/RIGHT hip/RIGHT leg remain SCREEN RIGHT; LEFTshieldarm/LEFThip/LEFTleg SCREENLEFT. TailcurvesouttoSIDEso bothhips/knees/shins/talonfeetvisible; no tailcovering centralfeet. Anatomyback not frontwithheadturn. Toes pointAWAY UPscreen. Bodies same size, no perspectivecamera switch.
ROW1 A: SCREEN RIGHT physicalRIGHT thigh/knee/ankle reaches AWAY UPscreen, RIGHT talon foot clearly40px HIGHER/UPscreen thanLEFT andPLANTED on far-groundplane. SCREENLEFT LEFTlegtrailsTOWARD viewerDOWNscreen, LEFTtalonfootclearlyLOWER andheelraised. Actualrightthighlead, not justfootlabel.
ROW2 PASS L: SCREENRIGHT RIGHTleg verticalweightbearing withRIGHTfoot PLANTED lowbaseline. SCREENLEFT LEFTknee bentandlifted, LEFTfootAIRBORNE at least40pxabovebaseline, notplantedsecondfoot. Pelvis movesoverRIGHTsupport.
ROW3 B: SCREENLEFT physicalLEFTthigh/knee/ankle now reachesAWAYUPscreen, LEFTtalonfootclearly40px HIGHER/UPscreen thanRIGHT andPLANTED. SCREENRIGHT RIGHTleg trailsTOWARDviewer DOWNscreen, RIGHTtalonfootLOWER heelraised. Visiblyoppositefore-aftlegdepthandknee/thighchain fromrow1. Do notkeepbothflatfeetunequalcosmetictail.
ROW4 PASS R: SCREENLEFT LEFTleg verticalweightbearing withLEFTfootPLANTED lowbaseline. SCREENRIGHT RIGHTkneebentandlifted, RIGHTfootAIRBORNE at least40pxabovebaseline, NOTplanted. PelvisoverLEFTsupport. Clear opposite actualsupportto row2. No frontaleye/muzzle fromanyframe.'''
 (p/f'prompt-walk4-{dr}-pilot2-guide.txt').write_text(common+specific)
