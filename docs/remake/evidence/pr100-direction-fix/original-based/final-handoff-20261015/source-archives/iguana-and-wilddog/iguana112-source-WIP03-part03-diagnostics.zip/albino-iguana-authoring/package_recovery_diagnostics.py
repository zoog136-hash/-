from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).parent;out=p.parent/'iguana-source-wip-portable';index=json.loads((out/'index.json').read_text());files=[]
for sub in ['mixed112-trial03','source-core-grids','memory31-lossless-probe']:
 for f in (p/sub).rglob('*'):
  if not f.is_file() or 'project' in f.relative_to(p/sub).parts or '__pycache__' in f.parts:continue
  if f.suffix in ['.json','.png','.txt','.py','.log','.md']:files.append(f)
files.extend([p/'RECOVERY_CURRENT.json',p/'write_recovery_checkpoint.py',p/'package_recovery_diagnostics.py']);files=sorted(set(files));dst=out/'iguana112-source-WIP03-part03-diagnostics.zip'
with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(f,'albino-iguana-authoring/'+str(f.relative_to(p)))
with zipfile.ZipFile(dst) as z:assert z.testzip() is None
meta={'file':str(dst),'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'entries':len(files),'uncompressed':sum(f.stat().st_size for f in files)};index['parts'].append(meta);have={x['path'] for x in index['inventory']}
for f in files:
 if str(f.relative_to(p)) in have:continue
 index['inventory'].append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
index['diagnostic_part3']='Adds all8current registered14pose matrices/8gaitstrips/8sourceheadcorecoordinate grids/isolated31lossless memory logs+summary. This part supplements sourceparts1/2 and overrides earlier duplicated checkpoint/README with same currentvalues. No rawselectedPNG differences.'
(out/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps(meta))
