from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).parent;out=p.parent/'iguana-source-wip-portable';idx=json.loads((out/'index.json').read_text());files=[]
for sub in ['mixed112-trial04','palette-repair']:
 for f in (p/sub).rglob('*'):
  if f.is_file() and f.suffix in ['.png','.json','.txt','.py','.md']:files.append(f)
files.extend([p/'RECOVERY_CURRENT.json',p/'write_recovery_checkpoint04.py',p/'build_mixed112_trial04.py',p/'package_recovery04.py']);files=sorted(set(files));dst=out/'iguana112-source-WIP04-part04-N-palette.zip'
with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(f,'albino-iguana-authoring/'+str(f.relative_to(p)))
with zipfile.ZipFile(dst) as z:assert z.testzip() is None
meta={'file':str(dst),'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'entries':len(files),'uncompressed':sum(f.stat().st_size for f in files)};idx['parts'].append(meta);have={x['path'] for x in idx['inventory']}
for f in files:
 path=str(f.relative_to(p));r={'path':path,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
 if path in have:idx['inventory']=[x for x in idx['inventory'] if x['path']!=path]
 idx['inventory'].append(r)
idx['latest_candidate']='albino-iguana-authoring/mixed112-trial04/candidate112-trial04-HOLD.json';idx['latest_checkpoint']='albino-iguana-authoring/RECOVERY_CURRENT.json';idx['restore']='Unzip parts01/02/03/04 in numericorder beneath /workspace/scratch/pr100-continuation. Parts04 current checkpoint overrides historic samepathcheckpoint03; read current. Allrawhistory immutable. No productionapply without independent staticQA+Main.';idx['palette_part04']='Only Nwalk4 wholePNG replaced in newproposal, prior30PNGs/108poses sourcegeometry unchanged. NewNmutedteal palette whilepreservingfourphysicalleg/heelstates; exactprompt/raw/geometry allrecorded. No completedactor claim.'
(out/'index.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n');print(json.dumps(meta))
