from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json
p=Path(__file__).parent;q=p/'profile-heading-repair';out=p/'source-core-grids';out.mkdir(exist_ok=True);f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
for dr in ['E','W']:
 for ph in range(4):
  src=q/f'{dr}-walk{ph}-true-profile-single-selected-proposal.png';im=Image.open(src).convert('RGBA');bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);im=bg.convert('RGB');D=ImageDraw.Draw(im)
  for x in range(0,im.width,50):D.line((x,0,x,im.height),fill='#aaaaaa',width=1);D.text((x+2,0),str(x),fill='black',font=f)
  for y in range(0,im.height,50):D.line((0,y,im.width,y),fill='#aaaaaa',width=1);D.text((2,y+2),str(y),fill='black',font=f)
  # Genuine sourcecoordinate crop, diagnostic ONLY.
  im.crop((250,100,min(im.width,1100),min(im.height,850))).save(out/f'{dr}-walk{ph}-source-coordinate-head-core-QA.png')
print(str(out))
