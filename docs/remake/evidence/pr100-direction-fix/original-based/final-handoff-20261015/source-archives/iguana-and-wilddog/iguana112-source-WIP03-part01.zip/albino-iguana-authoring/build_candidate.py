import sys,json,hashlib
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
p=Path(__file__).parent;q=p/'qa';q.mkdir(exist_ok=True)
specs=[
 ('idle-walk-front-spacing2',5,['E','SE','S','SW'],512,{'idle':[0,1],'walk':[2,3,4]}),
 ('idle-walk-rear-direction-spacing2',5,['W','NW','N','NE'],512,{'idle':[0,1],'walk':[2,3,4]}),
 ('attack-front-spacing2',3,['E','SE','S','SW'],728,{'attack':[0,1,2]}),
 ('attack-rear-attempt1',3,['W','NW','N','NE'],704,{'attack':[0,1,2]}),
 ('hit-death-E-SE-spacing2',5,['E','SE'],768,{'hit':[0,1],'death':[2,3,4]}),
 ('hit-death-S-SW-clean2',5,['S','SW'],728,{'hit':[0,1],'death':[2,3,4]}),
 ('hit-death-W-NW-subset1',5,['W','NW'],784,{'hit':[0,1],'death':[2,3,4]}),
 ('hit-death-N-NE-subset1',5,['N','NE'],896,{'hit':[0,1],'death':[2,3,4]})]
frames={};sheets=[];diagnostics=[];raw=set();visible=set();anchorlog=[]
for name,n,dirs,C,roles in specs:
 path=p/(name+'.png');im=Image.open(path).convert('RGBA');a=np.array(im)
 refs=[0,1] if n==5 else [0,2]
 g=m.analyze(path,rows_count=n,reference_rows=refs,directions_axis='columns',canvas_size=C,directions=dirs);m.require_complete_pose_regions(path,g)
 anchors=[];annot=Image.new('RGBA',im.size,'#161b23');annot.alpha_composite(im);draw=ImageDraw.Draw(annot)
 for f in g['frames']:
  x,y,w,h=f['region'];cr=a[y:y+h,x:x+w];rgb=cr[:,:,:3].astype(int);al=cr[:,:,3];yy,xx=np.indices(al.shape)
  fallen=('death' in roles and f['row']>=3)
  if not fallen:
   blue=(al>100)&(rgb[:,:,2]-rgb[:,:,0]>10)&(rgb[:,:,1]-rgb[:,:,0]>5)
   dark=(al>150)&(rgb.max(2)<100)&((rgb.max(2)-rgb.min(2))<35)&(yy>h*.80)
   labs,k=ndimage.label(dark);areas=np.bincount(labs.ravel());boxes=ndimage.find_objects(labs);parts=[]
   for j,area in enumerate(areas[1:]):
    if area<4:continue
    dy,dx=boxes[j]
    if dx.stop-dx.start>w*.24 or dy.stop-dy.start>h*.23:continue
    if dy.stop<h*.83:continue
    if not np.any(blue[max(0,dy.start-6):min(h,dy.stop+6),max(0,dx.start-6):min(w,dx.stop+6)]):continue
    parts.append((int(area),dx.start,dx.stop,dy.start,dy.stop))
   if parts:
    largest=max(v[0] for v in parts)
    parts=[v for v in parts if v[0]>=max(6,largest*.15)]
    maxy=max(v[4] for v in parts);parts=[v for v in parts if v[4]>=maxy-max(12,round(C/55))]
    centers=[(v[1]+v[2]-1)/2 for v in parts];ax=round((min(centers)+max(centers))/2);ay=max(v[4] for v in parts)-1;method='dark_desaturated_talon_clusters_actual_lower_support'
   else:
    z=(al>100)&(rgb[:,:,2]-rgb[:,:,0]>10)&(rgb[:,:,1]-rgb[:,:,0]>5)&(yy>h*.6)
    zy,zx=np.nonzero(z);ax=int(np.median(zx));ay=int(np.max(zy));parts=[];method='FALLBACK_blue_lower_body_REVIEW'
  else:
   blue=(al>100)&(rgb[:,:,2]-rgb[:,:,0]>10)&(rgb[:,:,1]-rgb[:,:,0]>5)
   zy,zx=np.nonzero(blue);ax=int(np.median(zx));strip=blue&(np.abs(xx-ax)<max(10,C*.055));sy,sx=np.nonzero(strip)
   # Only a proposed central body support, deliberately excluding horizontal distant spear/tail endpoints.
   ay=int(np.quantile(sy,.98));parts=[];method='proposed_central_connected_blue_corpse_support_REVIEW'
  if f['direction']=='N' and not fallen:
   blue=(al>100)&(rgb[:,:,2]-rgb[:,:,0]>10)&(rgb[:,:,1]-rgb[:,:,0]>5)
   core=blue&(yy>h*.38)&(yy<h*.69)&(xx>w*.20)&(xx<w*.80)
   cy,cx=np.nonzero(core)
   ax=int(np.median(cx))
   # Rear tail curls toward viewer beyond the physical left support foot.
   leftfoot=(al>100)&(xx>w*.02)&(xx<w*.31)&(yy>h*.72)
   fy,fx=np.nonzero(leftfoot);ay=int(fy.max());method='reviewed_N_body_axis_and_visible_left_talon_not_near_tail'
  manual_corpse_y={('hit-death-W-NW-subset1',4,'NW'):1465,('hit-death-N-NE-subset1',3,'N'):1240,('hit-death-N-NE-subset1',3,'NE'):1240,('hit-death-N-NE-subset1',4,'N'):1475,('hit-death-N-NE-subset1',4,'NE'):1478}
  if (name,f['row'],f['direction']) in manual_corpse_y:
   ay=manual_corpse_y[(name,f['row'],f['direction'])]-y;method='manual_rear_corpse_core_leg_ground_projection_excludes_near_tail'
  if name=='hit-death-E-SE-spacing2' and f['row']==0 and f['direction']=='E':
   ax=307-x;method='manual_two_visible_talon_feet_midpoint_recoil_preserved'
  if name=='hit-death-N-NE-subset1' and f['row']==2 and f['direction']=='NE':
   ax=770-x;ay=968-y;method='manual_visible_kneeling_talon_support_excludes_left_trailing_tail'
  ax=max(0,min(w-1,ax));ay=max(0,min(h-1,ay));anchors.append([x+ax,y+ay]);anchorlog.append({'sheet':name,'row':f['row'],'direction':f['direction'],'source_anchor':anchors[-1],'method':method,'parts':parts})
  draw.ellipse((x+ax-4,y+ay-4,x+ax+4,y+ay+4),outline='#ffff00',width=2)
  draw.line((x+ax-20,y+ay,x+ax+20,y+ay),fill='#48f970',width=1)
  for _,x1,x2,y1,y2 in parts:draw.rectangle((x+x1,y+y1,x+x2,y+y2),outline='#ff5566')
 g=m.analyze(path,rows_count=n,reference_rows=refs,directions_axis='columns',canvas_size=C,source_anchors=anchors,directions=dirs);m.require_complete_pose_regions(path,g)
 (q/(name+'-reviewed-geometry.json')).write_text(json.dumps(g,indent=2));annot.convert('RGB').save(q/(name+'-anchor-diagnostics.png'))
 s={'output_path':str(path),'rows':n,'reference_rows':refs,'directions_axis':'columns','directions':dirs,'canvas_size':C,'source_anchors':anchors,'roles':roles,'scale_review_note':'Proposed author same-heading skull/torso core normalization; tall spear reach and terminal collapsed height are NOT scale references. Exact coordinate QA and fixed-normalized contact provided. Root independent review and Main required.','anchor_review_note':'Proposed actual talon gray-claw support for living and central connected body support for low corpse. Original pixels untouched; reviewer must inspect all anchor diagnostics, then Main.'}
 sheets.append(s);mask=np.ones(a.shape[:2],bool)
 for f in g['frames']:
  x,y,w,h=f['region'];mask[y:y+h,x:x+w]=False;cr=a[y:y+h,x:x+w];rr=hashlib.sha256(cr.tobytes()).hexdigest();vv=m._visible_pose_fingerprint(cr);assert rr not in raw;assert vv not in visible;raw.add(rr);visible.add(vv)
  for role,rows in roles.items():
   if f['row'] in rows:frames[(f['direction'],role,rows.index(f['row']))]=(im,f,g)
 z=a[:,:,3][mask];diagnostics.append({'name':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'strict_count':len(g['frames']),'canvas':C,'max_outside_alpha':int(z.max()),'outside_gt25':int((z>25).sum()),'outside_gt100':int((z>100).sum())})
assert len(raw)==len(visible)==len(frames)==104
for d in m.DIRECTIONS:
 for role,n in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)]:assert all((d,role,k) in frames for k in range(n))
roleorder=[(r,k) for r,n in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)] for k in range(n)]
cw,ch=380,200;plot=Image.new('RGB',(cw*8,ch*14),'#161b23');draw=ImageDraw.Draw(plot)
for col,d in enumerate(m.DIRECTIONS):draw.text((col*cw+100,20),d,fill='white')
for row,(role,k) in enumerate(roleorder):
 for col,d in enumerate(m.DIRECTIONS):
  im,f,g=frames[(d,role,k)];x,y,w,h=f['region'];ax,ay=f['source_anchor'];scale=384/g['canvas_size'][0];cr=im.crop((x,y,x+w,y+h));cr=cr.resize((max(1,round(w*scale)),max(1,round(h*scale))),Image.Resampling.LANCZOS);ox=col*cw+cw//2-round((ax-x)*scale);oy=(row+1)*ch+170-round((ay-y)*scale);plot.paste(cr,(ox,oy),cr);draw.line((col*cw+15,(row+1)*ch+170,(col+1)*cw-15,(row+1)*ch+170),fill='#37634d');draw.text((col*cw+3,(row+1)*ch+3),role+str(k),fill='white')
plot.save(q/'all104-normalized-provisional.png')
proof=json.loads((p/'source-proof.json').read_text())
c={'key':'monster:알비노 이구아나','sheets':sheets,'display_height_basis':'median_idle','prompt':json.dumps({f.name:f.read_text() for f in p.glob('prompt-*.txt')},ensure_ascii=False),'prompt_record_kind':'Exact prompts saved before each generation; raw generated PNG copies unchanged.','review':{'identity_preserved':True,'eight_views':True,'motion_roles':True,'no_clipping':True,'notes':'Author reviewed eight genuine views/all5roles and104 strict complete source poses. Spears/shields source anatomical hand identity maintained; source groundedfloatingfalse, slash/melee0.44,height86 preserved. All104 raw+visibleunique. Several failed direction/spacing/alpha outputs retained and excluded. Per-sheet core scale and per-pose support anchors remain proposed pending diagnostic/independent/Main review; no completion claim.'},'status':'AUTHOR104_STRICT_PASS_SCALE_ANCHOR_REVIEW_IN_PROGRESS','independent_qa_approved':False,'actual_Main':'not_run','completed_added':0,'source_proof_path':str(p/'source-proof.json'),'presentation_to_preserve':proof['presentation_to_preserve'],'source_claim':'New authored source-based2D, not recovered original animation.','png_sha256':{str(p/(d['name']+'.png')):d['sha256'] for d in diagnostics}}
(p/'candidate-provisional.json').write_text(json.dumps(c,ensure_ascii=False,indent=2));(q/'strict104.json').write_text(json.dumps({'sheets':diagnostics,'raw_unique':104,'visible_unique':104,'runtime_used':104,'unused_source_poses':0},indent=2));(q/'anchor-diagnostics.json').write_text(json.dumps(anchorlog,indent=2));print(json.dumps({'selected104':True,'canvases':[s['canvas_size'] for s in sheets],'fallback_anchors':[a for a in anchorlog if a['method'].startswith('FALLBACK')]},indent=2))
