from pathlib import Path
from PIL import Image
import sys,json,hashlib,numpy as np,shutil
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
p=Path(__file__).parent;src=Path(sys.argv[1]);name=sys.argv[2];dr=sys.argv[3];phase=int(sys.argv[4]);dst=p/(name+'.png')
if not dst.exists():shutil.copyfile(src,dst)
assert src.read_bytes()==dst.read_bytes()
r={'path':str(dst),'tool_original':str(src),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'unchanged_copy':True,'proposed_actual_direction':dr,'proposed_actual_phase':phase,'visual_status':'PENDING_INDEPENDENT_HIP_CHAIN_SCALE_HEEL_REVIEW'}
try:
 g=m.analyze(dst,rows_count=1,reference_rows=[0],directions_axis='columns',canvas_size=2048,directions=[dr]);m.require_complete_pose_regions(dst,g);r.update(strict_status='PASS',count=len(g['frames']),neutral_height=g['neutral_height']);(p/(name+'-geometry.json')).write_text(json.dumps(g,indent=2));a=np.array(Image.open(dst));mask=np.ones(a.shape[:2],bool)
 for f in g['frames']:
  x,y,w,h=f['region'];mask[y:y+h,x:x+w]=False
 r.update(max_outside_alpha=int(a[:,:,3][mask].max()),outside_gt25=int((a[:,:,3][mask]>25).sum()))
except Exception as e:r.update(strict_status='FAIL',strict_error=str(e))
(p/(name+'-validation.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r))
