from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import shutil,json
p=Path(__file__).parent;shutil.copyfile('/workspace/generated_images/exec-94b995e0-7f3d-4af3-a1ee-29ef693b28ad.png',p/'E-single-B-opposite-blue-final1.png');f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22)
for dr in ['E','W']:
 src=p/('E-single-B-opposite-blue-final1.png' if dr=='E' else 'W-single-opposite-stride-pilot2-A-proposed.png')
 for phase in [1,3]:
  im=Image.open(src).convert('RGBA');bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);im=bg.convert('RGB');d=ImageDraw.Draw(im)
  if dr=='E':
   d.rectangle((350,690,1190,1220),fill='#eee');ch={'R':[(745,710),(745,920),(745,1120),(810,1140)],'L':[(690,715),(840,850),(770,950),(830,970)]} if phase==1 else {'R':[(745,710),(900,850),(820,950),(880,970)],'L':[(690,715),(690,920),(690,1120),(755,1140)]}
  else:
   d.rectangle((200,710,970,1240),fill='#eee');ch={'R':[(610,730),(610,950),(610,1160),(545,1180)],'L':[(550,750),(410,875),(470,1000),(420,1020)]} if phase==1 else {'R':[(610,730),(470,855),(530,970),(480,990)],'L':[(550,750),(550,950),(550,1160),(485,1180)]}
  for k in (['L','R'] if dr=='E' else ['R','L']):
   col='#e32432' if k=='R' else '#00a5b5';d.line(ch[k],fill=col,width=55,joint='curve')
   for x,y in ch[k][:-1]:d.ellipse((x-27,y-27,x+27,y+27),fill=col,outline='black',width=4)
  d.text((25,25),f'{dr} phase{phase}: PRIMARY support / airborne chains. RED=RIGHT CYAN=LEFT',fill='black',font=f);im.save(p/f'{dr}-walk{phase}-passing-body-guide-QA.png')
  action='RIGHT physical leg is VERTICAL SINGLE SUPPORT, RIGHT foot PLANTED. LEFT physical knee bent and LEFT foot CLEARLY AIRBORNE at least150px higher than planted foot.' if phase==1 else 'LEFT physical leg is VERTICAL SINGLE SUPPORT, LEFT foot PLANTED. RIGHT physical knee bent and RIGHT foot CLEARLY AIRBORNE at least150px higher than planted foot.'
  near='RIGHT spear-side leg is NEAR and its thigh overlaps farLEFT where theycross' if dr=='E' else 'LEFT shield-side leg is NEAR and its thigh overlaps farRIGHT where theycross'
  prompt=f'''Finish exactly ONE whole newhandpainted2D blueiguana from this QA construction image. Upperbodyisactualsourceidentity/trueprofile appearance; lowergreyblank+RED/CYANchainsareintentionalposeconstruction: replacewithproperBLUEscaledlegsattachedfromownhips through EXACT thigh/knee/shin/ankle/toechains. RED=anatomicalRIGHT, CYAN=LEFT. DoNOTdrawgrey/red/cyan/lines/dots/text infinal. DoNOTrestorestaticdefaultlegpose. {action} Sourceimage shows exact target phase{phase}. The lifted foot is not grounded, toes clearly suspended high. Bodyweight over the one planted support. {near}. Keep same anatomical hips and near/far overlap, do not swap names while keeping old pose.
Whole actor facing TRUE {'RIGHT EAST' if dr=='E' else 'LEFT WEST'} sideprofile, oneeye/narrowpalecheststrip/overlappingshoulders+hips, nofront3quarterchest. Preserve exact upperhead/torso/arms/gear/palette/proportions fromreference. Muscularblue/tealscales/pale throat/darkbluecrest/yelloweyes/brownwaistcloth/bronzeleatherstraps/medallion, RIGHTbrownlongbronzespear/LEFTovaltealbronzeshield. Barebluescaledknees+calves with2-3narrowbronze calfbands, no newgreaves/boots/armor/redcostume. Samewholefull tail naturally attached fromLOWERSPINEbehindcloth, nofootattachment. Reconstructwaistclothswingaroundlegposewithoutconcealinghipconnections. Exact2arms2legs, fullheadbodyarmslegstoesentirespearentiretail visible, no clipping/merged/detached pieces. ONEcompletefigure, square1280transparentRGBA with≥100pxempty margins; nofloor/shadow/glow/fog/text/diagrammarks/3D. Newly authored source-based2D notoriginalextraction. Real physical support/airborne switch is mandatory.'''
  (p/f'prompt-{dr}-walk{phase}-passing-single1.txt').write_text(prompt)
print('Prepared four passing guides/prompts')
