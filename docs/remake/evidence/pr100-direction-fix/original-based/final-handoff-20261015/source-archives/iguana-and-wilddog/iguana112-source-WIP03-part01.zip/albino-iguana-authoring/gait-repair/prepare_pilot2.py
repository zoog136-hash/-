from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import shutil,sys,json,hashlib,numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
p=Path(__file__).parent
files={'E':'exec-112f631c-3ff5-4d60-ad75-7103ad6c27b7.png','W':'exec-a143fec6-5af8-4c0f-8085-9d864060a15a.png','N':'exec-bd0b5fb5-2062-41aa-b172-0ca74fc90fbb.png'}
for dr,fn in files.items():
 src=Path('/workspace/generated_images')/fn;dst=p/f'walk4-{dr}-pilot1.png';shutil.copyfile(src,dst)
 r={'direction':dr,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'tool_original':str(src),'unchanged_copy':dst.read_bytes()==src.read_bytes(),'quality':'HOLD_ACTUAL_HIP_CHAIN_OR_SUPPORT_REPEATS'}
 try:
  g=m.analyze(dst,rows_count=4,reference_rows=[0,2],directions_axis='rows',canvas_size=1536,directions=[dr]);m.require_complete_pose_regions(dst,g)
  r.update(strict_status='PASS',bodies=len(g['frames']));(p/f'walk4-{dr}-pilot1-geometry.json').write_text(json.dumps(g,indent=2))
 except Exception as e:r.update(strict_status='FAIL',strict_error=str(e))
 (p/f'walk4-{dr}-pilot1-validation.json').write_text(json.dumps(r,indent=2))
 print(r)
# Explicit connected anatomical-leg diagram. This is a QA instruction reference, never a game asset.
im=Image.new('RGB',(1024,1536),'white');d=ImageDraw.Draw(im)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
# Local x positions; E faces RIGHT. y360 is near-ground; far-ground y350.
legs=[
 {'R':[(505,203),(559,260),(600,348),(636,360)],'L':[(495,200),(451,257),(411,332),(435,350)]},
 {'R':[(505,203),(512,276),(515,350),(551,360)],'L':[(495,200),(535,244),(492,297),(522,306)]},
 {'R':[(505,203),(451,260),(411,341),(441,360)],'L':[(495,200),(552,251),(599,338),(636,350)]},
 {'R':[(505,203),(554,245),(509,294),(540,305)],'L':[(495,200),(502,272),(504,340),(540,350)]},
]
labels=['A: RIGHT near leg FORWARD; LEFT far leg BACK','PASS L: RIGHT near leg SUPPORT; LEFT far leg lifted','B: LEFT far leg FORWARD; RIGHT near leg BACK','PASS R: LEFT far leg SUPPORT; RIGHT near leg lifted']
for i,(ls,label) in enumerate(zip(legs,labels)):
 off=i*384
 d.text((30,off+10),label,fill='black',font=font)
 d.text((30,off+38),'RED = anatomical RIGHT / near; CYAN = LEFT / far. E faces RIGHT.',fill='black',font=small)
 d.line((340,off+360,690,off+360),fill='#aaa',width=2)
 # body gray, head to RIGHT, source fixed physique/gear come from source image rather than diagram.
 d.line((500,off+200,500,off+122,525,off+95,562,off+100),fill='#777',width=22)
 d.ellipse((480,off+180,525,off+216),fill='#777')
 # Draw far chain first, near chain on top at crossings.
 for k,color in [('L','#00a5b5'),('R','#e32432')]:
  pts=[(x,y+off) for x,y in ls[k]]
  d.line(pts,fill=color,width=16,joint='curve')
  for x,y in pts[:-1]:d.ellipse((x-9,y-9,x+9,y+9),fill=color,outline='black',width=1)
 d.text((720,off+188),'HIP -> KNEE -> ANKLE -> TOES',fill='black',font=small)
 d.text((35,off+320),('A and B must reverse WHICH connected thigh leads.' if i in (0,2) else 'Lifted foot has CLEAR AIR GAP. Other leg bears weight.'),fill='black',font=small)
im.save(p/'E-fourphase-anatomical-guide.png')
base=(p/'prompt-walk4-E-pilot1.txt').read_text()
prompt='''Create NEW source-faithful 2D hand-painted art of the blue iguana warrior from reference 1. Reference 2 is an ANATOMICAL INSTRUCTION DIAGRAM ONLY. Follow its exact HIP→KNEE→ANKLE→TOES connections and physical leg positions in the FOUR corresponding rows. Never render diagram text, dots, red/cyan colors, lines or markers in final artwork. Both real legs retain original BLUE scale colors. Preserve reference 1 costume, source palette, head, tall spiky crest, long tail, chest straps, layered waistcloth, anatomical RIGHT spear hand, anatomical LEFT oval diamond shield. Ignore unrelated fire above source actor. No 3D.
Output portrait 1024x1536 with EXACTLY ONE COLUMN × FOUR ROWS, four complete small whole warriors, not four columns. Each row is 384px tall. FULL SPEAR TIP to lowest TALON and FULL TAIL must fit inside its row with 45px clear top/bottom padding. Figure height including vertical spear ≤280px. Center each full warrior in wide row. Huge transparent horizontal/vertical gutters. No shadow, floor, halo, fog, background or text. Real clean RGBA alpha0 outside figures. No clipped/merged/detached pieces. Ground support at same relative y in each row. Same head/core scale all four.
All four figures true E RIGHT PROFILE, muzzle RIGHT, tail LEFT. Near anatomical RIGHT hip and leg is foreground, on same body side as RIGHT SPEAR hand; far LEFT leg stays behind, same side as shield. TWO arms/TWO legs only. Cloth moves aside enough to see correct upper thighs. Main task is actual physically reversed leading limb, NOT same pose with another bent ankle. The second reference diagram explicitly defines it; follow it.
ROW1 A: foreground RIGHT thigh projects FORWARD RIGHT of pelvis. RIGHT knee then ankle then talon are RIGHTMOST leading. Far LEFT leg projects BACK LEFT, foot behind. Right leading heel bears weight, left trailing heel rises.
ROW2 PASS L: near RIGHT leg is nearly VERTICAL and weight bearing, RIGHT talon PLANTED on ground. Far LEFT thigh lifts forward with LEFT knee bent, LEFT shin folds backward, LEFT FOOT has visible AIR under it. Keep hip→knee→shin fully connected.
ROW3 B: foreground RIGHT thigh now projects BACK LEFT of pelvis. RIGHT knee BEHIND LEFT of hip; RIGHT shin/ankle/foot trail LEFT, heel raised. Far LEFT thigh projects FORWARD RIGHT with LEFT knee RIGHT of hip and LEFT shin/ankle leading to the RIGHTMOST talon planted on ground. This is an unmistakable different crossed-leg silhouette from row1. Foreground RIGHT thigh must run DOWN-LEFT, never DOWN-RIGHT. Near RIGHT overlaps far LEFT at crossing while both attach their OWN hips. Do not swap the names of the same near-leg-leading pose.
ROW4 PASS R: far LEFT leg nearly VERTICAL weight-bearing, LEFT talon PLANTED. Foreground RIGHT thigh lifted forward, RIGHT knee BENT, RIGHT shin folds BACK LEFT, RIGHT FOOT visibly AIRBORNE behind the knee. This is the opposite physical support to row2. Torso subtle weight transfer and tail counterbalance, no floating. No detached foot. Follow the diagram's continuous joints.
Source look and gear identity remain exact. Newly authored 2D motion, not claimed original extraction. Four genuine articulated walk phases with actual alternating anatomical leg chains.'''
(p/'prompt-walk4-E-pilot2-guide.txt').write_text(prompt)
