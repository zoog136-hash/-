from pathlib import Path
import json,subprocess,os,time,resource,sys
p=Path(__file__).parent;kind=sys.argv[1];env=os.environ.copy();env['XDG_DATA_HOME']=str(p/'xdg');env['DISPLAY']=':99';env['LIBGL_ALWAYS_SOFTWARE']='1';base=['/workspace/scratch/bin/godot-pr100','--path',str(p/'project')]
if kind=='import':cmd=base+['--headless','--editor','--import']
elif kind=='headless31':cmd=base+['--headless','--script','res://probe.gd','--','31',str(p/'headless31.json'),'inspect']
elif kind=='gl31':cmd=base+['--rendering-driver','opengl3','--audio-driver','Dummy','--script','res://probe.gd','--','31',str(p/'gl31.json'),'inspect']
else:raise SystemExit(kind)
start=time.monotonic()
with (p/(kind+'-python.stdout.log')).open('wb') as out, (p/(kind+'-python.stderr.log')).open('wb') as err:r=subprocess.run(cmd,env=env,stdout=out,stderr=err)
record={'kind':kind,'command':cmd,'elapsed_seconds':time.monotonic()-start,'exit_code':r.returncode,'peak_children_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'scope':'Isolated sourcePNG lossless memory only; not Main/quality/Androidrealdevice'};(p/(kind+'-process.json')).write_text(json.dumps(record,indent=2));print(json.dumps(record));raise SystemExit(r.returncode)
