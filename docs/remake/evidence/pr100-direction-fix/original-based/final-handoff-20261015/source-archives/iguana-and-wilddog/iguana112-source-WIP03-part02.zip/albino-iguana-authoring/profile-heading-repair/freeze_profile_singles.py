from pathlib import Path
from PIL import Image
import json,shutil,hashlib,sys,numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
p=Path(__file__).parent
cases=[('E',0,'exec-5da4cd53-731a-4bcb-8cbb-63ee313c180d.png'),('E',1,'exec-cd8405b9-a738-45fd-bd20-e1a8d9947604.png'),('E',2,'exec-94b995e0-7f3d-4af3-a1ee-29ef693b28ad.png'),('E',3,'exec-86368c0f-af5e-4657-8d8c-c2c807ff0926.png'),('W',0,'exec-7af54ad3-f411-4123-bdf3-f2184af91f1d.png'),('W',1,'exec-849a5342-c252-4d8b-b859-ed44d0fdf6a7.png'),('W',2,'exec-59dc26f8-e007-442b-aa17-5e464829abf5.png'),('W',3,'exec-10cc9a00-a328-447f-a587-b1f5859a381f.png')]
report=[]
for dr,phase,src in cases:
 dst=p/f'{dr}-walk{phase}-true-profile-single-selected-proposal.png';source=Path('/workspace/generated_images')/src
 if not dst.exists():shutil.copyfile(source,dst)
 assert dst.read_bytes()==source.read_bytes()
 r={'path':str(dst),'tool_original':str(source),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'direction':dr,'phase':phase,'status':'SOURCE_PROPOSED_ROOT_PENDING','Main':'not_run','completed_added':0}
 try:
  g=m.analyze(dst,1,[0],None,'columns',2048,None,[dr]);m.require_complete_pose_regions(dst,g);r.update(strict='PASS',size=list(Image.open(dst).size),region=g['frames'][0]['region']);(p/f'{dr}-walk{phase}-true-profile-single-selected-proposal-geometry.json').write_text(json.dumps(g,indent=2));a=np.array(Image.open(dst));r['edge_alpha_max']=int(max(a[0,:,3].max(),a[-1,:,3].max(),a[:,0,3].max(),a[:,-1,3].max()))
 except Exception as e:r.update(strict='FAIL',error=str(e))
 report.append(r)
(p/'true-profile-eight-single-proposal.json').write_text(json.dumps({'status':'PENDING_ROOT_PHYSICAL_DIRECTION_SCALE_REVIEW','raw_png':report,'count':len(report),'original_sheets_unselected':'E/W former whole4 sheets never partially selected; all raw history immutable. No software PNG reassembly/crop/resample used in selected PNGs. Diagnostic guides include source crops solely as authoring references.','colored_studies':'3 explicitly unselected intermediate anatomical studies; final separate whole rawPNG only may count after review/Main.','completed_added':0},indent=2));print(json.dumps(report,indent=2))
