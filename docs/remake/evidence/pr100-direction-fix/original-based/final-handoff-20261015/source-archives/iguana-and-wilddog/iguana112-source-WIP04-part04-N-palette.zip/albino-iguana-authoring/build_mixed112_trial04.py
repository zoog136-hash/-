from pathlib import Path
import json,hashlib,sys,copy,math
from PIL import Image,ImageDraw,ImageFont
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
p=Path(__file__).parent;q=p/'profile-heading-repair';out=p/'mixed112-trial04';out.mkdir(exist_ok=True)
c=json.loads((p/'mixed112-wip/candidate112-WIP.json').read_text());c['sheets']=[s for s in c['sheets'] if s['id'] not in ['walk4-E','walk4-W']];c['prompt']+='\nTRUE_PROFILE_REPAIR_EXACT_PROMPTS:\n'+json.dumps({str(x.relative_to(p)):x.read_text() for x in q.glob('prompt-*.txt')},ensure_ascii=False)
c['prompt']+='\nN_PALETTE_EXACT_PROMPT:\n'+(p/'palette-repair/prompt-N-walk4-palette-only1.txt').read_text()
c['status']='HOLD_ROOT_FULL112_STATIC_REVIEW_TRIAL04';c['review']['notes']='Trial04: all112 source geometry complete, five8direction walk singles +3whole4posewalk sheets. Static actual chain/yaw proposals pending independent root review. Colored diagnostic studies never selected. Metadata only proposed skull/core registration, source rawPNG byteunchanged. No Main/import/completion.'
for s in c['sheets']:
 oldC=s['canvas_size']
 if s['id'].startswith('preserved-role-sheet-'):s['canvas_size']=round(oldC*.76/8)*8;s['scale_review_note']+=' Trial04 uniformly rebase preserved64 virtualcanvases by k~.76 within measured wholepose bounds, source byte unchanged. This is relative registration proposal, no accepted production asset altered.'
 if s['id'].startswith('new-idle-'):s['canvas_size']=640
 if s['id']=='walk4-N':
  s['canvas_size']=800;s['output_path']=str(p/'palette-repair/N-walk4-palette-only1-proposed.png');s['source_sha256']=hashlib.sha256(Path(s['output_path']).read_bytes()).hexdigest()
 if s['id']=='walk4-S':s['source_anchors']=[[517,376],[497,750],[555,1117],[553,1474]]
 if s['id']=='walk4-SW':s['source_anchors']=[[510,350],[440,739],[485,1093],[571,1490]]
 if s['id']=='walk4-N':s['source_anchors']=[[518,368],[561,740],[518,1100],[477,1487]]
 if s['id']=='new-idle-rear8':s['source_anchors'][2]=[950,440];s['source_anchors'][6]=[950,890]
profiles=json.loads((q/'true-profile-eight-single-proposal.json').read_text())['raw_png']
for r in profiles:
 if r['direction']=='W' and r['phase']==1:
  r['path']=str(q/'W-walk1-true-profile-single-proportion2-proposed.png');r['sha256']=hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()
# Per-single virtualunit proposals based same-heading skull/core; exact sourceproof measurement follows, no silhouettefit.
Cmap={('E',0):2048,('E',1):2048,('E',2):2048,('E',3):2048,('W',0):2048,('W',1):2048,('W',2):1792,('W',3):1856}
anchors={('E',0):[719,1106],('E',1):[809,1186],('E',2):[780,1157],('E',3):[710,1180],('W',0):[532,1196],('W',1):[621,1193],('W',2):[558,1099],('W',3):[641,1087]}
for r in profiles:
 dr,phase=r['direction'],r['phase'];c['pose_files'].append({'id':f'true-profile-walk-{dr}-{phase}','output_path':r['path'],'source_sha256':r['sha256'],'role':'walk','direction':dr,'phase':phase,'canvas_size':Cmap[dr,phase],'source_anchor':anchors[dr,phase],'scale_review_note':'Trial04 metadata proposal: same-heading physical skull/upper torso core rather than full silhouette/spear/raisedfoot. Root exactpoint review pending; original raw PNG byte unchanged. Actual source talon sole / doublecontact ground anchor proposed, no Main yet.'})
for s in c['pose_files']:
 dr,ph=s['direction'],s['phase']
 if dr=='SE':
  s['canvas_size']=[1792,2048,2048,2048][ph];s['source_anchor']=[[756,1155],[708,1220],[815,1200],[912,1212]][ph]
 if dr=='NW':
  s['canvas_size']=[2048,2048,1792,2048][ph];s['source_anchor']=[[514,1170],[655,1171],[584,1110],[451,1184]][ph]
 if dr=='NE':s['source_anchor']=[[720,1215],[862,1194],[800,1198],[718,1185]][ph]
# Actual source sole bottom for living standalone walks: tail/spear ends are above actual feet in all20 rawposes. Root visual confirmation pending.
for s in c['pose_files']:
 zz=m.analyze(Path(s['output_path']),1,[0],None,'columns',2048,None,[s['direction']]);fr=zz['frames'][0];s['source_anchor'][1]=fr['region'][1]+fr['region'][3]-4
slots={};report=[];raw=set();visible=set();bounds=[]
for s in c['sheets']+c['pose_files']:
 sheet='rows' in s
 geom=m.analyze(Path(s['output_path']),s['rows'] if sheet else 1,s.get('reference_rows',[0]),None,s.get('directions_axis','columns'),s['canvas_size'],s.get('source_anchors',[s.get('source_anchor')]),s['directions'] if sheet else [s['direction']]);m.require_complete_pose_regions(Path(s['output_path']),geom)
 im=Image.open(s['output_path']).convert('RGBA');a=np.array(im);cov=np.zeros(a.shape[:2],bool)
 for f in geom['frames']:
  x,y,w,h=f['region'];cov[y:y+h,x:x+w]=True;cr=a[y:y+h,x:x+w];rr=hashlib.sha256(cr.tobytes()).hexdigest();vv=m._visible_pose_fingerprint(cr);assert rr not in raw and vv not in visible;raw.add(rr);visible.add(vv);ax,ay=f['source_anchor'];minC=max(2*(ax-x),2*(x+w-ax),math.ceil((ay-y)*8/5),math.ceil((y+h-ay)*8/3));bounds.append({'source':s['id'],'direction':f['direction'],'row':f['row'],'region':f['region'],'anchor':f['source_anchor'],'canvas':s['canvas_size'],'minimum_canvas':minC,'margin':f['margin']})
 if sheet:
  for role,rows in s['roles'].items():
   for phase,row in enumerate(rows):
    for d,dr in enumerate(s['directions']):slots[dr,role,phase]=(s,geom['frames'][row*len(s['directions'])+d])
 else:slots[s['direction'],s['role'],s['phase']]=(s,geom['frames'][0])
 report.append({'id':s['id'],'sha256':s['source_sha256'],'bodies':len(geom['frames']),'canvas':s['canvas_size'],'max_alpha_outside_regions':int(a[:,:,3][~cov].max()),'status':'STRICT_WHOLE_PNG_PASS'})
(out/'candidate112-trial04-HOLD.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(out/'source-geometry112.json').write_text(json.dumps({'status':'GEOMETRY_ONLY_NOT_QUALITY','sources':report,'total':sum(x['bodies'] for x in report),'slots':len(slots),'raw_unique':len(raw),'visible_unique':len(visible),'all_bounds_fit':all(x['minimum_canvas']<=x['canvas'] for x in bounds),'full_pose_bounds':bounds,'quality':'root pending','actual_Main':'not_run','completed_added':0},indent=2))
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
for dr in m.DIRECTIONS:
 matrix=Image.new('RGB',(4*580,4*600+40),(235,235,235));D=ImageDraw.Draw(matrix);D.text((12,5),f'{dr} trial04 full112 WIP / fixed 760px per virtualcanvas / actualfloor proposal / NO Main',fill='black',font=font);ordered=[(r,f) for r,n in c['phase_counts'].items() for f in range(n)]
 for k,(role,phase) in enumerate(ordered):
  s,fr=slots[dr,role,phase];im=Image.open(s['output_path']).convert('RGBA');x,y,w,h=fr['region'];sc=760/s['canvas_size'];res=im.crop((x,y,x+w,y+h)).resize((max(1,round(w*sc)),max(1,round(h*sc))),Image.Resampling.LANCZOS);tile=Image.new('RGBA',(580,600),(245,245,245,255));td=ImageDraw.Draw(tile);ax,ay=fr['source_anchor'];tile.alpha_composite(res,(290-round((ax-x)*sc),515-round((ay-y)*sc)));td.line((10,515,570,515),fill=(145,145,145),width=1);td.line((283,515,297,515),fill='red',width=2);td.line((290,508,290,522),fill='red',width=2);td.text((8,8),f'{dr} {role}[{phase}] C={s["canvas_size"]} anchor{ax,ay}',fill='black',font=small);matrix.paste(tile.convert('RGB'),((k%4)*580,(k//4)*600+40))
 matrix.save(out/f'matrix-{dr}-14poses-WIP.png')
 walk=Image.new('RGB',(4*660,800),'white')
 for phase in range(4):
  s,fr=slots[dr,'walk',phase];im=Image.open(s['output_path']).convert('RGBA');x,y,w,h=fr['region'];sc=1000/s['canvas_size'];res=im.crop((x,y,x+w,y+h)).resize((round(w*sc),round(h*sc)),Image.Resampling.LANCZOS);t=Image.new('RGBA',(660,800),'white');t.alpha_composite(res,(330-round((fr['source_anchor'][0]-x)*sc),700-round((fr['source_anchor'][1]-y)*sc)));ImageDraw.Draw(t).text((8,8),f'{dr} phase {phase} C={s["canvas_size"]} PROPOSED',fill='black',font=font);walk.paste(t.convert('RGB'),(phase*660,0))
 walk.save(out/f'walk-{dr}-fourphase-WIP.png')
print(json.dumps({'sources':len(report),'poses':len(slots),'wholebounds':len(bounds),'raw_unique':len(raw),'visible_unique':len(visible),'output':str(out),'quality':'PENDING_ROOT_112_REVIEW'}))
