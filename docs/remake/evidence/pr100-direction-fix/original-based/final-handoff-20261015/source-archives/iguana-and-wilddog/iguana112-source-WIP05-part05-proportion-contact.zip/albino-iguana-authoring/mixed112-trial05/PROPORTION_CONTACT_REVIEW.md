Trial05 is a metadata-only registration proposal for `monster:알비노 이구아나`.
It is ready for the root reviewer's Main trial after the S change is accepted.
It is not a completion record. Main has not run and the author added zero completed actors.

The frozen trial04 and all 31 selected original generated PNG bytes remain intact.
Only the S four-pose sheet's virtual canvas changes from 704 to 592. All 112
source anchors stay identical. Whole-source coverage, visible uniqueness and
whole-pose canvas bounds pass. The largest required S canvas is 512, below 592.
No alpha extraction, body assembly, raw PNG resampling, stance replacement or
new animation frame was used for this correction.

Two independent S anatomical measurements share the same registration error:

| Projected anatomical distance | Own idle2 mean | S walk4 mean at old canvas | Walk/idle old | Walk/idle C592 |
| --- | --- | --- | --- | --- |
| Lower-jaw corner to corner | 35.507 px / 640 | 32.758 px / 704 | 0.838697 | 0.997369 |
| Jaw midpoint to belt-jewel center | 87.754 px / 640 | 81.032 px / 704 | 0.839462 | 0.998279 |

These are manual projected source-pixel measurements, with +/-2 px picking
uncertainty for S. Exact absolute source points and annotated diagnostic overlays
are saved in `homologous-landmark-measurements.json` and
`../landmark-review/*manual-landmarks-QA.png`. Source art is not modified by
the overlays. Crest, spear, tail, lifted feet and whole silhouette height were
excluded from the scale decision.

SE and E use posterior lower-jaw hinge to snout and hinge to visible pelvis;
the points have +/-3 px idle / +/-12 px large-source walking uncertainty.
SE walking/idle normalized means are jaw 0.923667 and core 0.994989.
The quarter-view walking head turns further toward SE, exposing less lateral
snout. The projected jaw alone does not justify enlarging an already matched
core. E means are jaw 0.960569 and core 0.988568. E phase1/3 height changes
correspond to a straight loaded leg and opposite lifted thigh, while the
physical skull/core measurements remain close to its own idle. Brighter SE
scale highlights are visible; palette and anatomy visual acceptance remains
separate from geometric acceptance.

NW heading was checked against its own idle, attack and hit source crops.
All expose a back torso with crossed straps, LEFT near shield and RIGHT far
spear. Idle/attack turn the head farther left to expose the side snout; the new
walk keeps the head more closed away. This is a head-yaw difference within a
consistent back-left torso heading, not reversed near/far gear or a W mirror.
The diagnostic `NW-eight-source-body-only-QA.png` shows the original source
bodies at an explicitly normalized inspection size; it is never a motion input.

NW walk2 ground contact does not require a correction. The source RIGHT trailing
toe's alpha>100 bounding box ends at Y1126 exclusive, exactly the existing Y1126
source anchor. The LEFT leading foot is higher and farther away. The root
reviewer directly inspected the exact 580x600 registered tile and confirmed the
contact. Its prior apparent gap came from a reduced preview. The source anchor
and raw PNG are preserved. Exact source ROI bounds are saved in
`NW-walk2-contact-source-proof.json`; the actual-size tile is
`NW-walk2-exact580x600-contact-QA.png`.

Resume: root inspect `matrix-S-14poses-WIP.png` and before/after exact S walk0
tiles; accept/reject the metadata proposal explicitly. Then run existing mixed
read-only validation and actual Main direction/role/temporal/combat validation.
Retain native86, grounded biped, RIGHT spear / LEFT shield and melee slash .44.
No production import, profile change, completion increase or Android execution
is claimed by this author checkpoint.
