from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import shutil
p=Path(__file__).parent;shutil.copyfile('/workspace/generated_images/exec-6dd6f171-4206-493e-8282-c480f0b0fcab.png',p/'walk4-N-pilot3-gear-support.png')
im=Image.open(p/'walk4-N-pilot3-gear-support.png').convert('RGBA');bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);im=bg.convert('RGB');d=ImageDraw.Draw(im);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',21)
for i in (2,3):
 off=i*384
 d.line((392,off+32,448,off+292),fill='red',width=8);d.line((448,off+32,392,off+292),fill='red',width=8)
 d.line((575,off+100,630,off+235),fill='red',width=7);d.line((630,off+100,575,off+235),fill='red',width=7)
 d.line((658,off+40,628,off+300),fill='#00bb00',width=9);d.polygon([(650,off+60),(669,off+30),(669,off+68)],fill='#00bb00')
 d.ellipse((356,off+106,410,off+246),outline='#00bb00',width=9)
 d.text((700,off+100),'SPEAR HERE',fill='#008800',font=font);d.text((100,off+180),'SHIELD HERE',fill='#008800',font=font)
 d.text((80,off+28),'MOVE GEAR ONLY. DO NOT MIRROR BODY OR LEGS.',fill='red',font=font)
im.save(p/'N-gear-correction-annotation.png')
prompt='''Correct ONLY arm/gear placement on the BOTTOM TWO creatures in reference2. Reference1 is a visual correction annotation: RED crosses mark WRONG existing gear positions, GREEN marks show required corrected positions. DO NOT render any annotations/colors/text in final art. Reference2 is the clean art. Output new transparent1024x1536 four-row whole2D sheet, same four body/leg poses and scale. Preserve firsttwo figures entirely. Preserve lasttwo actual heads, tails, backs, hips, thighs, knees, shins andfeet in their exact screen locations. DO NOT MIRROR any body orleg. Only move spear+graspinghand to SCREENRIGHT and shield+carryingarm to SCREENLEFT on figures3and4.
Allfour are NORTH BACKview away: anatomicalRIGHThand onSCREENRIGHT holds long uprightbronze spear; anatomicalLEFTforearm onSCREENLEFT carries ovalteal/bronze shield. Thus in ALL FOUR figures spear appears onRIGHT side ofimage, shieldonLEFT. Currentlasttwo WRONG spearleft/shieldright must be fixed by reposing their arms, while body andlegposearelocked. NO spearontheleft in final. NO shieldontheright in final. Exacttwoarms, one spear one shield perfigure, no detachedprops or duplicategear. Do notmirror thewholethird/fourth figure asshortcut because that wouldbreaktheircorrectlegphases. Right handSCREENRIGHTgripmustconnecttoanatomicalrightshoulderonthebackRIGHT; leftarmSCREENLEFTshieldmustconnectleftshoulderonthebackLEFT.
Legposes remain row1RIGHTscreenrightfootUPahead/LEFTfootDOWNtrail; row2RIGHTscreenrightlegsolePLANTED/LEFTscreenleftfootAIRBORNE; row3LEFTscreenleftfootUPahead/RIGHTfootDOWNtrail; row4LEFTscreenleftsolePLANTED/RIGHTscreenrightfootAIRBORNE. Four genuine newlyauthored2Dsourcefaithfulposes, no3D. Keepsourcebluepalette, originalcostume/straps/waistcloth/crest/longtail/feet unchanged. Allvisiblepartsinsideeachrow, generousalphazeroverticalgaps, no floor/shadow/halo/fog/text/lines/annotations. Completewholefiguresnotlimbcutouts. Do NOTintroduce any frontface.'''
(p/'prompt-walk4-N-pilot4-gear-only-annotation.txt').write_text(prompt)
