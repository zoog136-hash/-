from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).parent;out=p.parent/'iguana-source-wip-portable';out.mkdir(exist_ok=True);selected={Path(s['output_path']).resolve() for s in json.loads((p/'mixed112-trial03/candidate112-trial03-HOLD.json').read_text())['sheets']+json.loads((p/'mixed112-trial03/candidate112-trial03-HOLD.json').read_text())['pose_files']}
files=[]
for f in p.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(p)
 if any(x in ['.godot','__pycache__','project'] for x in rel.parts):continue
 if f.suffix.lower() not in ['.png','.json','.txt','.py','.log','.md']:continue
 if f.suffix=='.png':
  if f.resolve() in selected:pass
  elif any(x in str(rel) for x in ['qa/','mixed112-wip/','mixed112-trial02/','source-core-grids/']):continue
  elif any(x in f.name for x in ['-white','-black','-QA','-normalized','contact','matrix-','fourphase-WIP']):continue
 files.append(f)
files.sort(key=lambda x:(x.resolve() not in selected,str(x.relative_to(p))))
parts=[];group=[];size=0
for f in files:
 if group and size+f.stat().st_size>75_000_000:parts.append(group);group=[];size=0
 group.append(f);size+=f.stat().st_size
if group:parts.append(group)
report=[]
for i,group in enumerate(parts,1):
 dst=out/f'iguana112-source-WIP03-part{i:02d}.zip'
 with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for f in group:z.write(f,'albino-iguana-authoring/'+str(f.relative_to(p)))
 with zipfile.ZipFile(dst) as z:assert z.testzip() is None
 report.append({'file':str(dst),'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'entries':len(group),'uncompressed':sum(f.stat().st_size for f in group)})
idx={'status':'HOLD_SOURCE_WIP_ONLY_NO_MAIN_NO_COMPLETION','scope':'Raw selected31PNG and unselected prior/generated failure history, exactprompts, validators/scripts, sourceproof, fullSHA metadata, eight trial03registered matrices/strips, all rawbytes immutable. Diagnostic white/black duplicate composites and large cache/source duplicates omitted.','restore':'Unzip each part beneath /workspace/scratch/pr100-continuation (all entries relative albino-iguana-authoring/). Read RECOVERY_CURRENT.json; no production import without independent review and Main.','candidate':'albino-iguana-authoring/mixed112-trial03/candidate112-trial03-HOLD.json','selected31_preserved':all(any(f.resolve()==s for f in files) for s in selected),'source_count':31,'source_poses':112,'completed_added':0,'parts':report,'inventory':[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]}
(out/'index.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'parts':report,'selected31':idx['selected31_preserved'],'files':len(files)},indent=2))
