from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).parent
im=Image.new('RGB',(512,1536),'white');d=ImageDraw.Draw(im)
pose=[{'name':'N anticipation: high neck, forehooves braced','head':[256,110],'neck':[[256,155],[256,218]],'hind':[[[230,285],[225,345],[220,420]],[[280,285],[288,345],[292,420]]],'fore':[[[235,230],[228,287],[227,350]],[[275,230],[286,290],[285,350]]],'horn':[[256,88],[256,35]],'rump':[210,245,302,330]}, {'name':'N low thrust AWAY: head/neck down behind rump','head':[256,185],'neck':[[256,205],[256,252]],'hind':[[[230,290],[212,355],[200,430]],[[282,290],[300,355],[312,430]]],'fore':[[[235,250],[226,285],[212,320]],[[275,250],[292,286],[295,300]]],'horn':[[256,168],[256,105]],'rump':[205,250,307,340]}, {'name':'N recovery: neck rises, lifted foreknee settles','head':[256,125],'neck':[[256,168],[256,220]],'hind':[[[230,290],[225,350],[223,425]],[[280,290],[288,350],[292,425]]],'fore':[[[235,230],[228,285],[230,350]],[[275,230],[292,275],[300,300]]],'horn':[[256,102],[256,45]],'rump':[210,250,302,335]}]
for i,p in enumerate(pose):
 o=i*512;d.text((12,o+10),p['name'],fill='black');d.line((100,o+435,412,o+435),fill=(175,185,185),width=2)
 d.ellipse((p['head'][0]-20,o+p['head'][1]-28,p['head'][0]+20,o+p['head'][1]+28),fill=(225,232,236),outline=(90,110,125),width=3)
 d.line([(x,y+o) for x,y in p['neck']],fill=(130,155,170),width=26)
 d.ellipse((218,o+205,294,o+300),outline=(100,125,140),width=4)
 for limb,group,col in [('fore',p['fore'],(15,157,207)),('hind',p['hind'],(218,81,128))]:
  for points in group:
   points=[(x,y+o) for x,y in points];d.line(points,fill=col,width=8)
   for x,y in points:d.ellipse((x-6,y-6,x+6,y+6),fill=col)
   x,y=points[-1];d.rectangle((x-11,y-3,x+11,y+5),fill=col)
 x1,y1,x2,y2=p['rump'];d.ellipse((x1,o+y1,x2,o+y2),fill=(235,226,222),outline=(130,115,105),width=4)
 d.line([(256,o+y1+20),(244,o+y2+20),(170,o+390)],fill=(205,188,152),width=14)
 d.line([(x,y+o) for x,y in p['horn']],fill=(183,133,28),width=8)
 d.polygon([(p['head'][0]-17,o+p['head'][1]-20),(p['head'][0]-15,o+p['head'][1]-47),(p['head'][0]-6,o+p['head'][1]-23)],fill=(170,150,145));d.polygon([(p['head'][0]+17,o+p['head'][1]-20),(p['head'][0]+15,o+p['head'][1]-47),(p['head'][0]+6,o+p['head'][1]-23)],fill=(170,150,145))
im.save(R/'desired-N-attack-physical-guide.png');(R/'desired-N-attack-physical-guide.json').write_text(json.dumps({'purpose':'ABSTRACT anatomical/heading diagram only; not sprite/donorbody','poses':pose},indent=2)+'\n')
