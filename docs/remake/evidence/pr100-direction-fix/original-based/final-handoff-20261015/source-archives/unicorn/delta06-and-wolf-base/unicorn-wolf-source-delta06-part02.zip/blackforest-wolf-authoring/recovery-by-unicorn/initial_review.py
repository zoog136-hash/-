from pathlib import Path
import json,hashlib,sys,datetime
from PIL import Image,ImageDraw
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
R=Path(__file__).parent;B=R.parent;c=json.load(open(B/'candidate-wip.json'));oldreview=json.load(open(B/'author-review-wip.json'));pins={x['path']:x['sha256']for x in oldreview['selected_source_validations']};raw=set();visible=set();entries=[];sources=[]
for s in c['sheets']:
 p=Path(s['output_path']);assert m.sha(p)==pins[str(p)];g=m.analyze(p,s['rows'],s['reference_rows'],None,s['directions_axis'],s['canvas_size'],directions=s['directions']);m.require_complete_pose_regions(p,g);a=np.asarray(Image.open(p).convert('RGBA'))
 for f in g['frames']:
  role=next(role for role,rows in s['roles'].items()if f['row']in rows);phase=s['roles'][role].index(f['row']);x,y,w,h=f['region'];vf=m._visible_pose_fingerprint(a[y:y+h,x:x+w]);assert vf not in visible and f['rgba_sha256']not in raw;visible.add(vf);raw.add(f['rgba_sha256']);entries.append({'source':str(p),'role':role,'phase':phase,'direction':f['direction'],'frame':f,'canvas':s['canvas_size']})
 sources.append({'path':str(p),'sha256':m.sha(p),'poses':len(g['frames']),'strict':'PASS'})
for group in[['E','SE','S','SW'],['W','NW','N','NE']]:
 out=Image.new('RGB',(3*640,4*400),(242,244,245));d=ImageDraw.Draw(out)
 for row,direction in enumerate(group):
  for phase in range(3):
   e=next(e for e in entries if e['role']=='walk'and e['direction']==direction and e['phase']==phase);f=e['frame'];im=Image.open(e['source']).convert('RGBA');x,y,w,h=f['region'];ax,ay=f['source_anchor'];z=1.8;q=Image.new('RGBA',(640,365),'white');left=round(320+(x-ax)*z);top=round(290+(y-ay)*z);q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z)),Image.Resampling.LANCZOS),(left,top));qd=ImageDraw.Draw(q);qd.line((0,290,639,290),fill=(172,189,178));out.paste(q.convert('RGB'),(phase*640,row*400+30));d.text((phase*640+8,row*400+8),f'OLD HOLD {direction} walk{phase} constant raw scale1.8; no source pixel rewrite',fill='black')
 out.save(R/f'old-walk-raw-contact-{group[0]}-{group[-1]}.png')
plan=json.load(open('/workspace/twilight/data/animation_authoring_sources.json'));target=next(x for x in plan['targets']if x['key']=='monster:검은숲 늑대');ref=Path('/workspace/twilight')/target['reference']['path'].removeprefix('res://');assert m.sha(ref)==target['reference']['sha256'];assert target['presentation_to_preserve']['visual_height']==78
j={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'key':target['key'],'native_height':78,'original_source_sha256':m.sha(ref),'prior_candidate_sha256':m.sha(B/'candidate-wip.json'),'old_selected_sources':sources,'old_global_raw_unique':len(raw),'old_global_visible_unique':len(visible),'source_geometry':'PASS104','visual_review':'HOLD_WALK24_EXPLICIT_FORE_HIND_REVERSAL_REVIEW_AND_SCALE_ROOTS_PENDING','source_appearance':'Stocky four-legged graybrown/charcoal wolf, pale face and inner legs, yellow eyes, brushy tail; no armor/weapon, grounded melee slash0.44. Original own source only; not Unicorn/Hell frames or recolor.','existing_source_edits':False,'production_edits':False,'Main':'not_run','completed_added':0,'entries':entries}
(R/'initial-independent-QA.json').write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');(R/'checkpoint.json').write_text(json.dumps({k:v for k,v in j.items()if k!='entries'},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'key':target['key'],'source_geometry':j['source_geometry'],'raw_unique':len(raw),'visible_unique':len(visible)}))
