from pathlib import Path
import sys,json
from PIL import Image,ImageDraw
R=Path(__file__).parent;dr=sys.argv[1];stems=sys.argv[2:];es=json.load(open(R/'registration-proposal05/source_registration_proposal.json'))['entries'];p=next(e for e in es if e['direction']==dr and e['role']=='idle'and e['phase']==0);part=[dict(p,label='idle original')]
for stem in stems:
 j=json.load(open(R/(stem+'.diagnostic.json')));f=j['geometry']['frames'][0];part.append({'path':j['path'],'canvas':2048,'anchor':f['source_anchor'],'frame':f,'label':stem})
out=Image.new('RGB',(640*len(part),680),'white');d=ImageDraw.Draw(out)
for k,e in enumerate(part):
 im=Image.open(e['path']).convert('RGBA');x,y,w,h=e['frame']['region'];C=e['canvas'];ax,ay=e['anchor'];z=640/C;q=Image.new('RGBA',(640,640),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z))), (round(320+(x-ax)*z),round(400+(y-ay)*z)));dd=ImageDraw.Draw(q);dd.line((0,400,639,400),fill='green');out.paste(q.convert('RGB'),(k*640,35));d.text((k*640+8,8),f'{dr} {e["label"]} C{C} root{e["anchor"]}',fill='black')
path=R/'registration-proposal06'/f'{dr}-frontal-latest-pilot-comparison.png';out.save(path);print(path)
