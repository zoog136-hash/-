from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).parent
# A compact new equine articulated guide seen from front-right/left, not a transformed donor sprite.
# Each visible chain originates at its own shoulder/pelvis; contactB reverses near fore AND near hind reach.
base={
'A':{'near_fore':[(585,370),(625,500),(685,650),(740,780)],'far_fore':[(650,340),(630,460),(570,560),(585,650)],'near_hind':[(365,340),(330,455),(255,600),(230,745)],'far_hind':[(435,310),(415,440),(465,585),(530,740)]},
'passing':{'near_fore':[(585,370),(585,510),(585,650),(585,790)],'far_fore':[(650,340),(690,445),(740,535),(710,615)],'near_hind':[(365,340),(400,465),(365,600),(365,770)],'far_hind':[(435,310),(445,430),(480,530),(435,615)]},
'B':{'near_fore':[(585,370),(565,490),(490,585),(485,660)],'far_fore':[(650,340),(690,465),(740,610),(790,750)],'near_hind':[(365,340),(410,460),(470,615),(530,795)],'far_hind':[(435,310),(390,430),(320,560),(295,710)]}}
for direction in ['SE','SW']:
 for phase,limbs in base.items():
  pts={k:[(1024-x,y) if direction=='SW' else(x,y) for x,y in v]for k,v in limbs.items()}
  im=Image.new('RGB',(1024,1024),'white');d=ImageDraw.Draw(im)
  d.text((20,20),f'OWN ABSTRACT EQUINE {direction} {phase} — TOPOLOGY ONLY, NOT SPRITE ART',fill='black')
  torso=[(330,210),(525,230),(700,360),(495,415)]
  if direction=='SW':torso=[(1024-x,y)for x,y in torso]
  d.polygon(torso,outline='#999999',width=8)
  head=[(610,280),(620,150),(710,180),(755,255)]
  if direction=='SW':head=[(1024-x,y)for x,y in head]
  d.line(head,fill='#999999',width=8)
  for name,line in pts.items():
   color='#bb2082'if name.startswith('near')else'#078ebc';d.line(line,fill=color,width=18)
   for x,y in line:d.ellipse((x-10,y-10,x+10,y+10),fill=color,outline='white',width=2)
   x,y=line[-1];d.ellipse((x-22,y-12,x+22,y+12),fill=color)
  d.text((25,870),'PINK = nearest visible shoulder + haunch / BLUE = far side.',fill='black')
  d.text((25,900),'A near FORE forward/down + near HIND back. B near FORE back/lift + near HIND forward/down.',fill='black')
  d.text((25,930),'Passing nearest fore hoof under shoulder, other fore lifted forward. Four horse legs joined.',fill='black')
  im.save(R/f'desired-{direction}-{phase}-equine-joint-guide.png');(R/f'desired-{direction}-{phase}-equine-joint-guide.json').write_text(json.dumps({'kind':'own abstract equine skeleton no donor sprite pixels','direction':direction,'phase':phase,'limbs':pts},indent=2)+'\n')
  movement='diagonally DOWN-RIGHT toward viewer, horse muzzle points lower-right, see front chest and RIGHT-facing side'if direction=='SE'else'diagonally DOWN-LEFT toward viewer, horse muzzle points lower-left, see front chest and LEFT-facing side'
  anatomy={'A':'Closest foreleg reaches FORWARD toward viewer and toward muzzle, planted. Closest hindleg trails BACK away from viewer. Far foreleg bends back/lifted. Far hindleg reaches forward under belly.','B':'EXACT OPPOSITE leg ordering: CLOSEST FORELEG folds BACK, clearly lifted hoof behind closest shoulder, not stretched forward. CLOSEST HINDLEG reaches FORWARD toward viewer beneath belly, planted. FAR FORELEG stretches forward toward muzzle, planted. FAR HINDLEG trails back. Trace each closest chain from shoulder/pelvis, not just hoof positions.','passing':'The CLOSEST FORELEG supports VERTICALLY directly UNDER its own shoulder, hoof planted. Closest hind leg supports under rump. FAR FORELEG swings FORWARD toward muzzle with bent knee and raised hoof. Far hind leg flexes and lifts clear. This is visibly between A and B, not a copy of a contact endpoint.'}[phase]
  p=f'''Make exactly ONE whole white ivory unicorn horse for 2D fantasy game animation, facing {direction}: {movement}. FIRST reference is an original abstract equine skeleton; use ONLY its limb chains and near/far ordering, not its outlines/colors/text. SECOND reference is this exact character original appearance. THIRD reference is this same newly authored unicorn for painterly coat, cream mane/tail, skull and chest/haunch proportions ONLY, not its old leg positions. Draw NEW {phase} walking phase. {anatomy} Correct real horse hocks/knees, four hooves on four fully attached legs, two real support feet grounded on one perspective plane. Keep proper horse anatomy, never bipedal/rearing/bounding. SAME individual: white ivory muscular equine, flowing cream mane and large cream tail, exactly one slender spiraled golden horn, red eyes, pale pink muzzle, gold-brown hooves, white fetlock hair. No armor, wings, tack, weapons, extra horns or magical effects. Keep full horse/single complete connected body, full uncropped horn/tail/four hooves with spacious transparent margins. Exactly ONE figure on transparent alpha zero, no shadow, floor, glow, fog, text, diagram/colored marks. Same slight elevated 2D game perspective as supplied character; direction {direction} fixed across the pose.'''
  (R/f'{direction}-{phase}-single-attempt1.prompt.txt').write_text(p+'\n')
