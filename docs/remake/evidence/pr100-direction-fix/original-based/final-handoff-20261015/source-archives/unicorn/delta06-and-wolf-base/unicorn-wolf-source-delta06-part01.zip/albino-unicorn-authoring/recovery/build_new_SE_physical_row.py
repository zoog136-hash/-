from pathlib import Path
import json
from PIL import Image,ImageDraw
R=Path(__file__).parent;D=R/'registration-proposal06';es=json.load(open(R/'registration-proposal05/source_registration_proposal.json'))['entries'];idle=next(e for e in es if e['direction']=='SE'and e['role']=='idle'and e['phase']==0)
stems=['SE-A-frontal-proportion-attempt3','SE-passing-frontal-proportion-attempt3','SE-B-frontal-proportion-attempt4'];paths=[]
chains=[{'near_fore':[[730,700],[790,900],[885,1190]],'near_hind':[[500,625],[430,850],[405,1135]],'far_fore':[[925,740],[1000,850],[945,1025]],'far_hind':[[650,710],[620,900],[720,1140]]},{'near_fore':[[755,745],[790,970],[818,1225]],'near_hind':[[530,650],[555,860],[595,1118]],'far_fore':[[940,760],[1020,850],[960,1040]],'far_hind':[[650,720],[660,960],[720,1170]]},{'near_fore':[[730,670],[820,870],[740,960]],'near_hind':[[515,620],[560,880],[660,1180]],'far_fore':[[930,725],[980,920],[1020,1195]],'far_hind':[[645,695],[470,835],[310,1120]]}]
part=[dict(idle,label='SE idle original C928')]
for k,s in enumerate(stems):
 j=json.load(open(R/(s+'.diagnostic.json')));f=j['geometry']['frames'][0];e={'path':j['path'],'canvas':2048,'anchor':[740,f['source_anchor'][1]],'frame':f,'label':s,'raw_sha256':j['raw_sha256'],'whole_limbs_approximate_manual_landmarks':chains[k]};part.append(e)
colors={'near_fore':'#d12577','near_hind':'#e68018','far_fore':'#2183b9','far_hind':'#1e8a57'};size=640;out=Image.new('RGB',(size*4,1360),'white');od=ImageDraw.Draw(out)
for k,e in enumerate(part):
 for row in [0,1]:
  im=Image.open(e['path']).convert('RGBA');x,y,w,h=e['frame']['region'];C=e['canvas'];ax,ay=e['anchor'];z=size/C;q=Image.new('RGBA',(size,size),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z))), (round(320+(x-ax)*z),round(400+(y-ay)*z)));d=ImageDraw.Draw(q);d.line((0,400,639,400),fill='#90b59e');d.ellipse((317,397,323,403),outline='red',width=2)
  if row and k:
   for name,pts in e['whole_limbs_approximate_manual_landmarks'].items():
    pp=[(round(320+(xx-ax)*z),round(400+(yy-ay)*z))for xx,yy in pts];d.line(pp,fill=colors[name],width=4)
    for xx,yy in pp:d.ellipse((xx-4,yy-4,xx+4,yy+4),fill=colors[name])
  out.paste(q.convert('RGB'),(k*size,row*680+35));od.text((k*size+8,row*680+8),e['label']+(' physical chain review'if row else''),fill='black')
out.save(D/'SE-new-A3-passing3-B4-idle-clean-and-joint-review.png');(D/'SE-new-A3-passing3-B4-registration-and-joints.json').write_text(json.dumps({'status':'SOURCE_PHYSICAL_ROOT_REVIEW_PENDING_NO_MAIN','review_flags':False,'completed_added':0,'note':'Approximate manual joints identify whole limb trajectories; not an automated physical quality acceptance. X740 proposed projected-spine root replaces tail bbox center; loaded sole source Y retained.','entries':part},ensure_ascii=False,indent=2)+'\n');print(str(out.size))
