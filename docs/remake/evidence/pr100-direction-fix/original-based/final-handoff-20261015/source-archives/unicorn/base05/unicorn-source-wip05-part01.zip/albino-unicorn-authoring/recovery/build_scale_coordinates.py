from pathlib import Path
import json
from PIL import Image,ImageDraw
R=Path(__file__).parent;B=R.parent
c=json.load(open(R/'candidate-recovery-wip.json'))
for stem,ds,role in [('walk-W-B-propagation-attempt4',['W'],'walk'),('attack-NE-spacing-attempt2',['NE'],'attack')]:
 j=json.load(open(R/(stem+'.diagnostic.json')));c['sheets'].append({'output_path':str(R/(stem+'.png')),'rows':3,'reference_rows':[0,1,2],'directions_axis':'columns','directions':ds,'canvas_size':1024,'roles':{role:[0,1,2]},'raw_sha256':j['raw_sha256'],'exact_prompt_path':str(R/(stem+'.prompt.txt'))})
c['status']='RECOVERY_ALL104_GEOMETRY_PASS_SCALE_ANCHORS_ROOT_QA_PENDING';(R/'candidate-recovery-all104-wip.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
for role in ['idle','walk','attack','hit','death']:
 ss=[(i,s)for i,s in enumerate(c['sheets'])if role in s['roles']]
 panel=Image.new('RGB',(len(ss)*620,790),'white');d=ImageDraw.Draw(panel)
 for col,(i,s) in enumerate(ss):
  j=json.load(open(Path(s['output_path']).with_suffix('.diagnostic.json')));g=j['geometry'];f=g['frames'][0];im=Image.open(s['output_path']).convert('RGBA');x,y,w,h=f['region'];q=Image.new('RGBA',(w,h),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)));z=min(1.15,570/w,640/h);ox=col*620+30;oy=60;panel.paste(q.resize((round(w*z),round(h*z))).convert('RGB'),(ox,oy));d.text((col*620+5,5),f'sheet{i}: {Path(s["output_path"]).stem}',fill='black');d.text((col*620+5,22),f'{f["direction"]} row0 source x{x} y{y} w{w} h{h} z{z:.3f}',fill='black')
  for xx in range(((x+39)//40)*40,x+w,40):
   ax=ox+(xx-x)*z;d.line((ax,oy,ax,oy+h*z),fill=(203,211,217));d.text((ax,oy-15),str(xx),fill='black')
  for yy in range(((y+39)//40)*40,y+h,40):
   ay=oy+(yy-y)*z;d.line((ox,ay,ox+w*z,ay),fill=(203,211,217));d.text((ox-26,ay),str(yy),fill='black')
 panel.save(R/f'scale-{role}-source-coordinates.png')
im=Image.open(B/'source-wholebody-context.png').convert('RGBA');q=Image.new('RGBA',im.size,'white');q.alpha_composite(im);q=q.resize((im.width*3,im.height*3));d=ImageDraw.Draw(q)
for x in range(0,im.width,20):d.line((x*3,0,x*3,q.height),fill=(203,211,217));d.text((x*3,0),str(x),fill='black')
for y in range(0,im.height,20):d.line((0,y*3,q.width,y*3),fill=(203,211,217));d.text((0,y*3),str(y),fill='black')
q.convert('RGB').save(R/'scale-exactsource-wholebody-coordinates.png')
print('Saved all104 unreviewed fit1024 WIP and source coordinate panels')
