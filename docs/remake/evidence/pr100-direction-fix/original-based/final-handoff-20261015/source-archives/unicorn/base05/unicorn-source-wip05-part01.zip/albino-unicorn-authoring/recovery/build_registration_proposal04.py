from pathlib import Path
import json,copy,datetime
from PIL import Image,ImageDraw
R=Path(__file__).parent;c=json.load(open(R/'candidate-mixed104-registration-trial03.json'));pr=json.load(open(R/'registered104-trial03-proof.json'));es=copy.deepcopy(pr['entries']);D=R/'registration-proposal04';D.mkdir(exist_ok=True)
for e in es:
 if e['direction']=='N':e['anchor'][0]={'idle':380,'walk':758,'attack':444,'hit':395,'death':315}[e['role']]
 if e['role']=='walk'and e['direction']in['S','N']:e['canvas']={'S':824,'N':784}[e['direction']]
 # This is a scratch review plan only. The optional importer field is not chosen/implemented by this script.
 x,y,w,h=e['frame']['region'];C=e['canvas'];ax,ay=e['anchor'];margin=[round(C/2)+x-ax,round(C*.625)+y-ay,C-w,C-h]
 assert margin[0]>=0 and margin[1]>=0 and margin[0]+w<=C and margin[1]+h<=C,(e['direction'],e['role'],e['phase'],margin,w,h,C)
 e['proposed_margin']=margin

def tile(e,C=None,size=640):
 C=C or e['canvas'];im=Image.open(e['path']).convert('RGBA');x,y,w,h=e['frame']['region'];z=size/C;ax,ay=e['anchor'];left=round(size/2+(x-ax)*z);top=round(size*.625+(y-ay)*z);q=Image.new('RGBA',(size,size),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z)),Image.Resampling.LANCZOS),(left,top));d=ImageDraw.Draw(q);gy=round(size*.625);d.line((0,gy,size-1,gy),fill=(160,182,167));d.ellipse((size//2-3,gy-3,size//2+3,gy+3),outline='#c52569',width=2);return q.convert('RGB')
roles=['idle','walk','attack','hit','death'];size=640
for direction in ['E','SE','S','SW','W','NW','N','NE']:
 part=sorted([e for e in es if e['direction']==direction],key=lambda e:(roles.index(e['role']),e['phase']));panel=Image.new('RGB',(size*5,(size+40)*3),(238,241,243));d=ImageDraw.Draw(panel)
 for i,e in enumerate(part):
  col=i%5;row=i//5;panel.paste(tile(e),(col*size,row*(size+40)+35));d.text((col*size+8,row*(size+40)+8),f'{direction} {e["role"]}{e["phase"]} C{e["canvas"]} root{e["anchor"]}',fill='black')
 panel.save(D/f'matrix-{direction}-13poses.png')
 strip=Image.new('RGB',(size*4,size+40),'white');sd=ImageDraw.Draw(strip)
 for col,i in enumerate([0,2,3,4]):
  e=part[i];strip.paste(tile(e),(col*size,35));sd.text((col*size+8,8),f'{direction} {e["role"]}{e["phase"]} C{e["canvas"]}',fill='black')
 strip.save(D/f'walk-{direction}-idle-A-pass-B.png')
part=sorted([e for e in es if e['direction']=='N'],key=lambda e:(roles.index(e['role']),e['phase']));small=512;out=Image.new('RGB',(small*4,(small+40)*3),'white');d=ImageDraw.Draw(out)
for row,C in enumerate([736,784,824]):
 for col,i in enumerate([0,2,3,4]):
  e=part[i];canvas=e['canvas']if col==0 else C;out.paste(tile(e,canvas,small),(col*small,row*(small+40)+35));d.text((col*small+8,row*(small+40)+8),f'N {e["role"]}{e["phase"]} C{canvas} / head-neck & visible haunch',fill='black')
out.save(D/'N-walk-canvas736-784-824-homologous-comparison.png')
proposal={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ROOT_REVIEW_PENDING_NO_PARSER_OR_PRODUCTION_WRITES','base_candidate':str(R/'candidate-mixed104-registration-trial03.json'),'whole_source_registration_proposal':[{'file':str(R/'walk-S-N-threephase-attempt1.png'),'canvas_by_direction_proposed':{'S':824,'N':784},'N_alternative_canvases':[736,824],'notes':'S114/129 raw pectoral and matching visible skull width suggest824 vs idle928. N128/161 white-haunch estimate partly tail-occluded;736 over-enlarges ears/neck. Present736/784/824 honest alternatives rather than claiming an approved full-rump measurement.'}],'N_sagittal_source_roots':{'idle':380,'walk':758,'attack':444,'hit':395,'death':315},'count':len(es),'global_visible_unique':pr['global_visible_unique'],'every_selected_source_body_used_once':True,'source_pngs_changed':False,'entries':es,'Main':'not_run','completed_added':0}
(D/'source_registration_proposal.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n');print(str(D))
