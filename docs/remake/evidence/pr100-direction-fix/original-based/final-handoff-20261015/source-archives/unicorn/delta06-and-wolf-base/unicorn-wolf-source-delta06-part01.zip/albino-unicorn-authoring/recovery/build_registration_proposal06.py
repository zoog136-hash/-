from pathlib import Path
import json,copy,datetime,hashlib
from PIL import Image,ImageDraw
R=Path(__file__).parent;D=R/'registration-proposal06';c=json.load(open(R/'candidate-mixed104-registration-proposal05.json'));base=json.load(open(R/'registration-proposal05/source_registration_proposal.json'));es=copy.deepcopy(base['entries']);replacements={}
for dr,name in [('SE','SE-new-A3-passing3-B4'),('SW','SW-new-A1-passing4-B2')]:
 row=json.load(open(D/(name+'-registration-and-joints.json')))
 for phase,e in enumerate(row['entries'][1:]):replacements[(dr,phase)]=e
for e in es:
 if e['role']=='walk'and(e['direction'],e['phase'])in replacements:
  q=replacements[(e['direction'],e['phase'])];e.update(path=q['path'],canvas=q['canvas'],anchor=q['anchor'],frame=q['frame'])
 x,y,w,h=e['frame']['region'];C=e['canvas'];ax,ay=e['anchor'];mar=[round(C/2)+x-ax,round(C*.625)+y-ay,C-w,C-h];assert min(mar)>=0 and mar[0]+w<=C and mar[1]+h<=C;e['proposed_margin']=mar
for p in c['pose_files']:
 if(p['direction'],p['phase'])in replacements:
  e=replacements[(p['direction'],p['phase'])];p.update(output_path=e['path'],source_sha256=e['raw_sha256'],canvas_size=e['canvas'],source_anchor=e['anchor'],scale_review_note='HOLD source06 frontal-three-quarter whole newly authored art with compact original neck/core; physical fore+hindreversal and passing source row pending root approval. Source X registered to projected core rather than tail bbox; sourceY follows actual support sole. Every selected whole PNG body used once, no cropping/assembly/resampling. Homologous head/chest/core registration, no max-silhouette fitting. Actual Main not run.')
c['prompt']='New reference-based authored unicorn animation, every exact source prompt retained beside immutable whole source PNG. Mixed whole sheets plus whole individual W/SE/SW walk poses, no production cropping/assembly/resampling. Source06 replaces all six rejected lateral-projection SE/SW walk single PNGs with newly drawn frontal-three-quarter compact-neck whole art; all other05 source/registration preserved.';c['review']['notes']='HOLD intentionally blocks import. Parent accepted other source directions for Main trial; new SE/SW whole A/passing/B need independent physical/source scale/root approval. Source-only06 metadata and diagnostics, not actual Main or visual quality pass. All flags false, completed_added0.';c['status']='SOURCE_ONLY_HOLD_PROPOSAL06_PHYSICAL_REVIEW_PENDING';c['actual_Main']='not_run';c['completed_added']=0
(R/'candidate-mixed104-registration-proposal06.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
def tile(e):
 im=Image.open(e['path']).convert('RGBA');x,y,w,h=e['frame']['region'];C=e['canvas'];ax,ay=e['anchor'];z=640/C;q=Image.new('RGBA',(640,640),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z))), (round(320+(x-ax)*z),round(400+(y-ay)*z)));d=ImageDraw.Draw(q);d.line((0,400,639,400),fill='#90b59e');d.ellipse((317,397,323,403),outline='red',width=2);return q.convert('RGB')
roles=['idle','walk','attack','hit','death']
for dr in ['SE','SW']:
 part=sorted([e for e in es if e['direction']==dr],key=lambda e:(roles.index(e['role']),e['phase']));out=Image.new('RGB',(3200,2040),(238,241,243));d=ImageDraw.Draw(out)
 for k,e in enumerate(part):
  col=k%5;row=k//5;out.paste(tile(e),(col*640,row*680+35));d.text((col*640+8,row*680+8),f'{dr} {e["role"]}{e["phase"]} C{e["canvas"]} root{e["anchor"]}',fill='black')
 out.save(D/f'matrix-{dr}-13poses.png')
prop={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOURCE_ONLY_HOLD_ALL_REVIEW_FLAGS_FALSE','base05_candidate_sha256':hashlib.sha256((R/'candidate-mixed104-registration-proposal05.json').read_bytes()).hexdigest(),'count':104,'entries':es,'source_pngs_changed':False,'other_six_direction_matrices':'Byte-identical source/registration to registration-proposal05; no redraw necessary.','Main':'not_run','completed_added':0};(D/'source_registration_proposal.json').write_text(json.dumps(prop,ensure_ascii=False,indent=2)+'\n');print(str(R/'candidate-mixed104-registration-proposal06.json'))
