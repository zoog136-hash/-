from pathlib import Path
import json
from PIL import Image,ImageDraw
import numpy as np
R=Path(__file__).parent;D=R/'registration-proposal06';D.mkdir(exist_ok=True)
es=json.load(open(R/'registration-proposal05/source_registration_proposal.json'))['entries'];report=[]
for direction in ['SE','SW']:
 part=[e for e in es if e['direction']==direction and e['role']in['idle','walk']]
 panel=Image.new('RGB',(1200,1600),'white');draw=ImageDraw.Draw(panel)
 for k,e in enumerate([part[0],part[2],part[3],part[4]]):
  im=Image.open(e['path']).convert('RGBA');a=np.asarray(im);x,y,w,h=e['frame']['region'];ax,ay=e['anchor'];nz=np.argwhere(a[y:y+h,x:x+w,3]>200);strong_bottom=int(nz[:,0].max()+y);lower=a[:,:,3].copy();lower[:int(y+h*.8)]=0;footys=np.where((lower>200).sum(1)>=8)[0];sole=int(footys[-1]);report.append({'direction':direction,'role':e['role'],'phase':e['phase'],'anchor':e['anchor'],'canvas':e['canvas'],'strong_alpha_bottom':strong_bottom,'substantial_alpha_bottom':sole,'strong_bottom_display_y':400+(strong_bottom-ay)*640/e['canvas'],'baseline_y':400})
  q=Image.new('RGBA',im.size,'white');q.alpha_composite(im);q=q.convert('RGB');d=ImageDraw.Draw(q)
  step=50 if e['role']=='idle' else 100
  for xx in range(0,im.width,step):
   d.line((xx,0,xx,im.height),fill=(180,210,245),width=1);d.text((xx+2,max(0,y)),str(xx),fill='blue')
  for yy in range(0,im.height,step):
   d.line((0,yy,im.width,yy),fill=(180,210,245),width=1);d.text((max(0,x),yy+2),str(yy),fill='blue')
  d.line((0,ay,im.width,ay),fill='red',width=3)
  crop=q.crop((max(0,x-10),max(0,y-10),min(im.width,x+w+10),min(im.height,y+h+10)));crop.thumbnail((590,740));col=k%2;row=k//2;panel.paste(crop,(col*600,row*800+40));draw.text((col*600+4,row*800+4),f'{direction} {e["role"]}{e["phase"]} native coordinates; anchor{e["anchor"]}',fill='black')
 panel.save(D/f'{direction}-raw-homologous-coordinate-review.png')
(D/'independent-sole-alpha-and-projection.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
