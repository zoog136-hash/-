from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).parent;D=R/'registration-proposal06';D.mkdir(exist_ok=True)
for direction in ['SE','SW']:
 for phase in ['A','passing','B']:
  im=Image.new('RGB',(1024,1024),'white');d=ImageDraw.Draw(im)
  # Blank anatomical planning diagram only: frontal 3/4 projection, never an imported body or edited sprite.
  d.text((20,15),f'{direction} {phase} -- FRONTAL THREE QUARTER; short projected shoulder-hip axis',fill='black')
  def p(x,y):return (x if direction=='SE' else 1024-x,y)
  shoulder=(550,505);hip=(425,525);head=(620,250)
  d.ellipse((*p(460,430),*p(645,635)),outline='#777777',width=4)if direction=='SE'else d.ellipse((379,430,564,635),outline='#777777',width=4)
  d.line([p(*shoulder),p(*hip)],fill='black',width=7);d.line([p(*shoulder),p(578,345),p(*head)],fill='gray',width=7)
  d.ellipse((p(600,230)[0]-16,214,p(600,230)[0]+16,246),outline='gray',width=3)
  if phase=='A':chains=[('near_fore','#d22674',[(575,550),(611,699),(648,872)]),('near_hind','#e58420',[(420,550),(395,690),(360,815)]),('far_fore','#247ab7',[(525,548),(495,650),(521,746)]),('far_hind','#298b55',[(384,540),(426,673),(460,804)])]
  elif phase=='passing':chains=[('near_fore','#d22674',[(575,550),(582,710),(590,872)]),('near_hind','#e58420',[(420,550),(440,695),(467,802)]),('far_fore','#247ab7',[(525,548),(571,649),(617,749)]),('far_hind','#298b55',[(384,540),(358,693),(340,820)])]
  else:chains=[('near_fore','#d22674',[(575,550),(536,644),(570,737)]),('near_hind','#e58420',[(420,550),(462,698),(500,825)]),('far_fore','#247ab7',[(525,548),(570,704),(620,872)]),('far_hind','#298b55',[(384,540),(351,685),(320,804)])]
  for name,c,pts in chains:
   qs=[p(*q)for q in pts];d.line(qs,fill=c,width=9)
   for x,y in qs:d.ellipse((x-8,y-8,x+8,y+8),fill=c)
   d.text((20,900+22*['near_fore','near_hind','far_fore','far_hind'].index(name)),name,fill=c)
  d.text((20,995),'A/P/B reciprocal whole limbs. Wide frontal chest. Short body axis. Support soles at own depth plane.',fill='black')
  im.save(D/f'front-{direction}-{phase}-blank-gait-guide.png')
  prompt=f'''Create ONE complete whole-body newly authored 2D game animation sprite of this exact white/ivory unicorn. Transparent background. No sheet, no duplicates, no text, no shadows. The FIRST reference is the authoritative existing idle artwork: select the RIGHT column unicorn facing {direction}, preserve its exact front-three-quarter camera yaw, foreshortened compact ribcage, wide visible frontal pectoral chest, equine skull/muzzle proportions, white ivory fur, huge cream mane and tail, single golden horn and red eyes. The second reference is a blank planning diagram only, not artwork: follow its leg phase and frontal short shoulder-to-hip projection. The third reference is exact original game identity. This is newly authored motion, not extracted original frames.\nDirection {direction}: face diagonally toward the viewer and {'right'if direction=='SE'else'left'}, at the SAME near-frontal three-quarter angle as the RIGHT column idle reference. The neck rises almost vertically and the near shoulder obscures much of the body behind it; show a broad frontal chest, a SHORT strongly foreshortened shoulder-to-hip axis. Do NOT turn the torso into a side view or make an elongated horizontal ribcage. Keep the original head and core anatomy; change only the whole articulated gait pose.\nWalking phase {phase}: '''
  if phase=='A':prompt+='Near foreleg reaches forward and DOWN to support on the near ground plane, near hindleg extends back, far foreleg is in an independently bent lifted swing, far hindleg advances. The fore and hind phases must oppose each other with visible hip/knee/hock articulation.'
  elif phase=='passing':prompt+='Near foreleg forms a near-vertical loaded shoulder-to-hoof chain UNDER its shoulder. Near hindleg passes underneath its hip, far foreleg swings forward visibly lifted, far hindleg supports behind. Distinct passing middle, not a copy of either contact endpoint.'
  else:prompt+='REVERSE phase A physically: near foreleg bends BACK and lifts, near hindleg advances FORWARD, far foreleg reaches forward and down to be the loaded support, far hindleg extends back. Preserve whole connected shoulder/hip/knee chains; no detached boots or duplicated limb overlays.'
  prompt+='\nDraw one complete connected horse at roughly 75% canvas height, generous empty transparent margin above horn and around tail and hooves, all source pixels in view. Grounded natural walking, one or two actual support hoof soles; no trotting airborne pose. Crisp painterly 2D fantasy sprite matching the idle reference, no armor/wings/accessories, no recoloring, no photographic backdrop, no reference diagram marks. The original idle frontal camera is mandatory; reject lateral showhorse profile. Keep the compact original physique and genuine four-legged equine walk.'
  (R/f'{direction}-{phase}-frontal-projection-attempt1.prompt.txt').write_text(prompt+'\n')
