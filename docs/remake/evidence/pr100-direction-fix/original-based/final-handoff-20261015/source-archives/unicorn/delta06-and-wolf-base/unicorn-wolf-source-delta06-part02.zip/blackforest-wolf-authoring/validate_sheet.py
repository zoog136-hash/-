import sys,json,hashlib,shutil
from pathlib import Path
import numpy as np
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
p=Path(__file__).parent
original=Path(sys.argv[1]);name=sys.argv[2];rows=int(sys.argv[3]);canvas=int(sys.argv[4]);dirs=sys.argv[5].split(',');f=p/(name+'.png')
if not f.exists():shutil.copyfile(original,f)
assert f.read_bytes()==original.read_bytes()
r={'path':str(f),'tool_original':str(original),'unchanged_byte_copy':True,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
try:
 g=m.analyze(f,rows_count=rows,reference_rows=[0,1] if rows==5 else [0,2],directions_axis='columns',canvas_size=canvas,directions=dirs);m.require_complete_pose_regions(f,g);r.update(strict_status='PASS',count=len(g['frames']),neutral_height=g['neutral_height']);(p/(name+'-geometry.json')).write_text(json.dumps(g,indent=2))
 a=np.array(Image.open(f).convert('RGBA'));mask=np.ones(a.shape[:2],bool)
 for fr in g['frames']:
  x,y,w,h=fr['region'];mask[y:y+h,x:x+w]=False
 z=a[:,:,3][mask];r.update(max_outside_alpha=int(z.max()),outside_alpha_gt25=int((z>25).sum()),outside_alpha_gt100=int((z>100).sum()))
except Exception as e:r.update(strict_status='FAIL',strict_error=str(e))
(p/(name+'-validation.json')).write_text(json.dumps(r,indent=2))
a=Image.open(f).convert('RGBA');bg=Image.new('RGBA',a.size,'#151515');bg.alpha_composite(a);bg.convert('RGB').save(p/(name+'-black.png'))
print(json.dumps(r,indent=2))
