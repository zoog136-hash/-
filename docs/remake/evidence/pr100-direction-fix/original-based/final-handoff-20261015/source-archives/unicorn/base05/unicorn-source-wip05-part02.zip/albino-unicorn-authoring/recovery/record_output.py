from pathlib import Path
import argparse,hashlib,json,shutil,sys
import numpy as np
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as motion
p=argparse.ArgumentParser();p.add_argument('generated');p.add_argument('name');p.add_argument('rows',type=int);p.add_argument('directions');p.add_argument('--canvas',type=int,default=1024);args=p.parse_args()
o=Path(__file__).parent;out=o/(args.name+'.png');gen=Path(args.generated)
if gen.resolve()!=out.resolve():shutil.copyfile(gen,out)
dirs=args.directions.split(',');j={'path':str(out),'generated_original':str(gen),'raw_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'unchanged_from_generated':True,'rows':args.rows,'directions':dirs,'canvas_size_diagnostic':args.canvas,'status':'STRICT_AND_VISUAL_REVIEW_PENDING','Main':'not_run','completed_added':0}
try:
 g=motion.analyze(out,rows_count=args.rows,reference_rows=list(range(args.rows)),directions_axis='columns',canvas_size=args.canvas,directions=dirs);motion.require_complete_pose_regions(out,g);j.update(geometry=g,strict_analyze='PASS',complete_visible='PASS');a=np.asarray(Image.open(out));cover=np.zeros(a.shape[:2],bool);visible=[]
 for f in g['frames']:
  x,y,w,h=f['region'];cover[y:y+h,x:x+w]=True;visible.append(motion._visible_pose_fingerprint(a[y:y+h,x:x+w]))
 z=a[:,:,3][~cover];j.update(outside_alpha_max=int(z.max()),outside_alpha_gt10=int(np.sum(z>10)),outside_alpha_gt100=int(np.sum(z>100)),raw_unique=len({f['rgba_sha256'] for f in g['frames']}),visible_unique=len(set(visible)))
except Exception as e:j.update(strict_analyze='FAIL',error=str(e))
im=Image.open(out).convert('RGBA')
for bg in ['white','black']:
 q=Image.new('RGBA',im.size,bg);q.alpha_composite(im);q.convert('RGB').save(o/(args.name+'.on-'+bg+'.png'))
(o/(args.name+'.diagnostic.json')).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
records=o/'recovery-generation-records.json';rs=json.load(open(records)) if records.exists() else[];rs.append({k:v for k,v in j.items() if k!='geometry'});records.write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in j.items() if k!='geometry'},ensure_ascii=False,indent=2))
