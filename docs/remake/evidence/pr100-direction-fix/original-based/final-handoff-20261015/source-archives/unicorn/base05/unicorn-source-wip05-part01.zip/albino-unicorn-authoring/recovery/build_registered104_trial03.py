from pathlib import Path
import json,sys,datetime
from PIL import Image,ImageDraw
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
R=Path(__file__).parent;c=json.load(open(R/'candidate-mixed104-registration-trial01.json'));c['status']='HOLD_REGISTERED104_METADATA_TRIAL03_NEW_SE_SW_WHOLE_SINGLES';c['review']['notes']='HOLD: all104 source geometry and metadata proposed; fresh SE/SW single A/pass/B joint-reversal pilots require root review, full104 head/chest/haunch and actual sole/corpse roots need independent visual approval before Main.'
entries=[];sheets=[]
walk_scales={'walk-E-threephase-attempt1':928,'walk-S-N-threephase-attempt1':728,'walk-NW-NE-threephase-attempt1':736}
for s in c['sheets']:
 p=Path(s['output_path']);stem=p.stem;role=next(iter(s['roles']))
 if stem=='walk-SE-SW-threephase-attempt1':continue
 canvas=round(s['canvas_size']*29/32/8)*8
 if role=='walk':canvas=walk_scales[stem]
 if role=='hit':canvas=1104 if 'E-SE-' in stem else 1048
 if role=='death'and stem=='death-N-NE-attempt1':canvas=1104
 if role=='death'and stem=='death-S-SW-attempt1':canvas=984
 s['canvas_size']=canvas
 for i,(a,f)in enumerate(zip(s['source_anchors'],json.load(open(p.with_suffix('.diagnostic.json')))['geometry']['frames'])):
  if f['direction']=='N':
   a[0]={'idle':390,'walk':795,'attack':448,'hit':415,'death':315}[role]
  if role=='walk'and f['direction']=='NW':a[0]=255
  if role=='walk'and f['direction']=='NE':a[0]=785
  if role=='idle'and f['direction']=='NE':a[0]=900
 s['scale_review_note']='HOLD trial03 proposed metadata: common virtual units scaled29/32 from trial01, no source resampling and no world-size change under median-idle normalization. Homologous head/chest/haunch comparisons determine role ratios: S/N walk728 + NW/NE walk736 vs idle928; E/SE attack640, W/NW attack816, N attack1104; hit1048/1104. N actual sagittal rump/sole root replaces tail-biased box center. Corpus/death actual-ground roots still independent review pending.'
 g=m.analyze(p,s['rows'],s['reference_rows'],None,s['directions_axis'],canvas,s['source_anchors'],s['directions']);m.require_complete_pose_regions(p,g);sheets.append(s)
 for f in g['frames']:
  role=next(k for k,rs in s['roles'].items()if f['row']in rs);phase=s['roles'][role].index(f['row']);entries.append({'path':str(p),'source_kind':'whole_sheet','role':role,'direction':f['direction'],'phase':phase,'canvas':canvas,'anchor':f['source_anchor'],'frame':f})
c['sheets']=sheets
for s in c['pose_files']:
 s['canvas_size']=round(s['canvas_size']*29/32/8)*8;s['scale_review_note']='Root accepted static W3 pilot geometry and comparative skull/chest/haunch at1952/2048/1952. Common virtual unit rescale29/32 preserves every world ratio; source PNG pixels untouched. Actual Main still unrun.'
for direction,canvas in [('SE',2048),('SW',1856)]:
 for phase,(name,attempt)in enumerate([('A',1),('passing',2),('B',2)]):
  p=R/f'{direction}-{name}-single-attempt{attempt}.png';j=json.load(open(p.with_suffix('.diagnostic.json')));a=j['geometry']['frames'][0]['source_anchor'];c['pose_files'].append({'id':f'walk-{direction}-{phase}','output_path':str(p),'source_sha256':m.sha(p),'role':'walk','direction':direction,'phase':phase,'canvas_size':canvas,'source_anchor':a,'scale_review_note':f'HOLD trial03 newly authored whole PNG {direction} {name}. Same-heading ocular-nostril/pectoral/haunch comparison to idle with virtual{canvas}; raw pixels untouched. Contact A/B actual near fore/hind reversal and passing stance require root independent review. Source anchor follows real lowest planted sole, no tail-relative drift. No source body exclusion.'})
for s in c['pose_files']:
 p=Path(s['output_path']);g=m.analyze(p,1,[0],None,'columns',s['canvas_size'],[s['source_anchor']],[s['direction']]);m.require_complete_pose_regions(p,g);entries.append({'path':str(p),'source_kind':'pose_file','role':s['role'],'direction':s['direction'],'phase':s['phase'],'canvas':s['canvas_size'],'anchor':s['source_anchor'],'frame':g['frames'][0]})
(R/'candidate-mixed104-registration-trial03.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');D=R/'registered104-trial03';D.mkdir(exist_ok=True)
roles=['idle','walk','attack','hit','death'];tile=640;ground=400;proof=[]
for direction in m.DIRECTIONS:
 es=sorted([e for e in entries if e['direction']==direction],key=lambda e:(roles.index(e['role']),e['phase']));panel=Image.new('RGB',(5*tile,3*(tile+40)),(237,241,243));d=ImageDraw.Draw(panel)
 for i,e in enumerate(es):
  im=Image.open(e['path']).convert('RGBA');x,y,w,h=e['frame']['region'];z=tile/e['canvas'];ax,ay=e['anchor'];left=round(tile/2+(x-ax)*z);top=round(ground+(y-ay)*z);q=Image.new('RGBA',(tile,tile),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z)),Image.Resampling.LANCZOS),(left,top));qd=ImageDraw.Draw(q);qd.line((0,ground,tile-1,ground),fill=(160,182,167));qd.ellipse((tile//2-3,ground-3,tile//2+3,ground+3),outline='#cb2364',width=2);col=i%5;row=i//5;panel.paste(q.convert('RGB'),(col*tile,row*(tile+40)+35));d.text((col*tile+8,row*(tile+40)+8),f'{direction} {e["role"]}{e["phase"]} canvas{e["canvas"]} anchor{e["anchor"]}',fill='black');e['diagnostic_bounds']=[left,top,round(w*z),round(h*z)];proof.append(e)
 panel.save(D/f'matrix-{direction}-13poses.png')
 # Also a compact gait strip containing old idle and all three newly registered walk poses.
 strip=Image.new('RGB',(4*tile,tile+40),'white');sd=ImageDraw.Draw(strip)
 for col,i in enumerate([0,2,3,4]):
  row=i//5;ocol=i%5;strip.paste(panel.crop((ocol*tile,row*(tile+40),ocol*tile+tile,row*(tile+40)+tile+40)),(col*tile,0))
 strip.save(D/f'walk-{direction}-idle-A-pass-B.png')
pixels=[]
for e in entries:
 a=np.asarray(Image.open(e['path']).convert('RGBA'));x,y,w,h=e['frame']['region'];pixels.append(m._visible_pose_fingerprint(a[y:y+h,x:x+w]))
logical=sum(Image.open(s['output_path']).width*Image.open(s['output_path']).height*4 for s in c['sheets']+c['pose_files'])
(R/'registered104-trial03-proof.json').write_text(json.dumps({'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':c['status'],'body_count':len(entries),'global_visible_unique':len(set(pixels)),'source_count':len(c['sheets'])+len(c['pose_files']),'logical_RGBA8_bytes':logical,'every_selected_source_body_used_once':True,'old_failed_W_and_SE_SW_sheets_entirely_unselected':True,'source_pngs_modified':False,'display_height_basis':'median_idle','common_virtual_unit_rescale':'29/32 retains all relative registration and runtime native128 under median-idle display normalization; raw bytes untouched','entries':proof,'Main':'not_run','completed_added':0},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidate':str(R/'candidate-mixed104-registration-trial03.json'),'body_count':len(entries),'unique':len(set(pixels)),'sources':len(c['sheets'])+len(c['pose_files']),'logical_RGBA8_MiB':logical/2**20}))
