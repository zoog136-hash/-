from pathlib import Path
import json
from PIL import Image,ImageDraw
O=Path(__file__).parent
for phase,src in [('A','B'),('B','A')]:
 old=json.load(open(O/f'desired-E-contact{src}-equine-joint-guide.json'));limbs={k:[[1024-x,y] for x,y in v] for k,v in old['limbs'].items()};im=Image.new('RGB',(1024,800),'white');d=ImageDraw.Draw(im)
 d.text((50,20),f'OWN ABSTRACT EQUINE TOPOLOGY W / LEFT CONTACT {phase}',fill='black');d.text((50,45),'Kinematics only. No donor sprite. Original source horse proportions/materials govern.',fill='black');d.ellipse((334,175,744,355),outline='#999999',width=8);d.line((359,230,294,145,234,145),fill='#999999',width=8);d.line((744,235,799,170,854,175),fill='#999999',width=8)
 for name,pts in limbs.items():
  color='#b01b80' if name.startswith('near') else '#008eb6';d.line([tuple(p) for p in pts],fill=color,width=16)
  for x,y in pts:d.ellipse((x-9,y-9,x+9,y+9),fill=color,outline='white',width=2)
  x,y=pts[-1];d.line((x-24,y,x+8,y),fill=color,width=16)
 d.line((100,650,920,650),fill='#888888',width=3);d.line((100,630,920,630),fill='#bbbbbb',width=1);d.line((200,90,60,90),fill='black',width=6);d.polygon([(60,90),(80,78),(80,102)],fill='black')
 d.text((50,705),'A: nearFORE back + nearHIND forward. B: nearFORE forward + nearHIND back.',fill='black');d.text((50,735),'Pink = near foreground; blue = far background. Never copy colors, shapes, labels or lines.',fill='black');im.save(O/f'desired-W-contact{phase}-equine-joint-guide.png');(O/f'desired-W-contact{phase}-equine-joint-guide.json').write_text(json.dumps({'kind':'own abstract W equine joint topology; no sprite pixels','phase':phase,'limbs':limbs},indent=2)+'\n')
