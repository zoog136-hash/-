from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
O=Path(__file__).parent;O.mkdir(exist_ok=True)
near='#b01b80';far='#008eb6'
phases={
 'A':{
  'far_hind':[[330,275],[405,390],[385,505],[445,610],[470,630]],
  'far_fore':[[620,275],[585,380],[555,490],[540,575],[565,598]],
  'near_hind':[[355,300],[420,405],[280,520],[245,625],[265,650]],
  'near_fore':[[640,300],[615,395],[710,490],[780,625],[800,650]],
 },
 'B':{
  'far_hind':[[330,275],[385,390],[220,515],[205,605],[225,630]],
  'far_fore':[[620,275],[600,375],[695,480],[760,610],[780,630]],
  'near_hind':[[355,300],[445,410],[410,530],[470,625],[490,650]],
  'near_fore':[[640,300],[600,400],[565,500],[530,575],[550,600]],
 }
}
for phase,limbs in phases.items():
 im=Image.new('RGB',(1024,800),'white');d=ImageDraw.Draw(im)
 d.text((45,20),f'OWN ABSTRACT EQUINE FOUR-LEG TOPOLOGY - E / RIGHT CONTACT {phase}',fill='black');d.text((45,45),'KINEMATICS ONLY: source horse anatomy/material/proportions remain authoritative',fill='black')
 d.ellipse((280,175,690,355),outline='#999999',width=8);d.line((665,230,730,145,790,145),fill='#999999',width=8);d.line((280,235,225,170,170,175),fill='#999999',width=8)
 for name,pts in limbs.items():
  color=near if name.startswith('near') else far;d.line([tuple(p) for p in pts],fill=color,width=16)
  for x,y in pts:d.ellipse((x-9,y-9,x+9,y+9),fill=color,outline='white',width=2)
  x,y=pts[-1];d.line((x-8,y,x+24,y),fill=color,width=16)
 d.line((100,650,920,650),fill='#888888',width=3);d.line((100,630,920,630),fill='#bbbbbb',width=1)
 d.line((815,90,950,90),fill='black',width=6);d.polygon([(950,90),(930,78),(930,102)],fill='black')
 if phase=='A':texts=[(35,420,'CYAN far hind FORWARD'),(650,415,'CYAN far fore BACK / lifted'),(35,705,'MAGENTA near hind BACK'),(625,705,'MAGENTA near fore FORWARD')]
 else:texts=[(35,420,'CYAN far hind BACK'),(650,415,'CYAN far fore FORWARD'),(35,705,'MAGENTA near hind FORWARD'),(625,705,'MAGENTA near fore BACK / lifted')]
 for x,y,t in texts:d.text((x,y),t,fill=far if t.startswith('CYAN') else near)
 d.text((80,750),'Only four connected chains. Do NOT copy diagram colors, labels, lines or body shape.',fill='black')
 p=O/f'desired-E-contact{phase}-equine-joint-guide.png';im.save(p);p.with_suffix('.json').write_text(json.dumps({'kind':'own abstract equine joint topology, no sprite pixels','phase':phase,'limbs':limbs},indent=2)+'\n')
