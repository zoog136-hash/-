from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).parent;j=json.load(open(R/'walk-E-threephase-pilot1.diagnostic.json'));im=Image.open(R/'walk-E-threephase-pilot1.png').convert('RGBA');out=Image.new('RGB',(1920,990),(238,241,243));d=ImageDraw.Draw(out)
traces=[{'near_fore':[(650,220),(700,310),(790,400),(865,449)],'near_hind':[(350,220),(300,300),(215,360),(170,415)],'far_fore':[(675,215),(605,270),(620,315),(570,350)],'far_hind':[(410,230),(435,290),(445,350),(505,399)]},{'near_fore':[(650,725),(640,825),(645,930),(660,980)],'near_hind':[(350,720),(350,805),(370,905),(410,960)],'far_fore':[(690,720),(800,790),(820,850),(790,895)],'far_hind':[(410,720),(300,795),(280,840),(250,880)]},{'near_fore':[(650,1230),(560,1280),(650,1350),(600,1380)],'near_hind':[(350,1230),(430,1300),(450,1400),(500,1450)],'far_fore':[(695,1220),(735,1330),(830,1430),(865,1480)],'far_hind':[(415,1235),(300,1300),(230,1385),(170,1455)]}]
colors={'near_fore':'#cc1b81','near_hind':'#e58b12','far_fore':'#00a3cf','far_hind':'#17a64e'}
for i,f in enumerate(j['geometry']['frames']):
 x,y,w,h=f['region'];ax,ay=f['source_anchor'];z=.7;left=round(320+(x-ax)*z);top=round(400+(y-ay)*z);q=Image.new('RGBA',(640,450),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z)),Image.Resampling.LANCZOS),(left,top));qd=ImageDraw.Draw(q);qd.line((0,400,639,400),fill=(166,186,172));out.paste(q.convert('RGB'),(i*640,35));d.text((i*640+8,8),['E contactA','E realpassing','E oppositecontactB'][i]+' constant rawscale0.7',fill='black');q2=q.copy();qd=ImageDraw.Draw(q2)
 for name,line in traces[i].items():
  line=[(round(320+(px-ax)*z),round(400+(py-ay)*z))for px,py in line];qd.line(line,fill=colors[name],width=4)
  for px,py in line:qd.ellipse((px-4,py-4,px+4,py+4),fill=colors[name])
 out.paste(q2.convert('RGB'),(i*640,530));d.text((i*640+8,500),'Diagnostic actual shoulder/hip → elbow/hock → paw traces only',fill='black')
out.save(R/'E-pilot1-clean-and-actual-joint-review.png');(R/'E-pilot1-actual-joint-review.json').write_text(json.dumps({'key':'monster:검은숲 늑대','raw_sha256':j['raw_sha256'],'author_physical_assessment':'A nearforeforward/nearhindback; P foreunderownshoulder; B nearforebacklift/nearhindforward, farforeforward. Four continuous canine chains, body-rootx502 unchanged all3. Root approval pending.','actual_joint_traces':traces,'source_png_modified':False,'Main':'not_run','completed_added':0},ensure_ascii=False,indent=2)+'\n')
