from pathlib import Path
import json
from PIL import Image,ImageDraw
O=Path(__file__).parent
poses={
 'S_A':{'RF':[[445,330],[444,430],[425,520],[420,610],[425,635]],'LF':[[555,330],[562,445],[580,550],[590,670],[595,695]],'RH':[[405,300],[385,405],[370,490],[375,580],[380,605]],'LH':[[615,300],[620,385],[625,445],[620,495],[615,520]]},
 'S_B':{'RF':[[445,330],[437,445],[420,550],[410,670],[405,695]],'LF':[[555,330],[556,430],[575,520],[580,610],[575,635]],'RH':[[405,300],[380,385],[375,445],[380,495],[385,520]],'LH':[[615,300],[630,405],[640,490],[635,580],[630,605]]},
 'N_A':{'RF':[[620,310],[630,410],[640,485],[635,565],[630,590]],'LF':[[405,310],[395,390],[385,440],[390,505],[395,530]],'RH':[[560,350],[575,440],[590,515],[580,575],[575,600]],'LH':[[460,350],[450,465],[435,550],[430,660],[425,685]]},
 'N_B':{'RF':[[620,310],[630,390],[640,440],[635,505],[630,530]],'LF':[[405,310],[395,410],[385,485],[390,565],[395,590]],'RH':[[560,350],[575,465],[590,550],[595,660],[600,685]],'LH':[[460,350],[450,440],[435,515],[445,575],[450,600]]},
}
colors={'RF':'#ad1b80','LF':'#008eb6','RH':'#e07b14','LH':'#248544'}
panel=Image.new('RGB',(2048,1600),'white');d=ImageDraw.Draw(panel)
for i,(key,limbs) in enumerate(poses.items()):
 ox=(i%2)*1024;oy=(i//2)*800
 d.text((ox+50,oy+20),f'OWN ABSTRACT EQUINE TOPOLOGY {key} - colors specify anatomical leg identity only',fill='black');d.text((ox+50,oy+45),'S = FRONT toward camera / DOWN. N = PURE BACK away / UP; no face.',fill='black')
 d.ellipse((ox+350,oy+180,ox+675,oy+390),outline='#999999',width=8);d.ellipse((ox+455,oy+85,ox+565,oy+190),outline='#999999',width=8)
 if key.startswith('N'):d.line((ox+515,oy+350,ox+700,oy+440,ox+735,oy+520),fill='#999999',width=18)
 for name,pts in limbs.items():
  q=[(ox+x,oy+y) for x,y in pts];d.line(q,fill=colors[name],width=14)
  for x,y in q:d.ellipse((x-8,y-8,x+8,y+8),fill=colors[name],outline='white',width=2)
  x,y=q[-1];d.line((x-14,y,x+14,y),fill=colors[name],width=18);d.text((x+20,y-10),name,fill=colors[name])
 d.text((ox+40,oy+735),'RF anatomicalRIGHT fore (pink); LF LEFT fore (blue); RH RIGHT hind (orange); LH LEFT hind (green)',fill='black');d.text((ox+40,oy+760),'No donor sprite pixels. Keep original horse proportions/materials; never copy colors, diagram or labels.',fill='black')
panel.save(O/'desired-S-N-contactAB-equine-joint-guide.png');(O/'desired-S-N-contactAB-equine-joint-guide.json').write_text(json.dumps({'kind':'own abstract S/N equine anatomical4leg topology no sprite pixels','poses':poses},indent=2)+'\n')
