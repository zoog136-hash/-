from pathlib import Path
import json,hashlib,sys,shutil,datetime
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
R=Path(__file__).parent;original=Path(sys.argv[1]);stem=sys.argv[2];rows=int(sys.argv[3]);directions=sys.argv[4].split(',');canvas=int(sys.argv[5]);out=R/(stem+'.png')
if out.exists():assert out.read_bytes()==original.read_bytes()
else:shutil.copyfile(original,out)
j={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'key':'monster:검은숲 늑대','raw_path':str(out),'generated_original':str(original),'raw_sha256':m.sha(out),'unchanged_from_generated':True,'exact_prompt_path':str(R/(stem+'.prompt.txt')),'rows':rows,'directions':directions,'canvas_size_geometry_only':canvas,'visual_quality':'ROOT_PHYSICAL_PILOT_PENDING','Main':'not_run','completed_added':0}
try:
 g=m.analyze(out,rows,list(range(rows)),None,'columns',canvas,directions=directions);m.require_complete_pose_regions(out,g);j.update(strict_geometry='PASS',complete_visible='PASS',pose_count=len(g['frames']),geometry=g);a=np.asarray(Image.open(out).convert('RGBA'));j['raw_unique']=len({f['rgba_sha256']for f in g['frames']});j['visible_unique']=len({m._visible_pose_fingerprint(a[f['region'][1]:f['region'][1]+f['region'][3],f['region'][0]:f['region'][0]+f['region'][2]])for f in g['frames']})
except Exception as e:j.update(strict_geometry='FAIL',error=str(e))
(R/(stem+'.diagnostic.json')).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
records=R/'generation-records.json';rs=json.load(open(records))if records.exists()else[];rs.append({k:v for k,v in j.items()if k!='geometry'});records.write_text(json.dumps(rs,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in j.items()if k!='geometry'},ensure_ascii=False))
