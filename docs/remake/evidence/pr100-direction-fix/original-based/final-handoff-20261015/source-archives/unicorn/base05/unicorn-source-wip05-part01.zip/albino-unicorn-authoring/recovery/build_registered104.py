from pathlib import Path
import json,hashlib,sys,datetime
from PIL import Image,ImageDraw
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
R=Path(__file__).parent;old=json.load(open(R/'candidate-recovery-all104-wip.json'))
scales={'attack-E-SE-spacing-attempt2':704,'attack-W-NW-attempt1':896,'attack-N-threephase-attempt1':1216}
c={'input_mode':'mixed_sources_v1','texture_binding':'unchanged_png_metadata','key':old['key'],'prompt':'New reference-based authored unicorn animation, exact per-source prompts retained next to immutable source PNGs; mixed source format uses whole source sheets + three whole W walking single PNGs, no PNG assembly/cropping/resampling. Same-atlas exact source reference and original presentation preserved.','prompt_record_kind':'per_source_exact_prompt_files','phase_counts':{'idle':2,'walk':3,'attack':3,'hit':2,'death':3},'expected_distinct_poses':104,'display_height_basis':'median_idle','sheets':[],'pose_files':[],'review':{'identity_preserved':False,'eight_views':False,'motion_roles':False,'no_clipping':False,'notes':'HOLD: Author metadata proposal only; full104 anatomical scale/ground root and actual Main pending root independent review.'},'source_claim':'New reference-based authored animation, not recovered original frames.','status':'HOLD_REGISTERED104_METADATA_TRIAL01','actual_Main':'not_run','completed_added':0}
entries=[];errors=[]
for idx,s in enumerate(old['sheets']):
 p=Path(s['output_path']);stem=p.stem
 if stem=='walk-W-B-propagation-attempt4':continue
 canvas=scales.get(stem,1024);g=m.analyze(p,s['rows'],s.get('reference_rows'),None,s.get('directions_axis','columns'),canvas,directions=s['directions']);m.require_complete_pose_regions(p,g)
 anchors=[f['source_anchor'][:] for f in g['frames']]
 # N root lies under the sagittal rump rather than to the tail-biased bounding-box center.
 for i,f in enumerate(g['frames']):
  if f['direction']=='N':
   pass
 spec={'id':f'sheet{idx:02d}-{stem}','output_path':str(p),'source_sha256':m.sha(p),'rows':s['rows'],'directions_axis':s.get('directions_axis','columns'),'directions':s['directions'],'reference_rows':s.get('reference_rows',list(range(s['rows']))),'roles':s['roles'],'canvas_size':canvas,'source_anchors':anchors,'scale_review_note':'HOLD metadata trial01: homologous head/chest/haunch comparison required. E/SE attack canvas704 vs idle1024; W/NW attack896; N attack1216 to correct enlarged rump. Sole/spine root anchors still under visual review. No max-silhouette role fit; median idle display height.'}
 c['sheets'].append(spec)
 for f,a in zip(g['frames'],anchors):
  role=next(k for k,rs in s['roles'].items() if f['row'] in rs);phase=s['roles'][role].index(f['row']);entries.append({'path':str(p),'source_kind':'whole_sheet','role':role,'direction':f['direction'],'phase':phase,'canvas':canvas,'anchor':a,'frame':f})
for phase,stem,canvas,anchor in [(0,'W-contactA-single-attempt1',1952,[768,916]),(1,'W-passing-single-attempt2',2048,[790,950]),(2,'W-contactB-single-attempt1',1952,[774,925])]:
 p=R/(stem+'.png');g=m.analyze(p,1,[0],None,'columns',canvas,[anchor],['W']);m.require_complete_pose_regions(p,g);f=g['frames'][0];c['pose_files'].append({'id':f'walk-W-{phase}','output_path':str(p),'source_sha256':m.sha(p),'role':'walk','direction':'W','phase':phase,'canvas_size':canvas,'source_anchor':anchor,'scale_review_note':'HOLD metadata trial01: A/B canvas1952, passing2048, preliminary homologous head/chest/haunch calibration. Actual soles use raw anchor y916/950/925; no PNG modification. Root independent review and actual Main pending.'});entries.append({'path':str(p),'source_kind':'pose_file','role':'walk','direction':'W','phase':phase,'canvas':canvas,'anchor':anchor,'frame':f})
(R/'candidate-mixed104-registration-trial01.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
D=R/'registered104-trial01';D.mkdir(exist_ok=True);proof=[]
roles=['idle','walk','attack','hit','death'];counts=c['phase_counts']
for direction in m.DIRECTIONS:
 es=sorted([e for e in entries if e['direction']==direction],key=lambda e:(roles.index(e['role']),e['phase']));panel=Image.new('RGB',(5*512,3*552),(237,241,243));d=ImageDraw.Draw(panel)
 for i,e in enumerate(es):
  im=Image.open(e['path']).convert('RGBA');x,y,w,h=e['frame']['region'];scale=512/e['canvas'];ax,ay=e['anchor'];left=round(256+(x-ax)*scale);top=round(320+(y-ay)*scale);q=Image.new('RGBA',(512,512),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*scale),round(h*scale)),Image.Resampling.LANCZOS),(left,top));qd=ImageDraw.Draw(q);qd.line((0,320,511,320),fill=(160,182,167));qd.ellipse((253,317,259,323),outline='#cb2364',width=2);col=i%5;row=i//5;panel.paste(q.convert('RGB'),(col*512,row*552+35));d.text((col*512+8,row*552+8),f'{direction} {e["role"]}{e["phase"]} canvas{e["canvas"]} anchor{e["anchor"]}',fill='black');e['diagnostic_bounds']=[left,top,round(w*scale),round(h*scale)];proof.append(e)
 panel.save(D/f'matrix-{direction}-13poses.png')
pixels=[]
for e in entries:
 a=np.asarray(Image.open(e['path']).convert('RGBA'));x,y,w,h=e['frame']['region'];pixels.append(m._visible_pose_fingerprint(a[y:y+h,x:x+w]))
(R/'registered104-trial01-proof.json').write_text(json.dumps({'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'HOLD_AUTHOR_PROPOSAL_VISUAL_SCALE_ANCHOR_QA_PENDING','source_count':len(c['sheets'])+len(c['pose_files']),'body_count':len(entries),'global_visible_unique':len(set(pixels)),'every_selected_source_body_used_once':True,'selected_old_failed_W3_sheet':False,'source_pngs_modified':False,'display_height_basis':'median_idle','entries':proof,'Main':'not_run','completed_added':0},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidate':str(R/'candidate-mixed104-registration-trial01.json'),'panels':str(D),'bodies':len(entries),'unique':len(set(pixels)),'source_count':len(c['sheets'])+len(c['pose_files'])}))
