from pathlib import Path
import json,hashlib,zipfile,datetime
ROOT=Path('/workspace/scratch/pr100-continuation');R=ROOT/'albino-unicorn-authoring/recovery';W=ROOT/'blackforest-wolf-authoring';O=R/'portable-FINAL-PAUSED-delta07';O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=json.load(open(R/'portable-wip05/unicorn-source-wip05-index.json'));d=json.load(open(R/'portable-delta06/unicorn-wolf-source-delta06-index.json'));prior={e['entry']:e['sha256']for e in b['entries']};prior.update({e['entry']:e['sha256']for e in d['entries']});now=datetime.datetime.now(datetime.timezone.utc).isoformat();c=R/'candidate-mixed104-registration-proposal06.json';assert sha(c)=='f5e2e96cee8d9c13e38a5285be2ba9b663abe93267c0ec35542bf6576d01de26'
state={'updated_utc':now,'status':'USER_STOPPED_ALL_NEW_PRODUCTION','instruction_from_parent':'USER STOP ALL NEW PRODUCTION IMMEDIATE. No more imagegen/newactor/tests. Already-running generation safe await finish/save exact raw/prompt/error then STOP.','current_running_processes':[],'new_authoring_or_geometry_tests_after_stop':0,'production_edits_by_this_agent':False,'completed_added':0,'all_review_flags':False,'Unicorn06':{'candidate':str(c),'candidate_sha256':sha(c),'status':'HOLD_FULL_IMPORTER_VALIDATION_FAILED_BEFORE_IMPORT','root_reported_command':'--validate-candidate','root_reported_error':'Standalone PNG must contain one connected visible body.','failing_source_path':'Not specified in root message; inspect parent validation log after reauthorization, do not guess.','production_import':'NOT_STARTED','actual_Main33':'NOT_STARTED','source_author_readonly_geometry':'Earlier m.analyze+complete-visible104 PASS is narrower than full importer; never a quality/qualification pass. Full parser guard failed; do not relax/bypass it.','frozen05_and06_candidates_and_archives':'UNCHANGED; no attempted repair after STOP.'},'Wolf':{'checkpoint':str(W/'recovery-by-unicorn/checkpoint.json'),'status':'SOURCE_ONLY_HOLD_PAUSED','new_raw_output_count':17,'new_since_delta06':['walk-SE-threephase-pilot1.png','walk-S-threephase-pilot1.png','walk-SW-threephase-pilot1.png','walk-NW-threephase-pilot1.png','walk-NE-threephase-pilot1.png','walk-N-compact-rear-threephase-pilot2.png'],'NW_NE':'Finished generation before STOP; saved whole raw and exact prompts only, no analyzer/test after STOP. Suspected same near-fore endpoint lead is explicitly HOLD.','new_full104_candidate':'NOT_ASSEMBLED','actual_Main':'NOT_RUN'},'resume_gate':'Await new user instruction. No authoring, imagegen, actor production, importer repair or tests while paused.','restore':['Extract base05 part01+part02, delta06 part01+part02, then FINAL-PAUSED delta07 under /workspace/scratch/pr100-continuation. Each is an independent ZIP; never concatenate.','All exact raw attempts/prompts/source identity/failed source/checkpoint states reconstruct from Git checkpoint archives; no prior chat history needed.','Current authoritative pause state is this JSON and Wolf recovery-by-unicorn/checkpoint.json. Older source-only proposal proofs remain historical, not current quality acceptance.']};pause=R/'checkpoint-USER-STOP-FINAL-PAUSED.json';pause.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
paths={pause,Path(__file__)}
for p in W.rglob('*'):
 if not p.is_file()or'__pycache__'in p.parts:continue
 if p.suffix not in ['.png','.json','.txt','.py','.log']:continue
 if p.suffix=='.png'and(p.stem.endswith('-black')or'.on-black'in p.stem or'.on-white'in p.stem):continue
 paths.add(p)
entries=[]
for p in sorted(paths):
 e=str(p.relative_to(ROOT));digest=sha(p)
 if prior.get(e)==digest:continue
 entries.append({'source':str(p),'entry':e,'bytes':p.stat().st_size,'sha256':digest})
# Ensure each completed raw and exact prompt is recoverable through the old archives + final overlay.
coverage=dict(prior);coverage.update({e['entry']:e['sha256']for e in entries});wr=json.load(open(W/'recovery-by-unicorn/generation-records.json'));raw={r['raw_path']:r for r in wr}
for p,r in raw.items():
 q=Path(p);assert sha(q)==r['raw_sha256']and coverage[str(q.relative_to(ROOT))]==r['raw_sha256'];prompt=Path(r['exact_prompt_path']);assert coverage[str(prompt.relative_to(ROOT))]==sha(prompt)
# Archive integrity hashes only, no motion/geometry/importer tests after STOP.
archives=[];groups=[];group=[];n=0
for e in entries:
 if group and n+e['bytes']>80*1024*1024:groups.append(group);group=[];n=0
 group.append(e);n+=e['bytes']
if group:groups.append(group)
for k,g in enumerate(groups,1):
 p=O/f'unicorn-wolf-source-FINAL-PAUSED-delta07-part{k:02d}.zip'
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for e in g:z.write(e['source'],e['entry'])
 with zipfile.ZipFile(p)as z:
  for e in g:assert hashlib.sha256(z.read(e['entry'])).hexdigest()==e['sha256']
 archives.append({'file':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'entries':len(g),'restore':'independent ZIP, extract to /workspace/scratch/pr100-continuation'})
idx={'created_utc':now,'status':'USER_STOPPED_SOURCE_ONLY_HOLD_NO_MAIN_NO_COUNT','requires_base05_archives':b['archives'],'requires_delta06_archives':d['archives'],'archives':archives,'entry_count':len(entries),'uncompressed_bytes':sum(e['bytes']for e in entries),'member_sha256_verified_for_preservation':True,'new_motion_geometry_or_importer_tests_after_stop':0,'all17_Wolf_raws_and_exact_prompts_recoverable':True,'candidate06_unchanged_sha256':sha(c),'Unicorn06_full_importer_status':'FAILED before import: Standalone PNG must contain one connected visible body.','Unicorn06_production_import_and_Main33':'NOT_STARTED','review_flags':False,'completed_added':0,'current_running_processes':[],'current_pause_checkpoint':str(pause),'entries':entries};(O/'unicorn-wolf-source-FINAL-PAUSED-delta07-index.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in idx.items()if k not in['entries','requires_base05_archives','requires_delta06_archives']},ensure_ascii=False,indent=2))
