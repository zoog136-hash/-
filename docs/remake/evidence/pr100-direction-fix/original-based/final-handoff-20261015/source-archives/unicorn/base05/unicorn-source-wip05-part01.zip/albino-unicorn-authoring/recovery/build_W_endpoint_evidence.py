from pathlib import Path
import json
from PIL import Image,ImageDraw
R=Path(__file__).parent
stem='walk-W-B-propagation-attempt4'
g=json.load(open(R/(stem+'.diagnostic.json')))['geometry'];im=Image.open(R/(stem+'.png')).convert('RGBA')
paths={0:{'near_fore':[(397,270),(349,336),(389,362),(434,390)],'near_hind':[(590,270),(576,330),(606,394),(532,487)],'far_fore':[(346,292),(310,398),(229,480)],'far_hind':[(630,300),(700,370),(790,470)]},2:{'near_fore':[(400,1276),(340,1357),(285,1421),(225,1483)],'near_hind':[(601,1275),(676,1348),(742,1412),(806,1480)],'far_fore':[(386,1300),(390,1376),(466,1414)],'far_hind':[(542,1320),(606,1398),(542,1485)]}}
colors={'near_fore':(224,34,89),'near_hind':(238,134,10),'far_fore':(18,162,214),'far_hind':(29,170,81)}
canvas=Image.new('RGB',(1536,1100),(239,242,245));dr=ImageDraw.Draw(canvas)
for phase,f in enumerate(g['frames']):
 x,y,w,h=f['region'];size=g['canvas_size'][0];q=Image.new('RGBA',(size,size),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)),tuple(f['margin'][:2]));q=q.resize((512,512),Image.Resampling.LANCZOS);canvas.paste(q.convert('RGB'),(phase*512,40));dr.text((phase*512+10,10),['W contactA','W passing','W contactB'][phase],fill='black')
 if phase in paths:
  qq=Image.new('RGBA',(size,size),'white');qq.alpha_composite(im.crop((x,y,x+w,y+h)),tuple(f['margin'][:2]));dd=ImageDraw.Draw(qq)
  for limb,points in paths[phase].items():
   points=[(px-x+f['margin'][0],py-y+f['margin'][1]) for px,py in points];dd.line(points,fill=colors[limb],width=5)
   for px,py in points:dd.ellipse((px-5,py-5,px+5,py+5),fill=colors[limb])
  canvas.paste(qq.resize((512,512),Image.Resampling.LANCZOS).convert('RGB'),(phase*512,580))
for n,(limb,c) in enumerate(colors.items()):dr.text((530,620+30*n),limb,fill=c)
dr.text((530,780),'Diagnostic manual joint traces only.',fill='black');dr.text((530,810),'Near fore: folded back A -> forward planted B.',fill='black');dr.text((530,840),'Near hind: forward A -> trails backward B.',fill='black')
canvas.save(R/'W-attempt4-endpoint-joint-evidence.png')
(R/'W-attempt4-endpoint-joint-evidence.json').write_text(json.dumps({'sheet':str(R/(stem+'.png')),'raw_sha256':json.load(open(R/(stem+'.diagnostic.json')))['raw_sha256'],'manual_visual_joint_traces_source_pixels':paths,'near_limbs_reason':'Closest folded foreleg occludes far extended foreleg in A; closest rounded haunch connects to forward hind. In B closest shoulder connects to long forward foreleg and closest haunch connects to back trailing hind.','status':'AUTHOR_OBSERVATION_ROOT_INDEPENDENT_REVIEW_PENDING','diagnostic_only':True},indent=2)+'\n')
print(str(R/'W-attempt4-endpoint-joint-evidence.png'))
