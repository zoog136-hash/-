from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path('/workspace/scratch/pr100-continuation/albino-unicorn-authoring/recovery');out=Image.new('RGB',(1500,900),'white');d=ImageDraw.Draw(out)
for col,(stem,direction) in enumerate([('idle-S-SW-attempt1','S'),('walk-S-N-threephase-attempt1','S')]):
 j=json.load(open(R/(stem+'.diagnostic.json')));f=next(f for f in j['geometry']['frames']if f['direction']==direction and f['row']==0);x,y,w,h=f['region'];im=Image.open(R/(stem+'.png')).convert('RGBA');q=Image.new('RGBA',(w,h),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)));z=1.2;ox=col*750+100;oy=60;out.paste(q.resize((round(w*z),round(h*z))).convert('RGB'),(ox,oy));d.text((col*750+10,10),f'{stem} source {f["region"]} x/y labels',fill='black')
 for xx in range(((x+19)//20)*20,x+w,20):
  ax=ox+(xx-x)*z;d.line((ax,oy,ax,oy+h*z),fill=(180,198,209));d.text((ax,oy-15),str(xx),fill='black')
 for yy in range(((y+19)//20)*20,y+h,20):
  ay=oy+(yy-y)*z;d.line((ox,ay,ox+w*z,ay),fill=(180,198,209));d.text((ox-35,ay),str(yy),fill='black')
out.save(R/'S-idle-walk-homologous-raw-grid.png')
