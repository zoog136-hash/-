from pathlib import Path
import json,hashlib,zipfile,datetime
B=Path(__file__).parent.parent;R=B/'recovery';O=R/'portable-wip05';O.mkdir(exist_ok=True)
records=json.load(open(B/'generation-manifest.json'))+json.load(open(R/'recovery-generation-records.json'));files={}
for record in records:
 p=Path(record['path']);digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest==record.get('raw_sha256',record.get('sha256'));files[p.resolve()]=p
for p in B.rglob('*'):
 if not p.is_file()or O in p.parents:continue
 if p.suffix in['.json','.py','.txt','.log']:files[p.resolve()]=p
for p in [B/'source-expanded-context.png',B/'source-wholebody-context.png',R/'N-idle-walk-homologous-raw-grid.png',R/'S-idle-walk-homologous-raw-grid.png',R/'W-single-passing2-registered-clean-and-joints.png']:
 if p.exists():files[p.resolve()]=p
for p in R.glob('desired-*.png'):files[p.resolve()]=p
for p in(R/'registration-proposal05').glob('*.png'):files[p.resolve()]=p
entries=[{'source':str(p),'entry':'albino-unicorn-authoring/'+str(p.relative_to(B)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(files.values())]
parts=[];batch=[];size=0
for e in entries:
 if batch and size+e['bytes']>65*1024**2:parts.append(batch);batch=[];size=0
 batch.append(e);size+=e['bytes']
if batch:parts.append(batch)
archives=[]
for i,part in enumerate(parts,1):
 out=O/f'unicorn-source-wip05-part{i:02d}.zip'
 if out.exists():raise RuntimeError('Never overwrite frozen portable WIP archive '+str(out))
 with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for e in part:z.write(e['source'],e['entry'])
 with zipfile.ZipFile(out)as z:
  for e in part:assert hashlib.sha256(z.read(e['entry'])).hexdigest()==e['sha256']
 archives.append({'file':out.name,'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'entries':[e['entry']for e in part]})
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'key':'monster:알비노 유니콘','status':'UNQUALIFIED_SOURCE_WIP_ROOT_VISUAL_MAIN_PENDING','restore':'Extract each independent ZIP into /workspace/scratch/pr100-continuation, preserving paths. Follow albino-unicorn-authoring/recovery/checkpoint.json. Never run/accept root quality flags automatically.','candidate':'albino-unicorn-authoring/recovery/candidate-mixed104-registration-proposal05.json','raw_authored_source_count':len({Path(x['path']).resolve()for x in records}),'selected_source_count':29,'selected_body_count':104,'all_failed_authored_raw_pngs_preserved':True,'all_selected_png_hashes_checked_against_generation_records':True,'zip_entries_verified_against_sha256':True,'entry_count':len(entries),'archives':archives,'entries':entries,'production_imported':False,'Main':'not_run','completed_added':0}
(O/'unicorn-source-wip05-index.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'index':str(O/'unicorn-source-wip05-index.json'),'archives':[{k:v for k,v in a.items()if k!='entries'}for a in archives],'entries':len(entries)},ensure_ascii=False))
