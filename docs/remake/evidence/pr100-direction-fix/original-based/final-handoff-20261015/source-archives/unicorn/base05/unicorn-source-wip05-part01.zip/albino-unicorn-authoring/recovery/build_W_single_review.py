from pathlib import Path
import json,hashlib
from PIL import Image,ImageDraw
R=Path(__file__).parent
entries=[('contactA','W-contactA-single-attempt1',1952,[768,916]),('passing','W-passing-single-attempt2',2048,[790,950]),('contactB','W-contactB-single-attempt1',1952,[774,925])]
out=Image.new('RGB',(1536,1120),(240,243,245));d=ImageDraw.Draw(out)
frames=[]
# These traces record visible shoulder/hip chains manually; diagnostics only, never artwork.
traces={
'contactA':{'near_fore':[(580,411),(515,511),(588,605),(629,646)],'near_hind':[(894,411),(849,544),(906,663),(824,852),(789,900)],'far_fore':[(541,422),(470,596),(343,858),(300,900)],'far_hind':[(949,441),(1080,600),(1189,852),(1211,886)]},
'passing':{'near_fore':[(555,453),(550,658),(552,836),(525,927)],'near_hind':[(974,445),(1022,646),(962,760),(927,922)],'far_fore':[(490,465),(367,682),(444,790),(480,827)],'far_hind':[(972,484),(1074,660),(1025,758),(1089,803)]},
'contactB':{'near_fore':[(575,453),(449,602),(325,850),(291,906)],'near_hind':[(931,461),(1039,608),(1164,812),(1172,905)],'far_fore':[(544,476),(559,648),(656,763),(694,846)],'far_hind':[(884,505),(946,664),(873,790),(793,898)]}}
colors={'near_fore':'#da1d74','near_hind':'#e8850c','far_fore':'#10a5d2','far_hind':'#17a14a'}
for col,(phase,stem,canvas,anchor) in enumerate(entries):
 j=json.load(open(R/(stem+'.diagnostic.json')));f=j['geometry']['frames'][0];im=Image.open(R/(stem+'.png')).convert('RGBA');x,y,w,h=f['region'];z=512/canvas;left=256+(x-anchor[0])*z;top=320+(y-anchor[1])*z
 q=Image.new('RGBA',(512,512),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z)),Image.Resampling.LANCZOS),(round(left),round(top)));qd=ImageDraw.Draw(q);qd.line((0,320,511,320),fill=(170,190,176));qd.ellipse((253,317,259,323),outline='#d32364',width=2)
 out.paste(q.convert('RGB'),(col*512,40));d.text((col*512+10,10),f'W {phase} / whole PNG / virtual {canvas}',fill='black')
 q2=q.copy();qd=ImageDraw.Draw(q2)
 for name,pts in traces[phase].items():
  pts=[(round(256+(px-anchor[0])*z),round(320+(py-anchor[1])*z)) for px,py in pts];qd.line(pts,fill=colors[name],width=3)
  for px,py in pts:qd.ellipse((px-3,py-3,px+3,py+3),fill=colors[name])
 out.paste(q2.convert('RGB'),(col*512,590));d.text((col*512+10,560),'Manual visible joint-chain overlay; not production pixels',fill='black')
 frames.append({'phase':phase,'file':str(R/(stem+'.png')),'raw_sha256':hashlib.sha256((R/(stem+'.png')).read_bytes()).hexdigest(),'canvas_size_proposed':canvas,'source_anchor_proposed':anchor,'manual_joint_trace':traces[phase]})
out.save(R/'W-single-passing2-registered-clean-and-joints.png')
(R/'W-single-passing2-review.json').write_text(json.dumps({'key':'monster:알비노 유니콘','status':'ROOT_REVIEW_PENDING','frames':frames,'note':'Three separate whole unchanged PNGs, no selected subset of failed W3 sheet. Metadata-only calibration proposal not visual approval. Author sees distinct vertical near fore passing, opposite A/B near fore/hind chains.','Main':'not_run','completed_added':0},ensure_ascii=False,indent=2)+'\n')
