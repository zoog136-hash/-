from pathlib import Path
import json,hashlib,sys,datetime
import numpy as np
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
R=Path(__file__).parent;c=json.load(open(R/'candidate-mixed104-registration-proposal06.json'));slots={};sources=[];visible=set();raw=set();paths=set();sourcehashes=set();allframes=[]
for kind,s in [('whole_sheet',s)for s in c['sheets']]+[('pose_file',s)for s in c['pose_files']]:
 p=Path(s['output_path']);digest=m.sha(p);assert digest==s['source_sha256'];assert p.resolve()not in paths and digest not in sourcehashes;paths.add(p.resolve());sourcehashes.add(digest)
 dirs=s['directions']if kind=='whole_sheet'else[s['direction']];C=s['canvas_size'];sizes=s.get('canvas_sizes_by_direction',{d:C for d in dirs});assert set(sizes)==set(dirs)and max(sizes.values())==C and all(type(x)is int and 64<=x<=2048 for x in sizes.values())
 g=m.analyze(p,s.get('rows',1),s.get('reference_rows',[0]),None,s.get('directions_axis','columns'),C,s.get('source_anchors',[s.get('source_anchor')]),dirs);m.require_complete_pose_regions(p,g);a=np.asarray(Image.open(p).convert('RGBA'));used=set()
 for f in g['frames']:
  if kind=='whole_sheet':role=next(role for role,rows in s['roles'].items()if f['row']in rows);phase=s['roles'][role].index(f['row'])
  else:role=s['role'];phase=s['phase']
  slot=(role,f['direction'],phase);assert slot not in slots;slots[slot]=f;used.add((f['row'],f['direction']));x,y,w,h=f['region'];vf=m._visible_pose_fingerprint(a[y:y+h,x:x+w]);assert vf not in visible and f['rgba_sha256']not in raw;visible.add(vf);raw.add(f['rgba_sha256']);can=sizes[f['direction']];ax,ay=f['source_anchor'];margin=[round(can*.5)+x-ax,round(can*.625)+y-ay,can-w,can-h];assert min(margin)>=0 and margin[0]+w<=can and margin[1]+h<=can
  allframes.append({'role':role,'direction':f['direction'],'phase':phase,'source_file':str(p),'source_sha256':digest,'source_region':f['region'],'source_anchor':f['source_anchor'],'canvas_size':can,'margin':margin,'visible_sha256':vf,'rgba_sha256':f['rgba_sha256']})
 assert len(used)==len(g['frames'])
 sources.append({'file':str(p),'sha256':digest,'bytes':p.stat().st_size,'kind':kind,'analyzed_body_count':len(g['frames']),'used_body_count':len(used),'complete_visible':'PASS','all_selected_bodies_used_once':True,'canvas_sizes_by_direction':sizes})
expected={(r,d,ph)for r,n in c['phase_counts'].items()for d in m.DIRECTIONS for ph in range(n)};assert set(slots)==expected and len(slots)==104
plan=json.load(open('/workspace/twilight/data/animation_authoring_sources.json'));t=next(x for x in plan['targets']if x['key']==c['key']);ref=Path('/workspace/twilight')/t['reference']['path'].removeprefix('res://');assert m.sha(ref)==t['reference']['sha256']
report={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_sha256':m.sha(R/'candidate-mixed104-registration-proposal06.json'),'geometry_only':'PASS','actual_importer_extension_validation':'NOT_RUN_BY_SOURCE_AUTHOR_ROOT_OWNS_IMPORT','visual_quality':'ROOT_REVIEW_PENDING_NOT_AN_AUTOMATIC_PASS','reference_source_sha256':m.sha(ref),'source_count':len(sources),'source_body_count':len(slots),'raw_unique':len(raw),'visible_unique':len(visible),'complete_global_slot_matrix':'PASS','all_frames_fit_actual_direction_canvas':'PASS','source_pngs_changed':False,'review_flags':c['review'],'sources':sources,'frames':allframes,'Main':'not_run','completed_added':0}
(R/'proposal06-independent-geometry-proof.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in['sources','frames','review_flags']},ensure_ascii=False))
