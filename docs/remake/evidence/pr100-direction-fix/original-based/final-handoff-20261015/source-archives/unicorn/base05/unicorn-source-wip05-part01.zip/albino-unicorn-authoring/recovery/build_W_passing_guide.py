from pathlib import Path
from PIL import Image,ImageDraw
import json
O=Path(__file__).parent
limbs={
'far_hind':[(694,275),(649,375),(694,470),(674,555),(654,575)],
'far_fore':[(404,275),(364,365),(304,450),(319,520),(299,540)],
'near_hind':[(669,300),(624,410),(664,530),(649,625),(629,650)],
'near_fore':[(384,300),(384,410),(384,535),(384,625),(364,650)]}
im=Image.new('RGB',(1024,800),'white');d=ImageDraw.Draw(im)
d.text((30,20),'OWN ABSTRACT W EQUINE PASSING — NOT A CONTACT A/B COPY',fill='black')
d.ellipse((334,175,744,355),outline='#999999',width=8);d.line((359,230,294,145,234,145),fill='#999999',width=8);d.line((744,235,799,170,854,175),fill='#999999',width=8)
for name,pts in limbs.items():
 c='#b01b80' if name.startswith('near') else '#008eb6';d.line(pts,fill=c,width=16)
 for x,y in pts:d.ellipse((x-9,y-9,x+9,y+9),fill=c,outline='white',width=2)
 x,y=pts[-1];d.line((x-24,y,x+8,y),fill=c,width=16)
d.line((100,650,920,650),fill='#888888',width=3);d.line((200,90,60,90),fill='black',width=6);d.polygon([(60,90),(80,78),(80,102)],fill='black')
d.text((30,700),'Near FORE bears weight VERTICALLY under shoulder. Near HIND bears weight under rump.',fill='black');d.text((30,730),'Far FORE swings FORWARD with lifted hoof. Far HIND lifts clear. Four joined real legs.',fill='black')
im.save(O/'desired-W-passing-equine-joint-guide.png');(O/'desired-W-passing-equine-joint-guide.json').write_text(json.dumps({'kind':'own abstract equine topology no source pixels','limbs':limbs},indent=2)+'\n')
p='''Create ONE single whole white ivory UNICORN horse facing exactly LEFT/WEST, on a TRANSPARENT alpha zero background. First reference is an abstract equine joint guide, use it ONLY for exact passing-step skeleton. Second reference is this character\'s original source appearance. Third and fourth are this SAME independently authored unicorn\'s contact A/B whole poses for face, material and body proportions. Draw a NEW DISTINCT intermediate PASSING step, NEVER reproduce either reference contact pose. Closest/near foreleg must be almost VERTICAL from closest shoulder down through knee/fetlock to PLANTED hoof directly UNDER shoulder, bearing weight. Closest hindleg likewise bears weight directly under rump, slight real horse hock bend. Far foreleg SWINGS FORWARD/LEFT with bent knee and hoof lifted cleanly above ground in front of planted foreleg. Far hindleg swings with flexed hock and hoof lifted. Four attached anatomically legible horse leg chains, no duplicate limbs or fusion. This is a calm grounded walk, no rearing, no suspended jump. Hooves of two support legs share a horizontal ground plane, but no drawn ground/shadow. Exact identity: large white/ivory muscular equine, cream flowing mane and enormous cream tail, a SINGLE slender gold spiral horn facing left, visible red eye, pale pink muzzle, warm gold/brown hooves, white fetlock hair. Source-faithful head/chest/haunch proportions. No wings, armor, jewelry, weapon, saddle. Keep muzzle/horn LEFT, tail RIGHT, same slight elevated game sprite angle as third/fourth references. Full horse and complete tail/horn/hooves centrally framed with generous blank transparent margins. Exactly ONE connected character, no labels, guides, colored lines, floor, cast shadow, glow, background or extra objects. Crisp polished painterly 2D fantasy game sprite, clean edges.''' 
(O/'W-passing-single-attempt1.prompt.txt').write_text(p+'\n')
