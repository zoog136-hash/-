from pathlib import Path
import json,hashlib,zipfile,datetime
ROOT=Path('/workspace/scratch/pr100-continuation');R=ROOT/'albino-unicorn-authoring/recovery';W=ROOT/'blackforest-wolf-authoring';OUT=R/'portable-delta06';OUT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseidx=json.load(open(R/'portable-wip05/unicorn-source-wip05-index.json'));base={e['entry']:e['sha256']for e in baseidx['entries']};candidate=R/'candidate-mixed104-registration-proposal06.json';c=json.load(open(candidate));assert all(v is False for k,v in c['review'].items()if k!='notes');assert sha(R/'candidate-mixed104-registration-proposal05.json')=='2552fab5c1017362b4851044892f6034ac16e71d522c2484c26c9968542eca5c'
# New source-only06 report wording does not claim knowledge of root's importer work.
p=R/'verify_proposal06_geometry.py';s=p.read_text().replace('NOT_RUN_EXTENSION_IMPLEMENTATION_PENDING','NOT_RUN_BY_SOURCE_AUTHOR_ROOT_OWNS_IMPORT');p.write_text(s);p=R/'proposal06-independent-geometry-proof.json';j=json.load(open(p));j['actual_importer_extension_validation']='NOT_RUN_BY_SOURCE_AUTHOR_ROOT_OWNS_IMPORT';p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
newraw=[]
for rec in json.load(open(R/'recovery-generation-records.json')):
 p=Path(rec['path']);e=str(p.relative_to(ROOT))
 if e not in base:
  assert sha(p)==rec['raw_sha256'];assert p.with_suffix('.prompt.txt').exists();newraw.append(p)
newraw=sorted(set(newraw));wolfraw=[]
for rec in json.load(open(W/'recovery-by-unicorn/generation-records.json')):
 p=Path(rec['raw_path']);assert sha(p)==rec['raw_sha256'];assert Path(rec['exact_prompt_path']).exists();wolfraw.append(p)
wolfraw=sorted(set(wolfraw));selected=[]
for spec in c['sheets']+c['pose_files']:
 p=Path(spec['output_path']);assert sha(p)==spec['source_sha256'];selected.append({'path':str(p),'sha256':spec['source_sha256'],'location':'delta06'if p in newraw else'base05'})
wc=json.load(open(W/'candidate-wip.json'));wpins=[];wi=json.load(open(W/'recovery-by-unicorn/initial-independent-QA.json'));assert sha(W/'candidate-wip.json')==wi['prior_candidate_sha256'];wh={e['path']:e['sha256']for e in wi['old_selected_sources']}
for spec in wc.get('sheets',[]):
 p=Path(spec['output_path']);assert sha(p)==wh[str(p)];wpins.append({'path':str(p),'sha256':wh[str(p)]})
checkpoint={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOURCE_ONLY_HOLD_NO_PRODUCTION_NO_MAIN_NO_COUNT','candidate06':str(candidate),'candidate06_sha256':sha(candidate),'base05_candidate_sha256':sha(R/'candidate-mixed104-registration-proposal05.json'),'Unicorn_source_geometry':'104 exact roles/raw/visible unique PASS; 29 full source PNG files; actual Main not run','new_unicorn_authored_raw_count':len(newraw),'new_wolf_authored_raw_count':len(wolfraw),'Wolf_old_base_complete_in_delta':True,'all_review_flags':False,'completed_added':0,'restart':['Extract both prior05 archives and this delta under /workspace/scratch/pr100-continuation. All paths below reconstruct the original workspace.','Unicorn: root direct review registration-proposal06 SE and SW clean/joint rows +13pose matrices, then candidate06 source approval and actualMain. All other6direction source/registration exactly05.','Wolf: recovery-by-unicorn/checkpoint.json; own E/W/N pilots+idle16 strictcomplete but physical approval/registration not done. Author remaining SE/S/SW/NW/NE walk3; retain old whole64attack/hit/death only after source/core/corpse review, exclude entire badold40 when replacing walk.','No prior conversation history needed. All raw failures/prompts/source binding present. Source PNGs never transformed/assembled; crops only explicitly diagnostic references.'],'Unicorn_selected_source_pins':selected,'Wolf_old_candidate_source_pins':wpins}
(R/'checkpoint-proposal06.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
paths=set(newraw)
for p in R.iterdir():
 if not p.is_file():continue
 if p.suffix in ['.json','.py','.txt','.log']and ('06'in p.name or 'frontal' in p.name or p.name.startswith('build_new_') or p.name=='recovery-generation-records.json' or p.name=='build_front_diagonal_gait_guides.py' or p.name=='compare_frontal_pilot.py'):
  paths.add(p)
for p in (R/'registration-proposal06').rglob('*'):
 if p.is_file():paths.add(p)
for p in W.iterdir():
 if p.is_file()and (p.suffix in ['.json','.txt','.py','.log']or(p.suffix=='.png'and not p.stem.endswith('-black'))):paths.add(p)
for p in (W/'recovery-by-unicorn').rglob('*'):
 if p.is_file()and'__pycache__'not in p.parts and p.suffix in ['.json','.txt','.py','.log','.png']:paths.add(p)
entries=[]
for p in sorted(paths):
 ent=str(p.relative_to(ROOT));digest=sha(p)
 if ent in base and base[ent]==digest:continue
 entries.append({'source':str(p),'entry':ent,'bytes':p.stat().st_size,'sha256':digest,'kind':'new_authored_raw'if p in newraw or p in wolfraw else'checkpoint_or_diagnostic_or_old_Wolf_base'})
# Independent valid ZIP parts, each below 64MB stored input, no byte concatenation.
groups=[];g=[];n=0
for e in entries:
 if g and n+e['bytes']>62*1024*1024:groups.append(g);g=[];n=0
 g.append(e);n+=e['bytes']
if g:groups.append(g)
archives=[]
for k,g in enumerate(groups,1):
 path=OUT/f'unicorn-wolf-source-delta06-part{k:02d}.zip'
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for e in g:z.write(e['source'],e['entry'])
 with zipfile.ZipFile(path)as z:
  assert z.testzip()is None
  for e in g:assert hashlib.sha256(z.read(e['entry'])).hexdigest()==e['sha256']
 archives.append({'file':str(path),'bytes':path.stat().st_size,'sha256':sha(path),'entries':len(g),'extract':'independent ZIP; extract each to /workspace/scratch/pr100-continuation; do not concatenate'})
idx={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOURCE_ONLY_HOLD_NO_PRODUCTION_NO_MAIN_NO_COUNT','requires_prior_base05_archives':baseidx['archives'],'restore_root':str(ROOT),'candidate06':str(candidate),'candidate06_sha256':sha(candidate),'new_Unicorn_authored_raw':len(newraw),'new_Wolf_authored_raw':len(wolfraw),'all_old_Wolf_base_raw_pngs_and_candidate_and_prompts_included':True,'source_reference_assets':'Original reference atlas paths/hashes remain pinned to existing repository assets; no external substitute or production asset mutation.','member_sha_verified':True,'base05_artifacts_unchanged':True,'archives':archives,'entry_count':len(entries),'uncompressed_bytes':sum(e['bytes']for e in entries),'entries':entries,'selected_Unicorn_source_pins':selected,'selected_Wolf_old_base_pins':wpins,'review_flags':False,'Main':'not_run','completed_added':0};(OUT/'unicorn-wolf-source-delta06-index.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in idx.items()if k not in['entries','selected_Unicorn_source_pins','selected_Wolf_old_base_pins','requires_prior_base05_archives']},ensure_ascii=False,indent=2))
