from pathlib import Path
import json
from PIL import Image,ImageDraw
R=Path(__file__).parent;D=R/'registration-proposal06';es=json.load(open(R/'registration-proposal05/source_registration_proposal.json'))['entries'];idle=next(e for e in es if e['direction']=='SW'and e['role']=='idle'and e['phase']==0)
stems=['SW-A-frontal-projection-attempt1','SW-passing-frontal-proportion-attempt4','SW-B-frontal-proportion-attempt2'];paths=[]
chains=[{'near_fore':[[380,660],[370,870],[350,1080]],'near_hind':[[800,600],[850,800],[900,1070]],'far_fore':[[550,670],[500,815],[560,930]],'far_hind':[[680,680],[720,870],[650,1050]]},{'near_fore':[[320,650],[325,900],[325,1200]],'near_hind':[[790,665],[700,920],[675,1180]],'far_fore':[[525,690],[450,835],[530,1000]],'far_hind':[[680,710],[810,900],[900,1130]]},{'near_fore':[[325,665],[298,840],[360,1020]],'near_hind':[[775,665],[690,850],[630,1090]],'far_fore':[[520,690],[525,900],[500,1160]],'far_hind':[[680,710],[790,870],[900,1100]]}]
part=[dict(idle,label='SW idle original C928')]
for k,s in enumerate(stems):
 j=json.load(open(R/(s+'.diagnostic.json')));f=j['geometry']['frames'][0];e={'path':j['path'],'canvas':[1856,2048,2048][k],'anchor':[647,f['source_anchor'][1]],'frame':f,'label':s,'raw_sha256':j['raw_sha256'],'whole_limbs_approximate_manual_landmarks':chains[k]};part.append(e)
colors={'near_fore':'#d12577','near_hind':'#e68018','far_fore':'#2183b9','far_hind':'#1e8a57'};size=640;out=Image.new('RGB',(size*4,1360),'white');od=ImageDraw.Draw(out)
for k,e in enumerate(part):
 for row in [0,1]:
  im=Image.open(e['path']).convert('RGBA');x,y,w,h=e['frame']['region'];C=e['canvas'];ax,ay=e['anchor'];z=size/C;q=Image.new('RGBA',(size,size),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)).resize((round(w*z),round(h*z))), (round(320+(x-ax)*z),round(400+(y-ay)*z)));d=ImageDraw.Draw(q);d.line((0,400,639,400),fill='#90b59e');d.ellipse((317,397,323,403),outline='red',width=2)
  if row and k:
   for name,pts in e['whole_limbs_approximate_manual_landmarks'].items():
    pp=[(round(320+(xx-ax)*z),round(400+(yy-ay)*z))for xx,yy in pts];d.line(pp,fill=colors[name],width=4)
    for xx,yy in pp:d.ellipse((xx-4,yy-4,xx+4,yy+4),fill=colors[name])
  out.paste(q.convert('RGB'),(k*size,row*680+35));od.text((k*size+8,row*680+8),e['label']+(' physical chain review'if row else''),fill='black')
out.save(D/'SW-new-A1-passing4-B2-idle-clean-and-joint-review.png');(D/'SW-new-A1-passing4-B2-registration-and-joints.json').write_text(json.dumps({'status':'SOURCE_PHYSICAL_ROOT_REVIEW_PENDING_NO_MAIN','review_flags':False,'completed_added':0,'note':'Approximate manual joints identify whole limb trajectories; not an automated physical quality acceptance. X647 proposed projected-spine root replaces tail bbox center; loaded sole source Y retained.','entries':part},ensure_ascii=False,indent=2)+'\n');print(str(out.size))
