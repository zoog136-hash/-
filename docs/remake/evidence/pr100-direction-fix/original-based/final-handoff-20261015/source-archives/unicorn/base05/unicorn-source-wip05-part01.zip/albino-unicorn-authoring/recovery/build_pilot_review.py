from pathlib import Path
import json,hashlib,datetime
from PIL import Image,ImageDraw
R=Path(__file__).parent;B=R.parent
canvas=Image.new('RGB',(3*512,3*560),(235,239,242));d=ImageDraw.Draw(canvas)
selected=[]
for stem,directions in [('walk-E-threephase-attempt1',['E']),('walk-S-N-threephase-attempt1',['S','N'])]:
 j=json.load(open(R/(stem+'.diagnostic.json')));g=j['geometry'];im=Image.open(R/(stem+'.png')).convert('RGBA')
 for f in g['frames']:
  phase=['contactA','passing','contactB'][f['row']];direction=f['direction'];x,y,w,h=f['region'];size=g['canvas_size'][0];q=Image.new('RGBA',(size,size),(235,239,242));q.alpha_composite(im.crop((x,y,x+w,y+h)),tuple(f['margin'][:2]));q=q.resize((512,512),Image.Resampling.LANCZOS);z=ImageDraw.Draw(q);z.line((0,320,511,320),fill=(166,184,172),width=1);z.ellipse((253,317,259,323),outline=(220,20,90),width=2);name=f'{direction}-{phase}-normalized.png';q.convert('RGB').save(R/name);ox=f['row']*512;oy=['E','S','N'].index(direction)*560;canvas.paste(q.convert('RGB'),(ox,oy+35));d.text((ox+10,oy+10),f'{direction} {phase} - prospective sheet pose / root review pending',fill='black');selected.append({'name':name,'direction':direction,'phase':phase,'source_sheet':stem+'.png','source_row':f['row'],'source_anchor':f['source_anchor'],'diagnostic_canvas':size,'source_pose_sha256':f['rgba_sha256']})
canvas.save(R/'pilot-E-S-N-normalized-contact-review.png')
files=[]
for p in sorted(R.glob('*.png')):files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'diagnostic_only':('normalized' in p.name or '.on-' in p.name or 'joint-guide' in p.name)})
prompts=[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(R.glob('*.prompt.txt'))]
manifest={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'key':'monster:알비노 유니콘','status':'RECOVERY_SMALL_WALK_PILOTS_ROOT_REVIEW_PENDING_OTHER_ROLES_IN_PROGRESS','source_original_failed7_preserved':True,'prospective_walk_sheets':['walk-E-threephase-attempt1.png','walk-S-N-threephase-attempt1.png','walk-SE-SW-threephase-attempt1.png','walk-NW-NE-threephase-attempt1.png'],'prospective_walk_frames':21,'W_walk_status':'Unapproved triple patterns: attempt1 uncertaingait; attempt2 boundingrectoverlap andnearforebreversaluncertain. CorrectsingleWA/WBstrict1completePASS. FocusedbottomB+spacingattempt3 generated pendingrecord/review.','root_requested_E_S_N_contacts':selected,'named_normalized_contact_overview':str(R/'pilot-E-S-N-normalized-contact-review.png'),'all_recovery_pngs':files,'exact_prompts':prompts,'pending_roles':['W3walk','idle16','attack24','hit16','death24'],'presentation_to_preserve':json.load(open(B/'candidate.json'))['presentation_to_preserve'],'production_imported':False,'Main':'not_run','completed_added':0}
(R/'recovery-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'manifest':str(R/'recovery-manifest.json'),'overview':manifest['named_normalized_contact_overview'],'named_contacts':[x['name'] for x in selected],'completed_added':0},ensure_ascii=False,indent=2))
