from pathlib import Path
import json,datetime
R=Path(__file__).parent
identity='''Exact source identity: compact muscular WHITE/IVORY HORSE, abundant LONG attached CREAM mane and LONG flowing cream tail, ONE long spiraled GOLD forehead horn, RED eyes where face is visible, pink-grey horse muzzle, pointed ears, cream fetlock feathering and small brown/gold hooves. Four attached EQUINE legs with normal horse elbow/knee/stifle/hock anatomy, one head/neck/ribcage/rump/tail. No armor, wings, rider, saddle, extra horn/limb, antlers, props. Same detailed hand-painted 2D source materials and anatomical proportions. All references represent this same exact source character; no donor body. Tail may curve aside to expose hocks, never cropped or removed.'''
views={
'E-SE':('LEFT E TRUE RIGHT SIDE PROFILE: muzzle/horn points RIGHT, tail LEFT. RIGHT SE FRONT-RIGHT THREEQUARTER: face/chest points downRIGHT.', ['E','SE']),
'S-SW':('LEFT S FRONT VIEW: muzzle/chest aims DOWN toward viewer, balanced frontal horse anatomy. RIGHT SW FRONT-LEFT THREEQUARTER: face/chest points downLEFT.', ['S','SW']),
'W-NW':('LEFT W TRUE LEFT SIDE PROFILE: muzzle/horn points LEFT, tail RIGHT. RIGHT NW BACK-LEFT THREEQUARTER: rump nearest viewer, head far UPPERLEFT, back of ears/mane/neck, no frontal face or red eye. Keep true rearquarter during EVERY phase.', ['W','NW']),
'N-NE':('LEFT N PURE REAR VIEW: rump nearest viewer, head/horn points UP/AWAY above back, NO visible face, muzzle or red eyes. RIGHT NE BACK-RIGHT THREEQUARTER: rump nearest viewer, head far UPPERRIGHT, back of ears/mane/neck, NO frontal face/eye. Keep true rear view during EVERY phase. Head must not turn toward viewer.', ['N','NE'])}
for suffix,(view,ds) in views.items():
 p=f'''Create EXACTLY SIX complete SMALL isolated same-source unicorn sprites in TWO COLUMNS and THREE ROWS, a tall native transparent RGBA sheet. New authentic ATTACK animation, not original recovered motion. First reference source identity, second current same-source idle orientation; paint NEW attack anatomy.

{view} Both columns keep their own heading through all three rows. A gold horn thrust goes toward the stated heading, never turns sideways in N.

ROW1 ANTICIPATION: grounded horse braces three or four hooves; foreknees soften, shoulders/chest lower slightly, neck draws back and horn tilts ready. Real connected muscle/joint posture, weight on hooves.
ROW2 STRIKE: forceful GROUNDED short forward LUNGE with lowered neck/head; the gold horn extends along its own heading. One front hoof plants ahead, other foreknee bends; hindhooves push from behind. Torso pitches forward while pelvis remains supported. This is a physical short melee horn/neck slash, no beam or projectile. In N/NW/NE see lowered head thrust AWAY on far side of back, rump still nearest; do not rotate head to show face.
ROW3 RECOVERY: chest/neck rises back, horn returns up, front leg repositions under shoulder with altered bent knee/hoof and hind hocks settle. Visibly distinct connected body posture from rows1 and2, not translated or resized stills or mane-only variants. Same anatomical body size in all phases, no floating, rear-up or jump.

{identity}

SPACIOUS EXACT LAYOUT: only6 complete bodies,2columns x3rows, each full horse plus FULL horn, mane, tail and every hoof occupies at most55percent of its cell width and55percent of cell height. Plenty transparent margin all sides and between figures; no figure, hair, horn or bounding rectangle overlaps another row or column. Do not fill the sheet with giant horses. Natural limb overlap is okay but every hoof belongs to an attached leg. Keep full tail and horn, no cut tips.
All non-unicorn pixels alphaZERO. NO floor, cast shadow, background, ground line, fog, vignette, glow, particles, text, labels or guides. No mirrors, copied poses, pixel warping or sprite assembly.''' 
 (R/f'attack-{suffix}-attempt1.prompt.txt').write_text(p)
 p=f'''Create EXACTLY TEN complete SMALL isolated same-source unicorn sprites in TWO COLUMNS and FIVE ROWS, tall native transparent RGBA sheet. Newly authored physical HIT and DEATH animation. First reference exact source identity, second same-source idle orientation. New connected body anatomy in every row.

{view} Every row retains these respective compass orientations. For NW/N/NE the horse's RUMP remains nearest and head stays farther away, including final fallen body; no rear-view dead horse suddenly showing a front portrait.

ROW1 HIT RECOIL: grounded impact flinch, neck recoils, shoulder twists and one foreknee bends while three hooves support weight. Body remains complete.
ROW2 HIT SETTLE: hoof comes down and chest settles lower with changed neck/pelvis and hock angles, returning toward grounded balance. Not duplicate idle or row1.
ROW3 DEATH BUCKLE: both FOREKNEES BEND toward ground, chest drops, hindlegs crouch with physically connected stifle/hocks, head dips. All body parts remain attached.
ROW4 DEATH FALL: body rolls/lists onto its flank, chest and one shoulder touch ground, haunch sinks, four legs bend and fold around fullsize ribcage. A genuinely lower falling posture than row3, no standing horse with tilted head.
ROW5 DEAD HOLD: ENTIRE intact horse lies LOW on its side, long ribcage and rump resting on ground, neck/head laid down, gold horn low and attached, four legs fully attached and naturally folded, whole long mane/tail draped on ground. Full anatomical size, no shrinking/fade, no standing hooves under corpse. Every body part and full horn/tail must fit. For rear views the near rump/back flank occludes far head/face naturally; do not rotate skull toward viewer.

{identity}

EXACT SPACIOUS LAYOUT: TEN complete bodies,2columns x5rows. Each full horse INCLUDING horizontal fallen tail and horn fits centrally within its own cell, at most55percent cellwidth and55percent cellheight; use SMALL figures and generous blank gutters, not giant horses that overlap another row. Exactly5 rows, never4, never additional frames. Preserve complete body in every frame; no detached hoof/leg, no dissolving, no gore, no missing horse, no cropped horn/hair/tail. Final corpses have wide horizontal full bodies but fit inside their own cell without reducing anatomical body scale versus standing.
All non-unicorn pixels alphaZERO. No floor, castshadow, groundline, background, fog, aura, vignette, glow, particles, text, labels or markers. No mirrors, copied poses, pixelwarping or spriteassembly.'''
 (R/f'hitdeath-{suffix}-attempt1.prompt.txt').write_text(p)
(R/'checkpoint.json').write_text(json.dumps({'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'RECOVERY_PARTIAL_WALK21_IDLE16_STRICT_PASS_W_WALK_HOLD_OTHER_ROLES_AUTHORING','parent_review':'E and N endpoints ANATOMY_PILOT_ONLY; W attempt3 rejected repeated planted foregroundforeleg; all original7 plus failed recoveries retained.','walk_prospective_frames':21,'idle_prospective_frames':16,'W_walk_frames_approved':0,'roles_remaining':['Wwalk3','attack24','hit16','death24'],'candidate_ready':False,'production_imported':False,'Main':'not_run','completed_added':0},ensure_ascii=False,indent=2)+'\n')
print('Saved 8 exact remaining-role prompts and checkpoint')
