from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib
W=Path(__file__).parent;refs=[]
for dr in ['SE','S','SW','NW','NE']:
 front=dr in ['SE','S','SW'];p=W/('idle-front-eight-pilot1.png'if front else'idle-rear-eight-pilot1.png');j=json.load(open(p.with_suffix('.diagnostic.json')));f=next(x for x in j['geometry']['frames']if x['row']==0 and x['direction']==dr);im=Image.open(p).convert('RGBA');x,y,w,h=f['region'];box=[max(0,x-8),max(0,y-8),min(im.width,x+w+8),min(im.height,y+h+8)];out=W/(dr+'-idle-isolated-DIAGNOSTIC-REFERENCE-ONLY.png');im.crop(box).save(out);refs.append({'diagnostic_reference':str(out),'source_whole_png':str(p),'source_whole_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'crop':box,'not_production_art':True,'not_selected_for_import':True})
 g=Image.new('RGB',(1024,1536),'white');d=ImageDraw.Draw(g)
 for k,phase in enumerate(['A','passing','B']):
  if dr in ['SW','NW'] and phase!='passing':phase='B'if phase=='A'else'A' # anatomicalRIGHT fore lead across all directions; nearLEFT reverses
  oy=k*512;d.text((25,oy+10),f'{dr} {["A","passing","B"][k]}: real near/far fore AND hind chains; compact four-legged wolf',fill='black')
  flip=dr in ['SW','NW']
  def pt(x,y):return(1024-x if flip else x,y+oy)
  if dr=='S':
   hips=[(425,250),(595,250)];shoulders=[(400,280),(620,280)];head=(510,175)
   if phase=='A':legs=[[(400,280),(395,345),(380,435)],[(425,250),(415,310),(420,355)],[(620,280),(610,320),(610,355)],[(595,250),(610,335),(630,420)]]
   elif phase=='passing':legs=[[(400,280),(400,350),(400,415)],[(425,250),(425,315),(425,390)],[(620,280),(610,325),(630,365)],[(595,250),(595,320),(595,375)]]
   else:legs=[[(400,280),(410,325),(405,355)],[(425,250),(415,335),(400,420)],[(620,280),(625,350),(640,435)],[(595,250),(605,310),(600,355)]]
  else:
   hips=[(385,260),(405,250)];shoulders=[(650,280),(605,250)];head=(755,305)if front else(690,120)
   if phase=='A':legs=[[(650,280),(710,350),(780,435)],[(385,260),(325,340),(255,415)],[(605,250),(575,300),(610,360)],[(405,250),(470,320),(525,390)]]
   elif phase=='passing':legs=[[(650,280),(650,355),(650,435)],[(385,260),(390,335),(400,415)],[(605,250),(690,300),(745,365)],[(405,250),(345,320),(295,390)]]
   else:legs=[[(650,280),(585,315),(625,365)],[(385,260),(465,340),(550,415)],[(605,250),(665,335),(735,410)],[(405,250),(340,325),(270,390)]]
  if not front:
   hips=[(420,290),(460,270)];shoulders=[(620,210),(580,200)];head=(700,150)
   if phase=='A':legs=[[(620,210),(680,240),(750,280)],[(420,290),(370,370),(330,450)],[(580,200),(550,225),(570,270)],[(460,270),(500,315),(530,350)]]
   elif phase=='passing':legs=[[(620,210),(630,270),(640,330)],[(420,290),(425,350),(430,420)],[(580,200),(650,225),(690,265)],[(460,270),(400,335),(360,410)]]
   else:legs=[[(620,210),(575,245),(590,285)],[(420,290),(485,330),(540,370)],[(580,200),(645,250),(710,310)],[(460,270),(400,350),(350,430)]]
  d.line([pt(510,250),pt(510,280),pt(*head)]if dr=='S'else[pt(*hips[0]),pt(*shoulders[0]),pt(*head)],fill='gray',width=7)
  for ix,pts in enumerate(legs):
   col=['#d12577','#e68018','#2183b9','#1e8a57'][ix];pp=[pt(*p)for p in pts];d.line(pp,fill=col,width=9)
   for xx,yy in pp:d.ellipse((xx-7,yy-7,xx+7,yy+7),fill=col)
  d.text((25,oy+470),'Pink near fore / orange near hind / blue far fore / green far hind. Diagram only, never import.',fill='black')
 g.save(W/(dr+'-blank-threephase-own-canid-guide.png'))
 heading={'SE':'southeast: face diagonally toward the viewer and RIGHT, front three-quarter, original low stocky wolf camera','SW':'southwest: face diagonally toward the viewer and LEFT, front three-quarter, original low stocky wolf camera','S':'south: EXACT front, centered nose, BOTH yellow eyes visible, no side yaw; face straight toward viewer','NW':'northwest: move diagonally AWAY from viewer and LEFT, show rear-quarter rump/nape with left profile muzzle at far upper left, not a frontal portrait','NE':'northeast: move diagonally AWAY from viewer and RIGHT, show rear-quarter rump/nape with right profile muzzle at far upper right, not a frontal portrait'}[dr]
 text=f'''Newly author a complete 2D fantasy game wolf walking sheet, exactly ONE COLUMN and THREE equal-height rows, THREE complete whole wolf bodies, transparent background with generous gutters. Row0 contact A, row1 passing, row2 opposite contact B. FIRST reference is the exact own {dr} idle appearance/camera in diagnostic isolation, not production source art; preserve its compact gray-brown/charcoal stocky FOUR-LEGGED wolf, pale face and inner legs, yellow eyes when visible, brushed thick tail, no armor. SECOND is newly authored own E walking3 showing fur style and physical canine articulation; do not copy its direction. THIRD is blank canid hip/shoulder leg-phase planning, no artwork donor; use its A/P/B articulation.\nEvery row direction {heading}. Keep exactly the same skull, neck, back/core/haunch sizes and camera in ALL3 rows, same ground-relative root and actual support sole plane. Do not change torso yaw between phases or elongate body/neck. Exact original game identity; newly authored motion, NOT extracted frames.\nContact A: closest foreleg reaches FORWARD/DOWN and carries weight; closest hindleg extends BACK. Far foreleg visibly bends/lifts backward in swing, far hindleg ADVANCES. Passing middle: closest FORE is a VERTICAL shoulder-to-paw loaded chain UNDER its shoulder, closest HIND passes UNDER its hip, far FORE swings forward visibly lifted, far HIND supports behind. Contact B: physically REVERSE BOTH near/far FORE and HIND phases: closest foreleg bends BACK/LIFTED, closest hindleg ADVANCES forward under belly; far foreleg reaches forward/down support, far hindleg extends BACK. Show each WHOLE connected canine shoulder/hip/knee/hock/paw chain changing, not detached feet or duplicated boot overlays. Real four-legged walking, not a biped or hovering trot. All3 phases must be visibly different physically; do not repeat a contact in the passing row.\n''' 
 if dr in ['NW','NE']:text+='Rear-quarter paws must expose rounded rear heels/hocks when grounded and lifted sole pads only on actually swinging legs; toes point away toward travel direction. Tail attaches to rump; neck is closed nape from rear. Do not put two forward-facing eyes on the back.\n'
 if dr=='S':text+='Front S paws have forward toe planes toward viewer; rear paws may be partly naturally occluded, but fore and hind side loading must truly alternate. Keep centered frontal skull with both eyes; never fake three identical front stance pictures.\n'
 if dr in ['SW','NW']:
  text=text.replace('Contact A: closest foreleg reaches FORWARD/DOWN and carries weight; closest hindleg extends BACK. Far foreleg visibly bends/lifts backward in swing, far hindleg ADVANCES.', 'Contact A uses ANATOMICAL RIGHT fore lead: here the near side is anatomicalLEFT, so CLOSEST foreleg bends BACK/LIFTED, CLOSEST hind ADVANCES; FAR foreleg reaches forward/down support, FAR hind extends BACK.').replace('Contact B: physically REVERSE BOTH near/far FORE and HIND phases: closest foreleg bends BACK/LIFTED, closest hindleg ADVANCES forward under belly; far foreleg reaches forward/down support, far hindleg extends BACK.', 'Contact B physically REVERSES contact A: here CLOSEST foreleg reaches FORWARD/DOWN support, CLOSEST hind extends BACK; FAR foreleg bends BACK/LIFTED, FAR hind ADVANCES. Keep the near-side anatomicalLEFT identity through all frames; no simple mirror.')
 text+='Painterly crisp original game sprite style, full body connected, no detached fragments, no separate body/legs, no floating paws, no glow/shadow/backdrop/text/grid/guide marks, no wings/armor/props. Draw ALL3 complete whole poses inside their own row with empty transparent margins between bodies, no part touching canvas boundary. No simple horizontal mirroring of an opposite direction. This is newly authored own wolf motion, never Unicorn/hellhound donor or recolor.\n';(W/f'walk-{dr}-threephase-pilot1.prompt.txt').write_text(text)
(W/'remaining-idle-reference-crops-provenance.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n')
