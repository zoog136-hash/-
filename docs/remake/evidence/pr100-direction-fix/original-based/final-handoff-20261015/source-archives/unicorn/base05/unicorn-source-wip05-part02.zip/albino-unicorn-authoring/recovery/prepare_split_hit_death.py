from pathlib import Path
exec((Path(__file__).parent/'prepare_remaining_roles.py').read_text().split('for suffix,(view,ds) in views.items():')[0])
for suffix,(view,ds) in views.items():
 s=f'''EXACTLY FOUR complete isolated SMALL unicorn sprites. TWO COLUMNS by TWO ROWS, square native transparent RGBA sheet. First reference exact source identity; second same-source idle view authority. Paint NEW physical HIT/FLINCH animation, not any referenced idle still.
{view} Retain the stated heading in both rows; a rear view never turns its head to face the viewer.
ROW1 HIT RECOIL: chest/neck recoils back from impact, shoulders twist, one foreknee sharply flexes and hoof lifts, other three hooves support full body. Pelvis/hocks tense; whole attached horse remains grounded.
ROW2 HIT SETTLE: chest pitches forward/down to regain balance, formerly lifted forehoof comes down and another leg bends subtly, neck/head lowers and hocks soften. Actual connected joints and body posture differ from row1 and idle; not moved/resized still, mane-only variant or attack lunge.
{identity}
Spacious2x2, fullhorse including fullhorn/mane/tail/hooves in each cell, generous100px blank gutters, no body bbox crosses into another cell. Same anatomy and model scale both phases. Exactly4 new poses, no extra row. All non-unicorn pixels alphaZERO; no floor/castshadow/groundline/aura/glow/fog/particles/background/text/guide. No mirrors, duplicates, cropping or pixelassembly.'''
 (R/f'hit-{suffix}-attempt1.prompt.txt').write_text(s)
 s=f'''EXACTLY SIX complete isolated SMALL unicorn sprites. TWO COLUMNS by THREE ROWS, tall native transparent RGBA sheet. First reference exact source identity; second same-source idle views. Paint NEW genuine DEATH animation.
{view} Keep own compass direction throughout fall. RearN/NW/NE show RUMP/back nearest and far head AWAY in EVERY row, including corpse, no front eyes or face toward viewer.
ROW1 BUCKLE: both FOREKNEES BEND toward ground, chest drops halfway, pelvis sinks as hindstifle/hocks crouch. This horse is losing balance, not calmly standing or resting. Head dips, full goldhorn attached.
ROW2 FALLING: body rolls onto one flank, one shoulder and side of chest touch ground, haunch partly falls, four attached legs fold at natural joints around fullsize ribcage. Much lower/tilted body than row1 but neck/head still partly raised. Genuine intermediate fall, not duplicate final corpse.
ROW3 DEAD HOLD: ENTIRE intact fullsize horse lies LOW on side, full ribcage+haunch rest directly on ground, neck/head relaxed and laid down, goldhorn low/attached, four legs attached and folded naturally, full LONG cream mane/tail draped. No standing feet under corpse, no calm sitting horse, no shrink/fade. Keep complete head/horn/body/4legs/hooves/tail; natural depth occlusion okay. Rear dead heads stay away/farther and rump/back still nearest.
{identity}
EXACT6,newdifferentphysicalposes. Generous transparent margins and gutters. Canvas1024x1536. Two columns three rows. Full alpha bounds with horn/tail: topL x80..430 y120..410; topR x590..940 y120..410; midL x80..430 y630..920; midR x590..940 y630..920; bottomL x80..430 y1140..1430; bottomR x590..940 y1140..1430. Blank gutters x440..580,y420..620,y930..1130. Same full anatomical body size all3phases, uniformly render SMALL enough to fit corpse in own cell, no shortening/cropping tail/horn, no neighboring body inside pose rectangle.
All non-unicorn pixels alphaZERO; NO floor,shadow,groundline,background,fog,aura,vignette,glow,particles,text,labels,guide. No gore/dissolving/detached limbs. No mirrors/duplicates/pixelassembly.'''
 (R/f'death-{suffix}-attempt1.prompt.txt').write_text(s)
print('Saved 4 hit4 and 4 death6 prompts; old missing-row HD retained')
