import sys,json,hashlib,copy
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
p=Path('/workspace/scratch/pr100-continuation/revenant-authoring');q=p/'independent'
c=json.loads((p/'candidate.json').read_text());c=copy.deepcopy(c)
c['sheets'][2]['output_path']=str(p/'attack-B-independent-muted.png')
canvases=[512,728,768,520]
notes=[
 'Independent fixed-scale hood/core review: S idle0 crown-to-chin approx48px and N rearhood width approx36px. Baseline512. Source floating state retained, no legs invented.',
 'Independent same-heading face/hood review: S windup crown-to-chin approx66px vs idle48px; 728canvas gives23.2 vs24.0 normalized pixels (manual±4). Full robe/deathheight not used as core landmark.',
 'New muted-source palette repair. Independent provisional hood comparison: W face-opening length approx49px vs idle33px; N hood-cap width approx52px vs idle36px. 768canvas gives16.3 vs16.5 normalized W face length,17.3 vs18.0 N hood-cap width (manual±4). Root must independently approve authored12 and Main.',
 'Independent S recoil crown-to-chin approx48px vs idle48px; 520canvas gives23.6 vs24.0 normalized pixels. Collapse height not normalized; full corpse remains low and retains cloth/hood/hand mass.'
]
frames={};allraw=set();allvisible=set();diagnostics=[];sourcehash={}
for i,s in enumerate(c['sheets']):
 s['canvas_size']=canvases[i];s['scale_review_note']=notes[i]
 path=Path(s['output_path']);im=Image.open(path).convert('RGBA');a=np.asarray(im)
 g=m.analyze(path,rows_count=s['rows'],reference_rows=s['reference_rows'],directions_axis=s['directions_axis'],canvas_size=s['canvas_size'],directions=s.get('directions',m.DIRECTIONS))
 # Ghost has no feet. Preserve directional neutral torso/cloth root X rather than chase the changing leading claw or lowest trailing cloth tip; Y is actual complete cloth support contour each pose.
 anchors=[]
 for f in g['frames']:
  x,y,w,h=f['region'];aa=a[y:y+h,x:x+w,3];ys,xs=np.nonzero(aa>100)
  anchors.append([f['source_anchor'][0],int(y+ys.max())])
 s['source_anchors']=anchors
 s['anchor_review_note']='Explicit per-pose actual alpha>100 lower-cloth support Y; fixed directional neutral whole-cloth torso projection X, not moving slash-hand/tail-tip midpoint. Source floating=true retained for living; terminal complete cloth corpse low on support line. Main must confirm float-disabled death/drop alignment.'
 g=m.analyze(path,rows_count=s['rows'],reference_rows=s['reference_rows'],directions_axis=s['directions_axis'],canvas_size=s['canvas_size'],source_anchors=anchors,directions=s.get('directions',m.DIRECTIONS));m.require_complete_pose_regions(path,g)
 (q/(path.stem+'.reviewed-geometry.json')).write_text(json.dumps(g,indent=2))
 for f in g['frames']:
  x,y,w,h=f['region'];crop=a[y:y+h,x:x+w];raw=hashlib.sha256(crop.tobytes()).hexdigest();vis=m._visible_pose_fingerprint(crop);assert raw not in allraw;assert vis not in allvisible;allraw.add(raw);allvisible.add(vis)
  for role,rows in s['roles'].items():
   if f['row'] in rows:frames[(f['direction'],role,rows.index(f['row']))]=(im,f,g,s)
 mask=np.ones(a.shape[:2],bool)
 for f in g['frames']:
  x,y,w,h=f['region'];mask[y:y+h,x:x+w]=False
 vals=a[:,:,3][mask];diag={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'strict_complete_poses':len(g['frames']),'canvas':s['canvas_size'],'max_outside_alpha':int(vals.max()),'outside_gt25':int((vals>25).sum()),'outside_gt100':int((vals>100).sum())};diagnostics.append(diag);sourcehash[str(path)]=diag['sha256']
assert len(allraw)==len(allvisible)==len(frames)==104
for d in m.DIRECTIONS:
 for role,n in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)]:assert all((d,role,i) in frames for i in range(n))
# All104 at one fixed virtual scale; QA composite only, source PNG bytes unchanged.
roles=[(r,k) for r,n in [('idle',2),('walk',3),('attack',3),('hit',2),('death',3)] for k in range(n)]
cellw,cellh=200,150;plot=Image.new('RGB',(8*cellw,14*cellh),'#161b23');draw=ImageDraw.Draw(plot)
for col,d in enumerate(m.DIRECTIONS):draw.text((col*cellw+85,8),d,fill='white')
for row,(role,k) in enumerate(roles):
 for col,d in enumerate(m.DIRECTIONS):
  im,f,g,s=frames[(d,role,k)];x,y,w,h=f['region'];anchor=f['source_anchor'];scale=256/g['canvas_size'][0];crop=im.crop((x,y,x+w,y+h));out=crop.resize((max(1,round(w*scale)),max(1,round(h*scale))),Image.Resampling.LANCZOS)
  ox=col*cellw+100-round((anchor[0]-x)*scale);oy=(row+1)*cellh+126-round((anchor[1]-y)*scale)
  plot.paste(out,(ox,oy),out);draw.line((col*cellw+25,(row+1)*cellh+126,col*cellw+175,(row+1)*cellh+126),fill='#355446');draw.text((col*cellw+3,(row+1)*cellh+3),role+str(k),fill='white')
plot.save(q/'all104-fixed-scale-review.png')
c['status']='STATIC_REVIEWED_92_REPAIRED12_PENDING_ROOT_INDEPENDENT_AND_MAIN'
c['independent_qa_approved']=False;c['actual_Main']='not_run';c['completed_added']=0;c['png_sha256']=sourcehash
c['prompt']=c['prompt']+'\n\nIndependent focused source-palette correction:\n'+(q/'prompt-attack-B-muted-source-palette.txt').read_text()
c['review']=str(c.get('review',''))+' Independent review: corrected material saturated rearattack palette by new authored12 (raw original preserved); other92 independently reviewed. All104 strict complete/global raw+visibleunique104. Head/core landmarks and actual lower-cloth support anchors recorded in independent review. New12 require ROOT independent approval, then actual Main all8/5roles melee-contact and death/drop/pickup; no completion added.'
c['independent_review_path']=str(p/'independent-review.json');c['display_height_basis']='median_idle'
(p/'candidate-scale-reviewed.json').write_text(json.dumps(c,ensure_ascii=False,indent=2))
(q/'strict-reviewed104.json').write_text(json.dumps({'source_sheets':diagnostics,'raw_unique':len(allraw),'visible_unique':len(allvisible),'runtime_used':len(frames),'unused_source_poses':0},indent=2))
print(json.dumps({'candidate':str(p/'candidate-scale-reviewed.json'),'count':len(frames),'raw_unique':len(allraw),'visible_unique':len(allvisible),'canvases':canvases,'strict':diagnostics},ensure_ascii=False,indent=2))
