from pathlib import Path
import copy,json,sys,hashlib,math
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as motion
B=Path(__file__).parent.parent;O=Path(__file__).parent
C=json.load(open(B/'candidate.json'))

def analyze(s):
    return motion.analyze(Path(s['output_path']),rows_count=s['rows'],reference_rows=s.get('reference_rows'),directions_axis=s['directions_axis'],canvas_size=s['canvas_size'],source_anchors=s['source_anchors'],directions=s['directions'])

def coordinates():
    panel=Image.new('RGB',(2400,550),'white');d=ImageDraw.Draw(panel)
    for si,s in enumerate(C['sheets']):
        g=analyze(s);f=g['frames'][2];p=Path(s['output_path']);x,y,w,h=f['region'];im=Image.open(p).convert('RGBA');q=Image.new('RGBA',(w,h),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)))
        z=1.15;lx=si*400+35;ly=55;panel.paste(q.convert('RGB').resize((round(w*z),round(h*z))),(lx,ly));d.text((si*400+5,5),f'{si} {p.stem}',fill='black');d.text((si*400+5,20),f'{f["direction"]} row0',fill='black')
        for px in range(((x+24)//25)*25,x+w,25):
            ax=lx+(px-x)*z;d.line((ax,ly,ax,ly+h*z),fill=(205,210,215));d.text((ax,ly-13),str(px),fill='black')
        for py in range(((y+24)//25)*25,y+h,25):
            ay=ly+(py-y)*z;d.line((lx,ay,lx+w*z,ay),fill=(205,210,215));d.text((si*400,ay),str(py),fill='black')
    panel.save(O/'living-eye-carapace-source-coordinates.png')

def build():
    landmarks=[
        {'sheet':0,'direction':'S','row':0,'kind':'front red eye center separation','points':[[931,79],[983,78]],'span_px':53,'uncertainty_px':3},
        {'sheet':1,'direction':'N','row':0,'kind':'rigid rear carapace lateral rim corners, below spikes and above abdomen','points':[[872,89],[1038,91]],'span_px':166,'uncertainty_px':8},
        {'sheet':2,'direction':'S','row':0,'kind':'front red eye center separation','points':[[924,207],[977,204]],'span_px':53,'uncertainty_px':3},
        {'sheet':3,'direction':'N','row':0,'kind':'rigid rear carapace lateral rim corners, below spikes and above abdomen','points':[[881,229],[1038,229]],'span_px':157,'uncertainty_px':8},
        {'sheet':4,'direction':'S','row':0,'kind':'front red eye center separation','points':[[945,101],[1001,104]],'span_px':56,'uncertainty_px':3},
        {'sheet':5,'direction':'N','row':0,'kind':'rigid rear carapace lateral rim corners, below spikes and above abdomen','points':[[864,133],[1035,132]],'span_px':171,'uncertainty_px':8},
    ]
    canvases=[512,512,512,480,544,528]
    preview=Image.new('RGB',(13*280+20,8*280+35),(238,241,244));d=ImageDraw.Draw(preview)
    detail=Image.new('RGB',(2400,650),'white');ld=ImageDraw.Draw(detail)
    metrics=[];raw=[];vis=[];roles={};contact=[];support_changes=[]
    for si,(s,canvas) in enumerate(zip(C['sheets'],canvases)):
        p=Path(s['output_path']);g0=analyze(s);im=Image.open(p).convert('RGBA');a=np.asarray(im);alpha=a[:,:,3];anchors=[]
        for f,old in zip(g0['frames'],s['source_anchors']):
            x,y,w,h=f['region'];rootx=old[0];roi=[x,y,x+w,y+h];reason='actual connected support-bottom; visible walking feet or flattened corpse contact'
            # Front right-side walking feet remain visible outside the giant
            # right pincer; keep body-root X fixed when that pincer extends.
            if si in [0,2] and f['direction'] in ['SE','S']:
                l,r=(650,717) if f['direction']=='SE' else (1055,1120)
                roi=[max(l,x),y,min(r,x+w),y+h];reason='outer walking-foot support strip excluding hanging/striking giant front pincer'
            l,t,r,b=roi;yy,xx=np.where(alpha[t:b,l:r]>100);support=t+int(yy.max());anchor=[rootx,support];anchors.append(anchor)
            row={'sheet':si,'row':f['row'],'direction':f['direction'],'source_anchor':anchor,'support_roi':roi,'basis':reason,'prior_anchor':old};contact.append(row)
            if old!=anchor:support_changes.append(row)
        s['canvas_size']=canvas;s['source_anchors']=anchors
        g=analyze(s);motion.require_complete_pose_regions(p,g);covered=np.zeros(alpha.shape,bool)
        for f in g['frames']:
            x,y,w,h=f['region'];covered[y:y+h,x:x+w]=True;raw.append(f['rgba_sha256']);vis.append(motion._visible_pose_fingerprint(a[y:y+h,x:x+w]));role=next(k for k,rows in s['roles'].items() if f['row'] in rows);phase=s['roles'][role].index(f['row']);col={'idle':0,'walk':2,'attack':5,'hit':8,'death':10}[role]+phase;ri=motion.DIRECTIONS.index(f['direction']);px=col*280+14;py=ri*280+30
            tile=Image.new('RGBA',(canvas,canvas),(238,241,244));tile.alpha_composite(im.crop((x,y,x+w,y+h)),tuple(f['margin'][:2]));tile=tile.resize((256,256),Image.Resampling.LANCZOS);preview.paste(tile.convert('RGB'),(px,py));d.line((px,py+160,px+255,py+160),fill=(165,183,170));d.ellipse((px+125,py+157,px+131,py+163),outline=(230,30,100),width=2);d.text((px,py-15),f'{f["direction"]} {role}{phase}',fill='black')
        for role,phases in s['roles'].items():
            for direction in s['directions']:
                k=f'{role}/{direction}';assert k not in roles;roles[k]=len(phases)
        lm=landmarks[si];lm['normalized_span_256']=lm['span_px']*256/canvas;f=g['frames'][2];x,y,w,h=f['region'];q=Image.new('RGBA',(w,h),'white');q.alpha_composite(im.crop((x,y,x+w,y+h)));z=1.05;lx=si*400+30;ly=55;detail.paste(q.convert('RGB').resize((round(w*z),round(h*z))),(lx,ly));pts=[]
        for xx,yy in lm['points']:
            ax=lx+(xx-x)*z;ay=ly+(yy-y)*z;pts.append((ax,ay));ld.ellipse((ax-4,ay-4,ax+4,ay+4),fill=(240,20,100))
        ld.line(pts,fill=(240,20,100),width=2);ld.text((si*400+5,5),str(si)+' '+p.stem,fill='black');ld.text((si*400+5,510),lm['kind'],fill='black');ld.text((si*400+5,530),f'{lm["span_px"]} +/-{lm["uncertainty_px"]} sourcepx',fill='black');ld.text((si*400+5,550),f'canvas{canvas}: normalized{lm["normalized_span_256"]:.2f}',fill='black')
        outside=alpha[~covered];metrics.append({'sheet':si,'image':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frames':len(g['frames']),'canvas':canvas,'strict_analyze':'PASS','complete_visible_regions':'PASS','outside_alpha_max':int(outside.max()),'outside_alpha_gt10':int(np.sum(outside>10)),'outside_alpha_gt100':int(np.sum(outside>100))});(O/(p.stem+'.reviewed-geometry.json')).write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n')
        s['scale_review_note']=f'Independent living {lm["direction"]} {lm["kind"]} span{lm["span_px"]}sourcepx (+/-{lm["uncertainty_px"]}), normalized{lm["normalized_span_256"]:.2f} at canvas{canvas}. Uses eye centers/front or actual rigid dorsal rim corners/rear, excluding raised huge pincer, belly, walking legs and collapsed death height. Six source-coordinate and normalized104 comparisons; original native78 standing core is Main gate. Body-root X remains fixed at actual column root; reviewed walking-foot support Y prevents hanging front giant pincer from controlling ground support. No PNG or threshold changes.'
        s['source_anchors_approved']=True
    assert len(raw)==104 and len(set(raw))==104 and len(set(vis))==104 and len(roles)==40
    preview.save(O/'all104-normalized-review.png');detail.save(O/'annotated-living-core-landmarks.png')
    evidence={'status':'STATIC_REVIEW_PENDING_FINAL_VISUAL','all104_strict':'PASS','raw_unique':104,'visible_unique':104,'landmarks':landmarks,'canvases':canvases,'per_pose_contact':contact,'support_changes':support_changes,'sheets':metrics,'role_direction_phase_counts':roles};(O/'landmark-and-anchor-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n');(B/'candidate-scale-review-wip.json').write_text(json.dumps(C,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'104_strict_visible_unique':'PASS','canvases':canvases,'landmarks':landmarks,'support_changes':support_changes},ensure_ascii=False,indent=2))

def finalize():
    c=json.load(open(B/'candidate-scale-review-wip.json'));e=json.load(open(O/'landmark-and-anchor-evidence.json'))
    src=Path('/workspace/twilight')/c['source_reference']['path'].removeprefix('res://');source_sha=hashlib.sha256(src.read_bytes()).hexdigest();assert source_sha==c['source_reference']['sha256'];x,y,w,h=c['source_reference']['region'];region_sha=hashlib.sha256(Image.open(src).convert('RGBA').crop((x,y,x+w,y+h)).tobytes()).hexdigest();assert region_sha==c['source_reference']['region_rgba_sha256']
    for m in e['sheets']:assert m['sha256']==c['selected_png_sha256'][Path(m['image']).name]
    living_heights=[]
    for s in c['sheets']:
        g=analyze(s)
        for f in g['frames']:
            role=next(k for k,rows in s['roles'].items() if f['row'] in rows)
            if role!='death':living_heights.append(f['region'][3]*256/s['canvas_size'])
    primary=analyze(c['sheets'][0])['neutral_height']*256/c['sheets'][0]['canvas_size'];maximum=max(living_heights)
    notes='Independent review of all104 authored crab poses on white/black proper alpha composites and complete normalized ground-contact comparison, against exact existing-project atlas4cell10 plus wholebody context. Preserve rough spiked ivory/cream carapace, brown chips/joints, two front red beadeyes, one huge anatomicalRIGHTpincer and narrowLEFTpincer, articulated connected walking legs with natural occlusion. No source-neighbor silverblade reproduced. Exact source is existing project art, not verified external original animation. S hugeclaw screenLEFT; W hugeclaw far/upper with small near/lower claw, including WtravelC return; N hugeclaw screenRIGHT before inward-elbow UPcontact. E/W opposingprofiles, frontS eyes/face and N/NW/NE backs hidefrontface in living and correctedcollapsedcorpses. Clawjaw openings, elbow extension/retraction, asymmetric leg/knee supports and shellpitch change physically through2idle/3crawl/3meleeattack/2hit/3death frames, rather than translated or mirrored stills. N strike giantclosedclaw is centeredUP from shell, NW/NE diagonal reach remains correct. All8 terminalcorpses retain fullspiked shell and connected limp claws/legs foldedflat into lowgroundedbody; no emptyframes, detachedpincers or miniaturecarapace. Exact104 source poses usedonce,104raw and104visibleunique, strictanalyze+completevisible guard PASS unchanged. Own anatomical landmarks are S red eye spans53/53/56px and N rigid dorsal rim corners166/157/171px; reviewed canvases512,512,512,480,544,528 normalizefront spans26.5/26.5/26.35 and rear83.0/83.73/82.91. Scale excludes raised giantclaw and collapseddeathheight. Everybody-rootX staysfixed at sourcecolumn root;12SE/S live supportYs are revised3–21sourcepx from hanginggiantpincer bottom to actual outer walkingfeet. All104 supportanchors viewed; isometric depth allows differentfeet/claw screenYs on groundplane. Source PNGs, sourceatlas and recordedregion remain byteexact. Preserve nativevisualheight78,floatingfalse,crawl,melee,attackhitratio0.44 andmedian_idle displaybasis so raisedclaw cannot shrinkstandingcore. This is staticapproval for Main only. Actual native78standingcomparison, worldfloor support, all8five-role playback, melee pincercontact/timing, death/drop/pickup andregressions remain mandatory.'
    c['review']={'identity_preserved':True,'eight_views':True,'motion_roles':True,'no_clipping':True,'notes':notes};c.update(status='INDEPENDENT_STATIC_QA_PASS_READY_FOR_MAIN',independent_qa_approved=True,source_anchors_independently_approved=True,independent_review_path=str(B/'independent-review.json'),Main='not_run',production_imported=False,completed_added=0)
    for s in c['sheets']:s['source_anchors_manually_approved']=True
    report={'target':c['key'],'status':c['status'],'independent_of_author':True,'corrective_art_generated_by_reviewer':False,'actual_source_poses':104,'mandatory_runtime_used_poses':104,'source_unused_poses':0,'global_raw_unique':104,'global_visible_unique':104,'role_direction_phase_counts':e['role_direction_phase_counts'],'all_strict_checks_pass':True,'all_source_pngs_unchanged':True,'source_atlas_sha_unchanged':source_sha,'source_region_rgba_sha_unchanged':region_sha,'anatomical_landmarks':e['landmarks'],'reviewed_canvases':e['canvases'],'author_canvases':[512,512,512,456,512,472],'scale_adjustment_reason':'Independent source-coordinate living anatomical span, excluding pincers/legs/death: rearattack480 and rearhit528 align actual rigid carapace rim; fronthit544 aligns actual56px eye centers. Author53–54px eye estimate did not locate hit-eyes precisely. Native78standingbody remains Main requirement.','source_anchor_verdict':'All104 fixedbody-rootX/supportY reviewed;12frontSE/S idle/travel/attack Ys corrected to outer walkingfeet rather than hanginggiantpincer. See complete104 records and overlay.','support_changes':e['support_changes'],'display_height_review':{'basis':'median_idle','primary_reference_height_normalized':primary,'maximum_living_frame_height_normalized':maximum,'standing_height_if_max_living_basis':78*primary/maximum,'native_visual_height_preserved':78,'reason':'Raised articulated hugeclaw is an appendage and must not force standingcarapace/legs toshrink. Root compare actualstanding78 and raisedclawclearance inMain.'},'visual_review':c['review'],'sheets':e['sheets'],'Main_gate':['ActualMain all8directions5roles','Native78standingbody against original and completedreferenceactors; median_idle intentional','Groundedmultilegsbody and fixedrootX duringclawreach; nohovering/floatingbob','Actual giantRIGHTpincer meleecontact andhitratio0.44, especially N UP and S DOWN phase1','All8 coherent lowterminalcorpses followed by realgrounddrop/pickup','Compatibility/regression and sourcepreservation'],'Main':'not_run','completed_added':0,'repo_map_changes':0,'candidate':str(B/'candidate-scale-reviewed.json'),'preview':str(O/'all104-normalized-review.png'),'landmark_preview':str(O/'annotated-living-core-landmarks.png'),'full_landmark_anchor_evidence':str(O/'landmark-and-anchor-evidence.json')}
    (B/'candidate-scale-reviewed.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(B/'independent-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');e['status']=c['status'];(O/'landmark-and-anchor-evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
    checkpoint={'status':c['status'],'candidate':str(B/'candidate-scale-reviewed.json'),'independent_review':str(B/'independent-review.json'),'104strict_raw_visible_unique':'PASS','source_atlas_unchanged':True,'all_source_pngs_unchanged':True,'reviewed_canvases':e['canvases'],'support_Y_changes':len(e['support_changes']),'Main':'not_run','production_imported':False,'completed_added':0,'next':'Root existing import/Main pipeline; native78groundedcrawlmelee profile andmedian_idle displaybasis preserved.'};(B/'checkpoint.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n');print(json.dumps(checkpoint,ensure_ascii=False,indent=2))

if __name__=='__main__':
    coordinates()
    build()
    finalize()
