from pathlib import Path
import json,sys,math,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as motion
B=Path(__file__).parent.parent
O=Path(__file__).parent
O.mkdir(exist_ok=True)
C=json.load(open(B/'candidate-wip.json'))
for si,name in [(1,'attack-front-S-projection-correction-attempt4'),(4,'attack-rear-N-blade-ratio-correction-attempt3')]:
    C['sheets'][si]['output_path']=str(O/(name+'.png'))

def initial_geometry(si):
    s=C['sheets'][si];p=Path(s['output_path'])
    return motion.analyze(p,rows_count=s['rows'],reference_rows=[0],directions_axis='columns',canvas_size=640,directions=s['directions'])

def coordinate_panel():
    panel=Image.new('RGB',(2100,760),'white');d=ImageDraw.Draw(panel)
    for i,s in enumerate(C['sheets']):
        p=Path(s['output_path']);g=initial_geometry(i)
        f=g['frames'][0];x,y,w,h=f['region'];raw=Image.open(p).convert('RGBA').crop((x,y,x+w,y+h))
        comp=Image.new('RGBA',raw.size,'white');comp.alpha_composite(raw)
        z=2;xx=i*350+30;yy=45;panel.paste(comp.convert('RGB').resize((w*z,h*z)),(xx,yy))
        d.text((i*350+5,5),f'{i}: {p.stem}',fill='black')
        for sx in range(((x+19)//20)*20,x+w,20):
            ax=xx+(sx-x)*z;d.line((ax,yy,ax,yy+h*z),fill=(210,215,220));d.text((ax,yy-13),str(sx),fill='black')
        for sy in range(((y+19)//20)*20,y+h,20):
            ay=yy+(sy-y)*z;d.line((xx,ay,xx+w*z,ay),fill=(210,215,220));d.text((i*350,ay),str(sy),fill='black')
    panel.save(O/'living-anatomy-source-coordinate-review.png')

def exceptional_panel():
    panels=[]
    for si,rows in [(1,[1]),(2,[4]),(5,[4])]:
        s=C['sheets'][si];p=Path(s['output_path']);g=initial_geometry(si)
        for f in g['frames']:
            if f['row'] not in rows:continue
            x,y,w,h=f['region'];raw=Image.open(p).convert('RGBA').crop((x,y,x+w,y+h))
            a=Image.new('RGBA',raw.size,'white');a.alpha_composite(raw)
            z=2;comp=Image.new('RGB',(700,450),'white');comp.paste(a.convert('RGB').resize((w*z,h*z)),(45,40));d=ImageDraw.Draw(comp)
            d.text((5,5),f'{si} {p.stem} row{f["row"]} {f["direction"]}',fill='black')
            for sx in range(((x+24)//25)*25,x+w,25):
                ax=45+(sx-x)*z;d.line((ax,40,ax,40+h*z),fill=(205,210,215));d.text((ax,25),str(sx),fill='black')
            for sy in range(((y+24)//25)*25,y+h,25):
                ay=40+(sy-y)*z;d.line((45,ay,45+w*z,ay),fill=(205,210,215));d.text((0,ay),str(sy),fill='black')
            panels.append(comp)
    for pi in range(3):
        sheet=Image.new('RGB',(1400,900),'white')
        for j,p in enumerate(panels[pi*4:pi*4+4]):sheet.paste(p,((j%2)*700,(j//2)*450))
        sheet.save(O/f'exceptional-pommel-source-coordinate-review-{pi}.png')

def build_normalized():
    # Whole living weapon length is measured along its own two rigid axes,
    # rather than from low strike/death bounding-box heights.
    landmarks=[
        {'sheet':0,'direction':'E','row':0,'tip':[166,33],'guard':[160,175],'pommel':[162,273]},
        {'sheet':1,'direction':'E','row':0,'tip':[296,121],'guard':[206,274],'pommel':[153,368]},
        {'sheet':2,'direction':'E','row':0,'tip':[171,73],'guard':[151,207],'pommel':[138,302]},
        {'sheet':3,'direction':'W','row':0,'tip':[166,33],'guard':[170,165],'pommel':[161,260]},
        {'sheet':4,'direction':'W','row':0,'tip':[151,116],'guard':[247,251],'pommel':[269,355]},
        {'sheet':5,'direction':'W','row':0,'tip':[150,42],'guard':[163,186],'pommel':[160,275]},
    ]
    canvases=[512,600,496,488,584,520]
    # These ROIs select the actual teal pommel; the blade/guard can extend
    # lower on screen in projected strike and flat-death poses.
    special={
        (1,1,'E'):[63,553,100,587],(1,1,'SE'):[525,495,550,522],
        (1,1,'S'):[898,518,930,539],(1,1,'SW'):[1363,493,1396,527],
        (2,4,'E'):[45,1274,87,1305],(2,4,'SE'):[345,1265,385,1286],
        (2,4,'S'):[683,1266,716,1287],(2,4,'SW'):[1045,1267,1075,1292],
        (5,4,'W'):[252,1301,282,1329],(5,4,'NW'):[548,1302,574,1331],
        (5,4,'N'):[680,1332,715,1356],(5,4,'NE'):[823,1305,852,1331],
    }
    summaries=[];geometries=[];raw=[];vis=[];role_map={};anchors_evidence=[]
    preview=Image.new('RGB',(2400,13*265+50),(242,244,247));draw=ImageDraw.Draw(preview)
    landmark_panel=Image.new('RGB',(1800,650),'white');ld=ImageDraw.Draw(landmark_panel)
    for si,(s,canvas) in enumerate(zip(C['sheets'],canvases)):
        p=Path(s['output_path']);g0=initial_geometry(si);im=Image.open(p).convert('RGBA');a=np.asarray(im);alpha=a[:,:,3];anchors=[]
        for f in g0['frames']:
            x,y,w,h=f['region'];roi=special.get((si,f['row'],f['direction']),[x,y,x+w,y+h]);l,t,r,b=roi
            yy,xx=np.where(alpha[t:b,l:r]>100);bottom=t+int(yy.max());by,bx=np.where(alpha[max(t,bottom-3):bottom+1,l:r]>100)
            anchor=[int(round(l+(int(bx.min())+int(bx.max()))/2)),bottom];anchors.append(anchor)
            anchors_evidence.append({'sheet':si,'row':f['row'],'direction':f['direction'],'source_anchor':anchor,'pommel_roi':roi,'method':'actual teal-pommel lower contact edge; no blade-tip or full-bbox recentering'})
        print('ANALYZE',si,p.name,canvas,flush=True)
        for f,anchor in zip(g0['frames'],anchors):
            x,y,w,h=f['region'];dx=canvas//2-(anchor[0]-x);dy=canvas*5//8-(anchor[1]-y)
            if min(dx,dy)<0 or dx+w>canvas or dy+h>canvas:print('CANNOTFIT',f['row'],f['direction'],f['region'],anchor,'placed',[dx,dy,dx+w,dy+h],flush=True)
        g=motion.analyze(p,rows_count=s['rows'],reference_rows=[0,1],directions_axis='columns',canvas_size=canvas,source_anchors=anchors,directions=s['directions']);motion.require_complete_pose_regions(p,g);geometries.append(g)
        covered=np.zeros(alpha.shape,bool)
        for f in g['frames']:
            x,y,w,h=f['region'];covered[y:y+h,x:x+w]=True;raw.append(f['rgba_sha256']);vis.append(motion._visible_pose_fingerprint(a[y:y+h,x:x+w]))
            role=next(k for k,rows in s['roles'].items() if f['row'] in rows);phase=s['roles'][role].index(f['row']);rp={'idle':0,'walk':2,'attack':5,'hit':8,'death':10}[role]+phase;col=motion.DIRECTIONS.index(f['direction'])
            tile=Image.new('RGBA',(canvas,canvas),(242,244,247));tile.alpha_composite(im.crop((x,y,x+w,y+h)),tuple(f['margin'][:2]));tile=tile.resize((256,256),Image.Resampling.LANCZOS)
            tx=col*300+22;ty=rp*265+35;preview.paste(tile.convert('RGB'),(tx,ty));draw.line((tx,ty+160,tx+255,ty+160),fill=(190,199,208));draw.ellipse((tx+125,ty+157,tx+131,ty+163),outline=(220,30,90),width=2);draw.text((tx,ty-14),f'{role}{phase} {f["direction"]} s{si}',fill='black')
        lm=landmarks[si];lm['blade_axis_length_px']=math.dist(lm['tip'],lm['guard']);lm['grip_axis_length_px']=math.dist(lm['guard'],lm['pommel']);lm['blade_grip_ratio']=lm['blade_axis_length_px']/lm['grip_axis_length_px'];lm['whole_axis_length_px']=lm['blade_axis_length_px']+lm['grip_axis_length_px'];lm['normalized_whole_axis_length_256']=lm['whole_axis_length_px']*256/canvas;lm['uncertainty_px']=6
        f=g['frames'][0];x,y,w,h=f['region'];comp=Image.new('RGBA',(w,h),'white');comp.alpha_composite(im.crop((x,y,x+w,y+h)));z=1.65;lx=si*300+25;ly=55;landmark_panel.paste(comp.convert('RGB').resize((int(w*z),int(h*z))),(lx,ly))
        pts=[lm[k] for k in ['tip','guard','pommel']]
        for j,(px,py) in enumerate(pts):
            ax=lx+(px-x)*z;ay=ly+(py-y)*z;ld.ellipse((ax-4,ay-4,ax+4,ay+4),fill=['red','orange','blue'][j]);ld.text((ax+5,ay),['tip','guard','pommel'][j],fill='black')
        ld.text((si*300+5,5),f'{si} {p.stem[:34]}',fill='black');ld.text((si*300+5,590),f'blade/grip {lm["blade_grip_ratio"]:.2f}',fill='black');ld.text((si*300+5,605),f'full normalized {lm["normalized_whole_axis_length_256"]:.1f}',fill='black');ld.text((si*300+5,620),f'canvas {canvas}; source +/-6px',fill='black')
        outside=alpha[~covered];s.update(canvas_size=canvas,source_anchors=anchors,source_anchors_manually_approved=False,source_anchors_approved=False,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        summaries.append({'sheet':si,'image':str(p),'sha256':s['sha256'],'canvas':canvas,'frames':len(g['frames']),'outside_alpha_max':int(outside.max()),'outside_alpha_gt100':int(np.sum(outside>100)),'strict_analyze':'PASS','complete_visible_regions':'PASS'})
        (O/(p.stem+'.reviewed-geometry.json')).write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n')
        for role,phases in s['roles'].items():
            for direction in s['directions']:
                key=f'{role}/{direction}';assert key not in role_map;role_map[key]=len(phases)
    assert len(raw)==104 and len(set(raw))==104 and len(set(vis))==104 and len(role_map)==40
    preview.save(O/'all104-normalized-review.png');landmark_panel.save(O/'annotated-living-weapon-landmarks.png')
    (O/'landmark-and-anchor-evidence.json').write_text(json.dumps({'status':'VISUAL_REVIEW_PENDING','landmarks':landmarks,'per_pose_pommel_anchors':anchors_evidence,'canvases':canvases,'strict_all104':'PASS','raw_unique':len(set(raw)),'visible_unique':len(set(vis)),'sheets':summaries,'roles':role_map},ensure_ascii=False,indent=2)+'\n')
    (B/'candidate-scale-review-wip.json').write_text(json.dumps(C,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'strict_all104':'PASS','raw_visible_unique':104,'canvases':canvases,'landmarks':landmarks,'sheets':summaries},ensure_ascii=False,indent=2))

def finalize_review():
    c=json.load(open(B/'candidate-scale-review-wip.json'));e=json.load(open(O/'landmark-and-anchor-evidence.json'))
    prompts=sorted(O.glob('*correction-attempt*.prompt.txt'))
    c['exact_prompts'].extend({'file':str(p),'text':p.read_text()} for p in prompts)
    for si,name in [(1,'attack-front-S-projection-correction-attempt4'),(4,'attack-rear-N-blade-ratio-correction-attempt3')]:
        c['sheets'][si]['exact_prompt_path']=str(O/(name+'.prompt.txt'))
    for si,s in enumerate(c['sheets']):
        lm=e['landmarks'][si];s['source_anchors_manually_approved']=True;s['source_anchors_approved']=True
        s['scale_review_note']=f'Actual living sword tip/guard/pommel landmarks along blade and grip axes; source blade/grip ratio {lm["blade_grip_ratio"]:.3f}, whole-axis length {lm["whole_axis_length_px"]:.1f}px (+/-6px landmark uncertainty), normalized {lm["normalized_whole_axis_length_256"]:.1f}px with canvas{s["canvas_size"]}. Primary reference120.1px. Not strike bounding-box height or lying-corpse height. Six source-scale anatomy comparisons and normalized104 viewed. Rear hit/death canvas520 retains complete NE corpse from actual pommel support; living ratio115.0 vs120.1px acknowledged. Every pose anchor follows actual teal pommel contact, with explicit semantic pommel ROIs for projected strikes and flat deaths, never blade-tip support or full-bbox X recentering. Source PNG bytes untouched. Actual Main native86 grounded/melee/slash comparison required.'
    notes='Static visual review of all104 complete alpha-composited weapon poses against exact original11319. Retains one narrow slightly undulating cool silverblue blade/dark spine, agedbronze asymmetric guard, long dark wrapped grip and tiny teal pommel without hands,limbs,carrier,aura,trails or detached parts. Distinct front bevel and dark reverse, opposing profiles, genuine blade/hilt pitch,yaw,flex phases across8directions and all5roles. Focused imagegen corrections replaced24 attack poses after original source blade/grip ratio failure; original six sheets and every correction prompt/raw output preserved. Corrected S/N strike has coherent whole-weapon forward/away perspective, clear down/up blade reach and distinct phase; every attack remains grounded at actual pommel rather than projecting tip. All104 raw/visible hashes unique, all104 mandatory source poses used once, strictanalyze and completevisible guard PASS without threshold,count or pixel changes. No omitted visible pixels; outside alpha max3-9 across sheets. Reviewed canvases512,600,496,488,584,520 use living tip/guard/pommel physical length and blade/grip ratio evidence, never compressed strike/death height. Normalized living profile lengths120.1/121.8/119.4/119.3/119.2/115.0px, manual landmarkuncertainty6sourcepx; actual native86 comparison remains Main gate. All104 actualpommel anchors reviewed; Sstrikebladetip and several diagonal/flat poses extend belowpommel in screenY as projectedgroundplane, not hover. Low whole fallen weapons are nonempty and intact. The reviewer generated the corrective attack artwork, so root must independently inspect these24 corrected poses before production import. Static candidate only: Main8directions5roles, meleecontact,timing,worldsupport,deathdrop/pickup andregressions pending. Preserve originalfloatingfalse,visualheight86,melee/slash andattackhitratioprofile.'
    c['review']={'identity_preserved':True,'eight_views':True,'motion_roles':True,'no_clipping':True,'notes':notes}
    c.update(status='STATIC_QA_PASS_ROOT_CORRECTION_REVIEW_AND_MAIN_PENDING',source_anchors_independently_approved=False,source_anchors_reviewed=True,independent_review_path=str(B/'independent-review.json'),corrective_art_generated_by_reviewer=True,root_independent_correction_review='pending',Main='not_run',production_imported=False,completed_added=0)
    source=Path('/workspace/twilight/assets/external_l1j/monsters/11319.png');source_sha=hashlib.sha256(source.read_bytes()).hexdigest();assert source_sha=='37b68430cb7bc5d2de057b49bc1d7098fceab34e2c98ee7ca363e8c06c190333'
    attack_landmarks=[{'sheet':1,'row':1,'direction':'S','tip':[912,663],'guard':[912,580],'pommel':[914,525],'blade_grip_ratio':83/math.hypot(2,55),'note':'forward/downscreen perspective; tip is below actual pommel anchor in screenY'}, {'sheet':4,'row':1,'direction':'N','tip':[908,453],'guard':[904,581],'pommel':[902,662],'blade_grip_ratio':math.hypot(4,128)/math.hypot(2,81),'note':'away/upscreen perspective; dark reverse blade, lowered/yawed guard and shortened whole projected axis'}]
    report={'target':c['key'],'status':c['status'],'independent_of_initial_author':True,'corrective_art_generated_by_reviewer':True,'root_independent_correction_review':'pending','source_poses':104,'mandatory_runtime_used_poses':104,'source_unused_poses':0,'global_raw_unique':104,'global_visible_unique':104,'all_strict_checks_pass':True,'source_sha_unchanged':source_sha,'sheets':e['sheets'],'role_direction_phase_counts':e['roles'],'living_anatomical_landmarks':e['landmarks'],'projected_strike_landmarks':attack_landmarks,'source_anchor_method':'Actual connected teal-pommel lower contact edge reviewed per pose. Default lowest four source rows only where that contour is truly pommel; explicit source-coordinate pommel ROIs on projected front strikes and all8 terminalcorpse poses avoid blade-tip/bbox-midpoint anchoring. See full104 overlay and104 evidence records.','scale_method':'Living physical weapon blade+grip two-axis landmark length and ratio, independent of compressed attack/death bbox. Virtual canvas only; no pixel editing. Rear hit/death520 is smallest reviewed safe canvas for full NE corpse at realpommel; living115px vsprimary120px is documented for Main comparison.','visual_review':c['review'],'corrections':{'original_attack_status':'HOLD_BLADE_GRIP_RATIO_MISMATCH','original_attack_sheets_unchanged':True,'selected_front':c['sheets'][1]['output_path'],'selected_rear':c['sheets'][4]['output_path'],'all_exact_correction_prompts':[str(p) for p in prompts]},'Main_gate':['Root independently view corrected front/rear24 poses; reviewer generated these corrections','ActualMain8directions5roles','Native visualheight86; floatingfalse groundedpommel and stableactorX throughreach','Melee slash actual bladecontact direction/timing especially S/N phase1','All8 low intactterminalcorpses, then realgrounddrop/pickup','Compatibility and regression checks'],'Main':'not_run','completed_added':0,'repo_map_changes':0,'candidate':str(B/'candidate-scale-reviewed.json'),'preview':str(O/'all104-normalized-review.png'),'landmark_preview':str(O/'annotated-living-weapon-landmarks.png'),'per_pose_anchor_evidence':str(O/'landmark-and-anchor-evidence.json')}
    (B/'candidate-scale-reviewed.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(B/'independent-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    e['status']=c['status'];e['projected_strike_landmarks']=attack_landmarks;(O/'landmark-and-anchor-evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
    checkpoint={'status':c['status'],'candidate':'candidate-scale-reviewed.json','independent_review':'independent-review.json','strict_all104':'PASS','global_visible_unique':104,'source_sha_unchanged':source_sha,'Main':'not_run','production_imported':False,'completed_added':0,'next':'Root independent24 correctedattackreview then existingpipeline import/Main; no code/map/profile changes authorized here.'}
    (B/'checkpoint.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n');(O/'scale-hold-checkpoint.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(checkpoint,ensure_ascii=False,indent=2))

if __name__=='__main__':
    coordinate_panel()
    exceptional_panel()
    build_normalized()
    finalize_review()
