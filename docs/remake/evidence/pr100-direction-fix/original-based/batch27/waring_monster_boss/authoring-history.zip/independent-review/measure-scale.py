from pathlib import Path
import json,sys
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
b=Path(__file__).parent
sets=[('original-idle',b.parent/'idle-walk-attempt1.png',b/'geometry-0.json'),('idle16',b/'idle16.png',b/'geometry-idle16.json'),('walk-E-W',b/'walk-E-W.png',b/'geometry-walk-E-W.json'),('walk-S-N',b/'walk-S-N.png',b/'geometry-walk-S-N.json'),('walk-front-diagonals',b/'walk-front-diagonals.png',b/'geometry-walk-front-diagonals.json'),('walk-rear-diagonals',b/'walk-rear-diagonals.png',b/'geometry-walk-rear-diagonals.json'),('attack-front',b.parent/'attack-front-attempt2.png',b/'geometry-1.json'),('attack-rear',b.parent/'attack-rear-attempt2.png',b/'geometry-2.json'),('hit-death-front',b.parent/'hit-death-front-attempt1.png',b/'geometry-3.json'),('hit-death-rear',b.parent/'hit-death-rear-attempt1.png',b/'geometry-4.json')]
out=[]
for name,p,gp in sets:
 g=json.loads(gp.read_text());im=Image.open(p).convert('RGBA');a=np.asarray(im);hsv=np.asarray(im.convert('RGB').convert('HSV'))
 rs=[]
 for f in g['frames']:
  x,y,w,h=f['region']; mask=(hsv[y:y+h,x:x+w,0]>=18)&(hsv[y:y+h,x:x+w,0]<=48)&(hsv[y:y+h,x:x+w,1]>110)&(hsv[y:y+h,x:x+w,2]>95)&(a[y:y+h,x:x+w,3]>100)
  lab,n=ndimage.label(mask); eyes=[]
  for k in range(1,n+1):
   yy,xx=np.nonzero(lab==k)
   if len(xx)>=2:eyes.append({'xy':[float(xx.mean()+x),float(yy.mean()+y)],'area':len(xx)})
  eyes=sorted(eyes,key=lambda z:z['area'],reverse=True)[:3]
  rs.append({'row':f['row'],'direction':f['direction'],'region':f['region'],'eyes':eyes})
 out.append({'name':name,'canvas':g['canvas_size'][0],'measurements':rs})
(b/'landmark-measurements-raw.json').write_text(json.dumps(out,indent=2)+'\n')
for s in out:
 print(s['name'],s['canvas'])
 for f in s['measurements']:
  if f['row']==0 and f['direction'] in ('E','S','N','NW','SE'):
   print(' ',f['direction'],f['region'],f['eyes'])
