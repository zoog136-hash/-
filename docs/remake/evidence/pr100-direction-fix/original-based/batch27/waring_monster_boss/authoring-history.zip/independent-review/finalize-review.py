from pathlib import Path
import json,sys,hashlib,copy,datetime
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as m
b=Path(__file__).parent;root=b.parent;c=json.loads((root/'candidate.json').read_text());old=copy.deepcopy(c['sheets'])
newdata=[('idle-front8',2,'columns',['E','SE','S','SW'],1008,{'idle':[0,1]}),('idle-rear8-standing',2,'rows',['W','NW','N','NE'],1008,{'idle':[0,1]}),('walk-E-W',3,'rows',['E','W'],1120,{'walk':[0,1,2]}),('walk-S-N',3,'rows',['S','N'],1512,{'walk':[0,1,2]}),('walk-front-diagonals',3,'rows',['SE','SW'],1104,{'walk':[0,1,2]}),('walk-rear-diagonals',3,'rows',['NW','NE'],1280,{'walk':[0,1,2]})]
notes={
'idle-front8':'1008 canvas matches front-S gold iris separation37.846px to original19.3px/512 (9.612 vs9.65 in256 canvas). Core crouch and head volume reviewed on proposed normalized contact sheets; no death bounding height used.',
'idle-rear8-standing':'1008 canvas independently matches rear skull-to-neck and shoulder/pelvis body core to original low stalking idle, with planted four-paw support and no exposed lifted pawpads. Full rear view has no facial features. Whole tail/corpse extents were not used as head scale.',
'walk-E-W':'1120 canvas uses source-faithful profile head/core landmarks and side-body length; E/W contact endpoints explicitly switch near vs far foreleg and opposite hindleg. Extended paws/tail do not set role scale.',
'walk-S-N':'1512 canvas matches S iris separation57.318px to original19.3px/512 (9.705 vs9.65 in256 canvas). Rear shoulder-to-hip centerline remains comparable despite bent alternate hindlegs. Manual projected midline anchors compensate whole-figure layout offsets without modifying any source pixel.',
'walk-front-diagonals':'1104 canvas matches SE iris separation36.5606px to original17.0833px/512 (8.478 vs8.541 in256canvas), with foreleg endpoint overlap explicitly reversing. Reach is organic gait extension, not display scale.',
'walk-rear-diagonals':'1280 canvas independently reviewed against original NW/NE skull, neck, shoulder and haunch core; final normalized contact sheets retain source body mass while alternate trailing hindpaw soles switch sides. Raised paw/tail bounding height is not the scale basis.'}
c['sheets']=[]
for name,rows,axis,ds,cv,roles in newdata:
 p=b/(name+'.png');og=json.loads((b/('geometry-'+name+'.json')).read_text());anchors=[f['source_anchor'] for f in og['frames']]
 if name=='walk-S-N':
  xs={'S':[298,789,1239],'N':[290,790,1290]}
  anchors=[[xs[f['direction']][f['row']],f['source_anchor'][1]] for f in og['frames']]
 spec={'output_path':str(p),'rows':rows,'reference_rows':[0,1] if rows==2 else [0],'directions_axis':axis,'directions':ds,'canvas_size':cv,'source_anchors':anchors,'roles':roles,'scale_review_note':notes[name]}
 c['sheets'].append(spec)
c['sheets']+=old[1:]
# Retain exact prior prompts and append exact newly selected prompts, all saved before generation.
selected_prompts=['prompt-idle-front8-spacing-correction.txt','prompt-idle-rear8-standing-correction.txt','prompt-walk-E-W.txt','prompt-walk-S-N.txt','prompt-walk-front-diagonals-correction.txt','prompt-walk-rear-diagonals-correction.txt']
c['prompt']+='\n\nINDEPENDENT_REVIEW_SELECTED_CORRECTIONS EXACT PROMPTS:\n'+''.join('\n'+n+'\n'+(b/n).read_text() for n in selected_prompts)
c['prompt_record_kind']='exact saved pre-generation prompts; original and excluded attempts preserved unchanged'
c['display_height_basis']='max_living_frame'
c['review']={'identity_preserved':True,'eight_views':True,'motion_roles':True,'no_clipping':True,'notes':'Independent STATIC review: complete source black cougar body, clean alpha composites, actual E/W side bodies and N/back head occlusion; walk endpoints traced shoulder/elbow/wrist and hip/knee/hock showing alternating near/far support in all8 directions. Original failed gait40 excluded, selected idle16/walk24 are newly authored unchanged PNGs; alloriginal attack24 and hit/death40 retained. Per-role head/body-core scale reviewed separately from death shortening. Rear attack briefly rears on planted hind paws, and full terminal corpses are low/grounded/complete. NW hit rotates head toward left side during recoil with one sideeye, preserving rear torso; Main reviewer should inspect this transition. Actual Godot Main, combat timing, dropped items, Android and integration have NOT been run by this reviewer; this is candidate-only and changes completion count by zero.'}
allraw=[];allvis=[];summ=[];role_dirs={r:{} for r in m.ROLES};parsed=[]
for idx,s in enumerate(c['sheets']):
 p=Path(s['output_path']);ds=s.get('directions',m.DIRECTIONS);g=m.analyze(p,s['rows'],s['reference_rows'],None,s['directions_axis'],s['canvas_size'],s['source_anchors'],ds);m.require_complete_pose_regions(p,g);parsed.append(g);(b/('final-geometry-'+str(idx)+'.json')).write_text(json.dumps(g,indent=2)+'\n')
 a=np.asarray(Image.open(p));cover=np.zeros(a.shape[:2],bool)
 for f in g['frames']:
  x,y,w,h=f['region'];cover[y:y+h,x:x+w]=True;allraw.append(f['rgba_sha256']);allvis.append(m._visible_pose_fingerprint(a[y:y+h,x:x+w]))
 outside=a[:,:,3][~cover];summ.append({'index':idx,'path':str(p),'sha256':m.sha(p),'frames':len(g['frames']),'strict_analyze':'PASS','complete_pose_regions':'PASS','canvas_size':s['canvas_size'],'outside_alpha_max':int(outside.max()),'outside_alpha_gt25':int(sum(outside>25))})
 for r,rows in s['roles'].items():
  for d in ds:
   assert d not in role_dirs[r];role_dirs[r][d]=len(rows)
assert len(allraw)==len(set(allraw))==len(allvis)==len(set(allvis))==104
for r in m.ROLES:assert set(role_dirs[r])==set(m.DIRECTIONS)
source=Path('/workspace/twilight')/c['reference']['path'].removeprefix('res://');assert m.sha(source)==c['reference']['sha256'];im=Image.open(source).convert('RGBA');x,y,w,h=c['reference']['region'];assert hashlib.sha256(im.crop((x,y,x+w,y+h)).tobytes()).hexdigest()==c['reference']['region_rgba_sha256']
original_manifest={str(Path(s['output_path'])):m.sha(Path(s['output_path'])) for s in old}
report={'status':'STATIC_PASS_PENDING_ROOT_MAIN_VALIDATION','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actor':'monster:웨링','completion_count_delta':0,'source_sha_verified':True,'source_region_sha_verified':True,'strict_analyze':'PASS104','complete_pose_regions':'PASS104','raw_unique':104,'visible_unique':104,'role_direction_counts':role_dirs,'alpha_review':'selected sheets clean on black/white/checker; low alpha edge AA retained; no manual pixel cleanup','sheets':summ,'scale_review':{'original_idle_benchmark_canvas':512,'original_atlas_source_unchanged':True,'original_front_S_iris_span':19.3,'front_attack640_S_iris_span':24.49,'front_hit680_S_iris_span':26.97,'selected_notes':notes,'rear_manual_landmarks':{'original_N':{'skull_to_neck':[79,115],'shoulder_pelvis':[[1245,115],[1245,168]],'canvas':512},'attack_N_windup':{'skull_to_neck':[865,910],'shoulder_pelvis':[[171,918],[181,987]],'canvas':640},'hit_N_A':{'skull_to_neck':[211,260],'shoulder_pelvis':[[642,270],[648,345]],'canvas':688}},'method':'same-view head/core landmarks and normalized composites, independent of long tail or shortened corpse. Approximate manual skull/neck/shoulder/pelvis coordinates reflect articulated posture, not claimed exact motion-capture landmarks. Main confirmation remains required.'},'support_anchor_review':'phase-major projected local ground anchors; original attack/hit/death anchors retained after rear hindpaw and lying corpse contact review. S/N walk x midline is manually compensated for wholebody layout drift; y anchors follow lowest planted support paw. No poses translated or pixels modified.','direction_review':'E/W true side bodies, front S gold eyes; N head/face hidden in allroles; NW/NE rear anatomy. NW hit head turns sideways during recoil, single lateral eye visible while torso stays rear-left; Main transition needs confirmation.','walk_endpoint_review':{'E_W':'near foreleg straight/leading contactA becomes curled/lifted back at contactB while farforeleg plants ahead; hip pair reverses','S_N':'front low/planted forepaw switches screen sides; back lowered support and lifted pawpad switch hindlegs','SE_SW':'long leading near arm contactA is visibly tucked/raised at contactB, fararm now extends/plants','NW_NE':'trailing exposed sole switches near/far hindleg at endpoints, opposite foreleg overlap changes'},'original_pngs_unchanged':original_manifest,'failed_or_excluded_attempts':{'original_idle_walk40':'excluded old E/W/N repeated endpoint gait; original16 idle source visually valid benchmark','walk-full40-failed-correction.png':'repeated anatomical lead endpoints','idle16.png':'real translucent matte band; outside alpha max61/261606 pixels>25','walk-diagonals.png':'repeated near forepaw/hindpaw endpoints despite distinct passing','idle16-clean-alpha-correction.png':'crop rectangle includes another body','idle-rear8.png':'crop rectangle includes another body','idle-rear8-portrait-failed.png':'geometry clean but idle borrowed lifted walking hindpaw/pad; not selected'},'main_screen':'UNVERIFIED_BY_THIS_REVIEWER','combat_attack_hit_death_drop_pickup':'UNVERIFIED_BY_THIS_REVIEWER','android_device':'UNVERIFIED','repository_mutations':False,'runtime_profile_mutations':False}
(root/'candidate-scale-reviewed.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(root/'independent-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
# Recompute canonical role sheets at reviewed scale, explicit diagnostic only.
for role in m.ROLES:
 count=next(iter(role_dirs[role].values()));out=Image.new('RGBA',(8*256,count*256),(235,235,235,255));dr=ImageDraw.Draw(out)
 for s,g in zip(c['sheets'],parsed):
  if role not in s['roles']:continue
  im=Image.open(s['output_path']).convert('RGBA');sc=256/s['canvas_size']
  for pi,row in enumerate(s['roles'][role]):
   for f in g['frames']:
    if f['row']!=row:continue
    di=m.DIRECTIONS.index(f['direction']);x,y,w,h=f['region'];a=f['source_anchor'];crop=im.crop((x,y,x+w,y+h)).resize((max(1,round(w*sc)),max(1,round(h*sc))),Image.Resampling.LANCZOS);out.alpha_composite(crop,(round(di*256+128+(x-a[0])*sc),round(pi*256+160+(y-a[1])*sc)));dr.text((di*256+5,pi*256+5),f['direction']+' '+role+' '+str(pi),fill=(0,0,0,255));dr.line((di*256,pi*256+160,(di+1)*256-1,pi*256+160),fill=(80,110,80,255))
 out.save(b/('final-'+role+'-normalized.png'))
print(json.dumps({'candidate':str(root/'candidate-scale-reviewed.json'),'review':str(root/'independent-review.json'),'frames':len(allraw),'unique_visible':len(set(allvis)),'source_verified':True,'max_outside_alpha':max(s['outside_alpha_max'] for s in summ),'outside_gt25':sum(s['outside_alpha_gt25'] for s in summ)},indent=2))
