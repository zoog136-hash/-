import json,sys
from pathlib import Path
from PIL import Image,ImageDraw
b=Path(__file__).parent
sets=[('original idle',b.parent/'idle-walk-attempt1.png',b/'geometry-0.json',512),('new idle',b/'idle16.png',b/'geometry-idle16.json',600),('walk EW',b/'walk-E-W.png',b/'geometry-walk-E-W.json',1120),('walk SN',b/'walk-S-N.png',b/'geometry-walk-S-N.json',1512),('walk frontdiag',b/'walk-front-diagonals.png',b/'geometry-walk-front-diagonals.json',1104),('walk reardiag',b/'walk-rear-diagonals.png',b/'geometry-walk-rear-diagonals.json',1440),('attack front',b.parent/'attack-front-attempt2.png',b/'geometry-1.json',640),('attack rear',b.parent/'attack-rear-attempt2.png',b/'geometry-2.json',640),('hit/death front',b.parent/'hit-death-front-attempt1.png',b/'geometry-3.json',680),('hit/death rear',b.parent/'hit-death-rear-attempt1.png',b/'geometry-4.json',688)]
sets=[(n,Image.open(p).convert('RGBA'),json.loads(g.read_text()),c) for n,p,g,c in sets]
dirs=['E','SE','S','SW','W','NW','N','NE']
for d in dirs:
 cells=[]
 for n,im,g,c in sets:
  fs=[f for f in g['frames'] if f['direction']==d and(f['row']<2 if 'idle' in n else True)]
  for f in fs:
   x,y,w,h=f['region'];a=f['source_anchor'];crop=im.crop((x,y,x+w,y+h)); sc=512/c
   cell=Image.new('RGBA',(512,400),(235,235,235,255));draw=ImageDraw.Draw(cell);draw.line((0,318,512,318),fill=(85,100,85,255));draw.text((5,5),n+' '+str(f['row']),fill=(0,0,0,255));new=crop.resize((round(w*sc),round(h*sc)),Image.Resampling.LANCZOS);cell.alpha_composite(new,(round(256+(x-a[0])*sc),round(318+(y-a[1])*sc)));cells.append(cell)
  # no slot for nonmatching
 out=Image.new('RGBA',(512*len(cells),400),(235,235,235,255))
 for i,c in enumerate(cells):out.alpha_composite(c,(i*512,0))
 out.save(b/('proposed-scale-'+d+'.png'))
