from pathlib import Path
import json,sys,hashlib,math
from PIL import Image
import numpy as np
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
out=Path(__file__).resolve().parent
specs=[
 ('idle-walk-E-SE',['E','SE'],5,{'idle':[0,1],'walk':[2,3,4]},[0,1]),
 ('idle-walk-S-SW',['S','SW'],5,{'idle':[0,1],'walk':[2,3,4]},[0,1]),
 ('idle-walk-W-NW-spaced',['W','NW'],5,{'idle':[0,1],'walk':[2,3,4]},[0,1]),
 ('idle-walk-N-NE-spaced',['N','NE'],5,{'idle':[0,1],'walk':[2,3,4]},[0,1]),
 ('attack-E-SE',['E','SE'],3,{'attack':[0,1,2]},[2]),
 ('attack-S-SW-spaced',['S','SW'],3,{'attack':[0,1,2]},[2]),
 ('attack-W-NW-spaced',['W','NW'],3,{'attack':[0,1,2]},[2]),
 ('attack-N-NE-northfix',['N','NE'],3,{'attack':[0,1,2]},[2]),
 ('hit-death-E-SE',['E','SE'],5,{'hit':[0,1],'death':[2,3,4]},[1]),
 ('hit-death-S-SW',['S','SW'],5,{'hit':[0,1],'death':[2,3,4]},[1]),
 ('hit-death-W-NW-rearfix',['W','NW'],5,{'hit':[0,1],'death':[2,3,4]},[1]),
 ('hit-death-N-NE',['N','NE'],5,{'hit':[0,1],'death':[2,3,4]},[1]),
]
basis=json.load(open(out/'idle-walk-E-SE-geometry.json'))['neutral_height']/640
sheets=[];checks=[];frames=[];roles={role:{d:[] for d in m.DIRECTIONS} for role in m.ROLES};visible=[];raw=[];errors=[]
for i,(slug,dirs,n,rs,refs) in enumerate(specs):
 path=out/(slug+'.png');baseline=m.analyze(path,rows_count=n,reference_rows=refs,canvas_size=1024,directions=dirs)
 desired=max(64,int(round((baseline['neutral_height']/basis)/8)*8));canvas=desired
 while True:
  try:g=m.analyze(path,rows_count=n,reference_rows=refs,canvas_size=canvas,directions=dirs);break
  except ValueError as exc:
   if str(exc)=='Pose cannot fit the foot-anchored canvas' and canvas<2048:canvas+=8;continue
   raise
 m.require_complete_pose_regions(path,g)
 anchors=[f['source_anchor'] for f in g['frames']]
 # Revalidate exact integer per-pose anchor metadata, preserving image bytes.
 g=m.analyze(path,rows_count=n,reference_rows=refs,canvas_size=canvas,source_anchors=anchors,directions=dirs);m.require_complete_pose_regions(path,g)
 with Image.open(path) as im:
  pixels=np.asarray(im)
  for f in g['frames']:
   x,y,w,h=f['region'];visible.append(m._visible_pose_fingerprint(pixels[y:y+h,x:x+w]));raw.append(f['rgba_sha256'])
 offset=len(frames)
 for f in g['frames']:f['sheet']=i
 frames.extend(g['frames'])
 for role,rows in rs.items():
  for j,d in enumerate(dirs):
   if roles[role][d]:errors.append('duplicate_role_direction:'+role+'/'+d)
   roles[role][d]=[offset+row*len(dirs)+j for row in rows]
 note=('PROVISIONAL geometry-only canvas: neutral/recovery body-height normalization versus E/SE provisionalcanvas640; '
       f'calculated{desired}, safe-foot-fit{canvas}. Source pixels unchanged. Per-pose anchors are original default column/lowest-opaque contact candidates, not final anatomical support approval. '
       'Head/petal/stalk proportion matching and ground contact require independent rendered review and actual Main before approval.')
 sheets.append({'output_path':str(path),'directions':dirs,'directions_axis':'columns','rows':n,'reference_rows':refs,'roles':rs,'canvas_size':canvas,'source_anchors':anchors,'scale_review_note':note})
 checked={'slug':slug,'source':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'image_size':g['image_size'],'directions':dirs,'roles':rs,'unique_poses':g['distinct_pixel_frames'],'strict_analyze':'pass','complete_visible_pixels':'pass','explicit_anchor_preflight':'pass','provisional_canvas':canvas,'neutral_reference_height_pixels':g['neutral_height']};checks.append(checked)
 (out/(slug+'-assembled-geometry.json')).write_text(json.dumps(g,indent=2)+'\n')
for role in m.ROLES:
 for d in m.DIRECTIONS:
  if not roles[role][d]:errors.append('missing_role_direction:'+role+'/'+d)
if len(raw)!=104 or len(set(raw))!=104 or len(set(visible))!=104:errors.append('104_unique_pose_guard')
used=[]
for role in m.ROLES:
 for d in m.DIRECTIONS:used.extend(roles[role][d])
if len(used)!=104 or len(set(used))!=104:errors.append('mandatory_pose_reuse_or_missing')
source=Path('/workspace/twilight/assets/monsters/original/atlas_1.png');source_sha=hashlib.sha256(source.read_bytes()).hexdigest();expected='f32e36a311e090f38f419a17d92a45a5e9af5214d144a0261ef5d356bc1e6387'
if source_sha!=expected:errors.append('original_source_sha')
record=json.load(open(out/'authoring-record.json'))
prompts={p.name:p.read_text() for p in sorted(out.glob('*exact-prompt.txt'))}
candidate={'key':'monster:피닉스','prompt':json.dumps(prompts,ensure_ascii=False,indent=2),'prompt_record_kind':'exact_prompts_for_twelve_direction_pair_sheets_and_spacing_heading_corrections','sheets':sheets,'display_height_basis':'max_living_frame','action_aliases':{'cast':'attack'},'review':{'identity_preserved':True,'eight_views':False,'motion_roles':True,'no_clipping':True,'cast_uses_authored_attack':True,'notes':'Own static inspection: exact golden-orange feathered bird identity with two attached wings/legs, long attached curled feather tail and hooked beak retained. All104 strict geometric/crop/visible uniqueness/role coverage guards pass. Flight has up/horizontal/down wing-joint articulation; attack is beak/chest casting-strike with no added projectile art; hit and3death phases end in a complete low prone bird. CorrectedNattack now keeps head/nape up/away instead of turningright. NWdeath has rearbody correction but independent QA must judge whether all5poses distinguish NW sufficiently from W. Provisional scale/hover-projection and ground/corpse anchors need actual rendered/Main review; no Main approval or completionclaim.'},'status':'FULL104_GEOMETRY_PASS_PENDING_INDEPENDENT_VISUAL_REVIEW','source_claim':'New authored2D from existing project atlas; not extracted original animation. Exactoriginalregion[947,934,315,312]/SHA unchanged; same-atlas wholebodycontext supplements clipped wingtip pixels only.','actual_Main':'not_run','completed_added':0}
(out/'candidate.json').write_text(json.dumps(candidate,ensure_ascii=False,indent=2)+'\n')
review={'status':'STATIC_REVIEW_PENDING_INDEPENDENT_RENDERED_APPROVAL','static_passes':['Golden/orange fieryfeathered bird, hookedbeak/crest/twowings/twoattachedtalonlegs/longcurledfeathertail preserved; no humanlimbs/weapons/orbs.','All8directions have distinct idle2/flight3/attack3/hit2/death3 actualarticulatedposes; all104 visible fingerprints distinct.','Flightphases have genuinely high/horizontal/low wing-joint sweeps and attachedtail curves, not bodysliding.','Sourceconfigured floatingtrue preserved forlivingmotion; deathdescends tocompleteprone lowbird withfoldedwings/attachedtalons/tail.','DedicatedNattackhead correction removes side-facingbeak, showingnape/straightupreachingneck onbackbody.','Strict104 geometric/crop/visible uniqueness/mandatory-role coverage pass; sourceSHAunchanged.'],'unresolved':['Independentreview must judge NWdeathbackview versus Wprofile acrossall5poses; correctionaddsrearplanes butsomeobliques remainclose.','Allflight/attack/headings/support and corpsecontact require actualMain playback andattacktargetcomparison.','Canvasnormalization/maxlivingframebasis and auto column/bottompixel hoverprojection/contactanchors areprovisional; compare againstoriginalandcompletedhighqualityactorinMain.','Properblack/white/checker alpha composition needed; displayedhiddenalpha0RGB isnot itself backgroundmatteproof.'],'actual_Main':'not_run','runtime_connected':False,'completed_added':0}
(out/'static-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
guards={'status':'PASS_GEOMETRIC_PREFLIGHT_NOT_FINAL_VISUAL_APPROVAL' if not errors else 'FAIL','total_poses':len(frames),'unique_raw_crop_poses':len(set(raw)),'unique_visible_poses':len(set(visible)),'mandatory_pose_assignment_count':len(used),'mandatory_unique_assignment_count':len(set(used)),'role_direction_counts':{r:{d:len(ids) for d,ids in row.items()} for r,row in roles.items()},'errors':errors,'sheets':checks,'original_reference_sha256':source_sha,'original_reference_sha_matches':source_sha==expected,'source_pixels_modified':False,'guard_thresholds_changed':False,'production_files_modified':False,'importer_apply':'not_run; candidate eight_views flag false pending parent visual approval','actual_Main':'not_run','completed_added':0}
(out/'full104-guard-report.json').write_text(json.dumps(guards,ensure_ascii=False,indent=2)+'\n')
record['active_checkpoint']={'stage':'full104 read-only preflight complete; candidate ready for independent QA','candidate':str(out/'candidate.json'),'guard_report':str(out/'full104-guard-report.json'),'static_review':str(out/'static-review.json'),'strict_geometric_status':guards['status'],'next':'Independent directional/contact/scale/anchor review; do not approve/import blindly; parent Main afterward','completed_added':0};record['selected_sheets']=checks
for p in out.glob('*exact-prompt.txt'):record['prompts'][p.stem]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'authoring-record.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':guards['status'],'total_poses':len(frames),'unique_visible':len(set(visible)),'errors':errors,'canvases':[s['canvas_size'] for s in sheets],'candidate':str(out/'candidate.json'),'review':str(out/'static-review.json')},ensure_ascii=False))
