import sys,json,hashlib,shutil,fcntl
from pathlib import Path
from PIL import Image
sys.path.insert(0,'/workspace/twilight/tools')
import import_original_based_motion as m
out=Path(__file__).resolve().parent
slug=sys.argv[1];source=Path(sys.argv[2]);spec=json.load(open(out/'sheet-specs.json'))[slug];dest=out/(slug+'.png')
if dest.exists():
 if dest.read_bytes()!=source.read_bytes():raise ValueError('Preserve prior sheet; use new version')
else:shutil.copyfile(source,dest)
report={'slug':slug,'generator_path':str(source),'copy':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'image_size':list(Image.open(dest).size),'rows':spec['rows'],'directions':spec['directions'],'roles':spec['roles'],'canvas_size':1280,'strict_geometry':'not_run','source_pixels_modified':False,'Main':'not_run','completed_added':0}
try:
 g=m.analyze(dest,rows_count=spec['rows'],reference_rows=[0,1],canvas_size=1280,directions=spec['directions']);m.require_complete_pose_regions(dest,g);report['strict_geometry']='pass';report['unique_poses']=g['distinct_pixel_frames'];(out/(slug+'-geometry.json')).write_text(json.dumps(g,indent=2)+'\n')
except Exception as exc:report['strict_geometry']='fail';report['error']=str(exc)
(out/(slug+'-validation.json')).write_text(json.dumps(report,indent=2)+'\n')
with open(out/'.checkpoint.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);checkpoint=json.load(open(out/'checkpoint.json'));checkpoint['finished_sheets']=[{'slug':p.name.removesuffix('-validation.json'),'strict_geometry':json.load(open(p))['strict_geometry']} for p in sorted(out.glob('*-validation.json'))];checkpoint['stage']='Production generation and strictper-sheet checks active';temp=out/('checkpoint-'+slug+'.tmp');temp.write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n');temp.replace(out/'checkpoint.json')
print(json.dumps({'slug':slug,'strict_geometry':report['strict_geometry'],'unique_poses':report.get('unique_poses'),'error':report.get('error'),'copy':str(dest)},ensure_ascii=False))
