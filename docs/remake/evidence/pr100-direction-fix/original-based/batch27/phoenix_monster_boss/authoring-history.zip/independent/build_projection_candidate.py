from pathlib import Path
import json,copy,sys,hashlib,math
import numpy as np
from PIL import Image
from scipy import ndimage
sys.path.insert(0,'/workspace/twilight/tools');import import_original_based_motion as motion
b=Path(__file__).parent.parent;out=Path(__file__).parent;c=json.load(open(b/'candidate.json'));old=copy.deepcopy(c)
sheets=[s for s in c['sheets'] if not s['output_path'].endswith('hit-death-W-NW-rearfix.png')]
for stem,d,canvas in [('hit-death-W-isolated-spaced','W',1024),('hit-death-NW-isolated-spaced-repair4','NW',1120)]:
 sheets.append({'output_path':str(b/(stem+'.png')),'directions':[d],'directions_axis':'columns','rows':5,'reference_rows':[1],'roles':{'hit':[0,1],'death':[2,3,4]},'canvas_size':canvas,'source_anchors':None,'scale_review_note':'New5pose single-direction repair; head/core proposedscale requires root independentreview.'})
c['sheets']=sheets;c.pop('action_aliases',None);c['review'].pop('cast_uses_authored_attack',None)
all_geoms=[];raw=[];vis=[];summaries=[];projections=[];roles={};diagnostics=[]
for si,s in enumerate(sheets):
 p=Path(s['output_path']);overrides={'attack-E-SE':1344,'attack-S-SW-spaced':960,'attack-W-NW-spaced':960,'hit-death-E-SE':1200,'hit-death-N-NE':1200};can=overrides.get(p.stem,round(s['canvas_size']*1.5/8)*8);s['canvas_size']=can
 rgba=np.asarray(Image.open(p));a=rgba[:,:,3]
 # Preliminary geometry never modifies source pixels or accepts incomplete crops.
 g=motion.analyze(p,rows_count=s['rows'],reference_rows=s['reference_rows'],directions=s['directions'],canvas_size=can);motion.require_complete_pose_regions(p,g)
 anchors=[];frame_notes=[]
 for f in g['frames']:
  x,y,w,h=f['region'];co=rgba[y:y+h,x:x+w,:3].astype(int);al=a[y:y+h,x:x+w]
  mask=(al>100)&(co.max(axis=2)<140)&(np.abs(co[:,:,0]-co[:,:,1])<55)&(np.abs(co[:,:,1]-co[:,:,2])<40)
  lab,n=ndimage.label(ndimage.binary_dilation(mask,iterations=2));clusters=[]
  for idx,sl in enumerate(ndimage.find_objects(lab)):
   if sl is None:continue
   yy,xx=np.where(mask&(lab==idx+1));area=len(xx)
   if area<15:continue
   if float(np.median(yy))<h*.2:continue
   clusters.append({'area':area,'xx':xx,'yy':yy})
  clusters.sort(key=lambda q:-q['area'])
  if not clusters:
   raise ValueError(f'{p.name} {f["row"]}/{f["direction"]}: no conservative talon candidates; manual review required')
  chosen=[q for q in clusters if q['area']>=max(20,clusters[0]['area']*.25)][:3]
  xs=np.concatenate([q['xx'] for q in chosen]);ys=np.concatenate([q['yy'] for q in chosen]);ax=int(round(x+float(np.median(xs))));feetbottom=int(y+ys.max())
  is_death=any(f['row'] in rr for role,rr in s['roles'].items() if role=='death')
  if is_death:
   # Local belly/wing support near attached legs, excluding the distant moving tail.
   half=max(5,round(can*7/256));ylim=min(y+h,y+int(ys.max())+max(4,round(can*10/256))+1)
   strip=a[y:ylim,max(x,ax-half):min(x+w,ax+half+1)]>100
   yy,xx=np.where(strip);ay=int(y+yy.max()) if len(yy) else feetbottom
  else:
   ay=min(y+h-2,feetbottom+round(can*8/256))
  ax=max(x,min(x+w-1,ax));ay=max(y,min(y+h-1,ay));anchors.append([ax,ay]);frame_notes.append({'row':f['row'],'direction':f['direction'],'talon_mask_pixels':sum(q['area'] for q in chosen),'talon_bbox_source':[int(x+xs.min()),int(y+ys.min()),int(x+xs.max()+1),int(y+ys.max()+1)],'proposed_anchor':[ax,ay],'anchor_kind':'local belly/wing support around attachedtalons' if is_death else 'under attachedtalons,8normalized hovergap capped inside actualpose','requires_human_projection_review':True})
 s['source_anchors']=anchors
 g=motion.analyze(p,rows_count=s['rows'],reference_rows=s['reference_rows'],directions=s['directions'],canvas_size=can,source_anchors=anchors);motion.require_complete_pose_regions(p,g);all_geoms.append(g);cover=np.zeros(a.shape,bool)
 for f in g['frames']:
  x,y,w,h=f['region'];cover[y:y+h,x:x+w]=True;raw.append(f['rgba_sha256']);vis.append(motion._visible_pose_fingerprint(rgba[y:y+h,x:x+w]))
 z=a[~cover];summaries.append({'image':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frames':len(g['frames']),'canvas':can,'strict':'PASS','outside_alpha_max':int(z.max()),'outside_alpha_gt10':int(np.sum(z>10))});projections.append({'image':p.name,'frames':frame_notes});(out/(p.stem+'.projection-geometry.json')).write_text(json.dumps(g,indent=2)+'\n')
 s['scale_review_note']='Anatomical projection/scale proposal: primarydirection canvases uniformly1.5larger than initialauthor values only to fit actualhip/talonroot anchor with fulltail retained. E/S/Wattack andE/Nhit canvases adjusted from manually measured sameheading eye/nape-to-hip landmarks, excludingchangingwing/tailheight. See independent-review.json for coordinates, uncertainty and residuals. Rootfinalreview required. Living anchorY is under actualdarktalons with8normalizedpixelhovergap capped inside sourcepose; death is localbody/winggroundsupport near attachedtalons, never automatically lowestmovingtail. Conservative darktalon detector candidates require root visualreview against annotated104. No PNG edits orthresholdchange. NewW/NW fivepose repair scales1024/1120 before1.5 expansion are provisional. All13sourcehead/core proportions must be independentlyconfirmed inactualMain beforecompletion; smallbeak/head landmarks have manualuncertainty.'
 for role,rr in s['roles'].items():
  for d in s['directions']:
   assert f'{role}/{d}' not in roles;roles[f'{role}/{d}']=len(rr)
assert len(raw)==104 and len(set(raw))==104 and len(set(vis))==104 and len(roles)==40
issued=['hit-death-W-NW-independent-repair2-exact-prompt.txt','hit-death-NW-isolated-repair3-exact-prompt.txt','hit-death-NW-isolated-spaced-repair4-exact-prompt.txt','hit-death-W-isolated-spaced-exact-prompt.txt']
c['prompt']+='\n\n'+'\n\n'.join(f+' EXACT ISSUED REPAIR PROMPT:\n'+(b/f).read_text() for f in issued);c['review']['eight_views']=True;c['review']['notes']+=' NEWauthorrepair: NW fiveposes now actualbackleft dorsalplanes/nape/hiddenbreast, separate5poseWsheetpreservesexactleftprofile. The priorW/NWrearfix and firstnewpairedrepair are rejected forNWprofileleak; firstisolatedNW hadstrict4/5 due mergedposes, separatedrepair4strictPASS. Rootmustindependentlyreview these NEW10frames; my independentviewapproval covers other94. Allselected104strict/unique/countsPASS. Talon/bodyprojectionanchors and scales remain provisional; noautomaticMainapproval.';c['status']='PROJECTION_CANDIDATE_ROOT_REVIEW_REQUIRED_NOT_MAIN_APPROVED';c['actual_Main']='not_run';c['completed_added']=0;c['independent_qa_approved']=False
(b/'candidate-repaired-projection-provisional.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(out/'projection-diagnostics.json').write_text(json.dumps({'sheets':projections,'strict':summaries,'raw_unique':104,'visible_unique':104,'roles':roles,'requires_human_projection_review':True},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'candidate':str(b/'candidate-repaired-projection-provisional.json'),'frames':104,'strictPASS':True,'canvas':[s['canvas_size'] for s in sheets],'outsideAlpha':[x['outside_alpha_max'] for x in summaries]},indent=2))
