import json,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from pathlib import Path
from PIL import Image
b=Path(__file__).parent.parent;out=b/'independent';c=json.load(open(b/'candidate-repaired-projection-provisional.json'));diag=json.load(open(out/'projection-diagnostics.json'));gs=[];ims=[]
for s in c['sheets']:
 p=Path(s['output_path']);gs.append(json.load(open(out/(p.stem+'.projection-geometry.json'))));ims.append(Image.open(p))
seq=[('idle',0),('idle',1),('walk',0),('walk',1),('walk',2),('attack',0),('attack',1),('attack',2),('hit',0),('hit',1),('death',0),('death',1),('death',2)];dirs=['E','SE','S','SW','W','NW','N','NE'];fig,axes=plt.subplots(8,13,figsize=(26,18),dpi=130,facecolor='#202020')
for rr,d in enumerate(dirs):
 for cc,(role,phase) in enumerate(seq):
  si=next(i for i,s in enumerate(c['sheets']) if d in s['directions'] and role in s['roles']);s=c['sheets'][si];g=gs[si];di=s['directions'].index(d);fi=s['roles'][role][phase]*len(s['directions'])+di;f=g['frames'][fi];x,y,w,h=f['region'];ma=f['margin'];sc=256/s['canvas_size'];xx=ma[0]*sc;yy=ma[1]*sc;a=axes[rr,cc];a.imshow(ims[si].crop((x,y,x+w,y+h)),extent=[xx,xx+w*sc,yy+h*sc,yy],interpolation='nearest');a.set_xlim(30,226);a.set_ylim(210,25);a.axhline(160,color='#687e61',lw=.5);a.plot([128],[160],marker='+',ms=3,color='#65d5ef');bb=diag['sheets'][si]['frames'][fi]['talon_bbox_source'];a.add_patch(Rectangle((xx+(bb[0]-x)*sc,yy+(bb[1]-y)*sc),(bb[2]-bb[0])*sc,(bb[3]-bb[1])*sc,fill=False,edgecolor='#a37964',lw=.4));a.set_facecolor('#202020');a.set_title(f'{d} {role}{phase}',color='white',fontsize=7);a.set_xticks([]);a.set_yticks([])
fig.suptitle('Phoenix104 revisedhead/core scale + actualtalon/bodyprojection — independent94; repaired10 require rootQA; Mainpending',color='white',fontsize=12);fig.tight_layout();fig.savefig(out/'all104-anatomical-projection-provisional.png',facecolor=fig.get_facecolor())
